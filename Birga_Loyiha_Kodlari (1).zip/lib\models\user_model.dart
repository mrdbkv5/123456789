class UserModel {
  final String id;
  final String firstName;
  final String lastName;
  final int age;
  final String gender; // 'Erkak' / 'Ayol'
  final String documentNumber; // Pasport yoki Tug'ilganlik guvohnomasi (Metrka)
  final String? phone;
  final String? email;
  final String country;
  final String region;
  final String district;
  final String role; // 'parent', 'child', 'member'
  final String? familyId;
  final String? avatarUrl;
  final String? childPinCode; // Farzandlar uchun 4-xonali PIN
  final String? emergencyPhone;
  final String? pushToken;
  final DateTime createdAt;

  UserModel({
    required this.id,
    String? firstName,
    String? lastName,
    this.age = 0,
    this.gender = 'Erkak',
    this.documentNumber = '',
    this.phone,
    this.email,
    this.country = "O'zbekiston",
    this.region = 'Toshkent shahri',
    this.district = 'Chilonzor tumani',
    required this.role,
    this.familyId,
    this.avatarUrl,
    this.childPinCode,
    this.emergencyPhone,
    this.pushToken,
    required this.createdAt,
    String? name,
  })  : firstName = (firstName != null && firstName.isNotEmpty)
            ? firstName
            : (name != null ? name.split(' ').first : 'Foydalanuvchi'),
        lastName = (lastName != null && lastName.isNotEmpty)
            ? lastName
            : (name != null && name.contains(' ')
                ? name.substring(name.indexOf(' ') + 1)
                : '');

  String get fullName => '$firstName $lastName'.trim();
  String get name => fullName.isNotEmpty ? fullName : 'Foydalanuvchi';
  bool get isParent => role == 'parent';
  bool get isChild => role == 'child';

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'firstName': firstName,
      'lastName': lastName,
      'age': age,
      'gender': gender,
      'documentNumber': documentNumber,
      'phone': phone,
      'email': email,
      'country': country,
      'region': region,
      'district': district,
      'role': role,
      'familyId': familyId,
      'avatarUrl': avatarUrl,
      'childPinCode': childPinCode,
      'emergencyPhone': emergencyPhone,
      'pushToken': pushToken,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  UserModel copyWith({
    String? id,
    String? firstName,
    String? lastName,
    int? age,
    String? gender,
    String? documentNumber,
    String? phone,
    String? email,
    String? country,
    String? region,
    String? district,
    String? role,
    String? familyId,
    String? avatarUrl,
    String? childPinCode,
    String? emergencyPhone,
    String? pushToken,
    DateTime? createdAt,
  }) {
    return UserModel(
      id: id ?? this.id,
      firstName: firstName ?? this.firstName,
      lastName: lastName ?? this.lastName,
      age: age ?? this.age,
      gender: gender ?? this.gender,
      documentNumber: documentNumber ?? this.documentNumber,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      country: country ?? this.country,
      region: region ?? this.region,
      district: district ?? this.district,
      role: role ?? this.role,
      familyId: familyId ?? this.familyId,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      childPinCode: childPinCode ?? this.childPinCode,
      emergencyPhone: emergencyPhone ?? this.emergencyPhone,
      pushToken: pushToken ?? this.pushToken,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  factory UserModel.fromMap(Map<String, dynamic> map, String docId) {
    return UserModel(
      id: docId,
      firstName: map['firstName'] ?? map['name'] ?? '',
      lastName: map['lastName'] ?? '',
      age: (map['age'] as num?)?.toInt() ?? 0,
      gender: map['gender'] ?? 'Erkak',
      documentNumber: map['documentNumber'] ?? '',
      phone: map['phone'],
      email: map['email'],
      country: map['country'] ?? "O'zbekiston",
      region: map['region'] ?? 'Toshkent shahri',
      district: map['district'] ?? 'Chilonzor tumani',
      role: map['role'] ?? 'member',
      familyId: map['familyId'],
      avatarUrl: map['avatarUrl'],
      childPinCode: map['childPinCode'],
      emergencyPhone: map['emergencyPhone'],
      pushToken: map['pushToken'],
      createdAt: map['createdAt'] != null
          ? DateTime.tryParse(map['createdAt']) ?? DateTime.now()
          : DateTime.now(),
    );
  }
}
