import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../models/shopping_item_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';

class ShoppingScreen extends StatelessWidget {
  const ShoppingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final auth = context.watch<AuthService>();
    final familyId = auth.currentUser?.familyId ?? 'family_101';
    final items = firestore.getShoppingItems(familyId);

    final unpurchased = items.where((i) => !i.isPurchased).toList();
    final purchased = items.where((i) => i.isPurchased).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Umumiy Xaridlar'),
      ),
      body: items.isEmpty
          ? const Center(
              child: Text(
                'Xaridlar ro\'yxati bo\'sh',
                style: TextStyle(color: AppColors.textSecondaryLight),
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (unpurchased.isNotEmpty) ...[
                  const Text(
                    'Sotib olinishi kerak',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  ...unpurchased.map((item) => _buildShoppingCard(context, item, firestore)),
                  const SizedBox(height: 20),
                ],
                if (purchased.isNotEmpty) ...[
                  const Text(
                    'Sotib olinganlar',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textSecondaryLight),
                  ),
                  const SizedBox(height: 10),
                  ...purchased.map((item) => _buildShoppingCard(context, item, firestore)),
                ],
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.accentGreen,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_shopping_cart_rounded),
        label: const Text('Mahsulot qo\'shish'),
        onPressed: () => _showAddItemDialog(context),
      ),
    );
  }

  Widget _buildShoppingCard(BuildContext context, ShoppingItemModel item, FirestoreService firestore) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Checkbox(
          value: item.isPurchased,
          activeColor: AppColors.accentGreen,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          onChanged: (_) {
            firestore.toggleShoppingItem(item.id);
          },
        ),
        title: Text(
          item.name,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            decoration: item.isPurchased ? TextDecoration.lineThrough : null,
            color: item.isPurchased ? AppColors.textSecondaryLight : null,
          ),
        ),
        subtitle: Text(
          '${item.quantity.toStringAsFixed(item.quantity.truncateToDouble() == item.quantity ? 0 : 1)} ${item.unit}' +
              (item.estimatedPrice != null ? ' • ~${item.estimatedPrice!.toInt()} so\'m' : '') +
              ' • Kimdan: ${item.addedByName}',
          style: const TextStyle(fontSize: 12),
        ),
      ),
    );
  }

  void _showAddItemDialog(BuildContext context) {
    final nameCtrl = TextEditingController();
    final qtyCtrl = TextEditingController(text: '1');
    final priceCtrl = TextEditingController();
    String unit = 'dona';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Yangi mahsulot qo\'shish'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Mahsulot nomi',
                    hintText: 'Masalan: Sut, Sabzi, Non',
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: TextField(
                        controller: qtyCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Miqdori'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      flex: 2,
                      child: DropdownButtonFormField<String>(
                        value: unit,
                        items: const [
                          DropdownMenuItem(value: 'dona', child: Text('dona')),
                          DropdownMenuItem(value: 'kg', child: Text('kg')),
                          DropdownMenuItem(value: 'litr', child: Text('litr')),
                          DropdownMenuItem(value: 'paket', child: Text('paket')),
                        ],
                        onChanged: (val) => setDialogState(() => unit = val ?? 'dona'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: priceCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Taxminiy narxi (so\'m, ixtiyoriy)',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Bekor qilish'),
            ),
            ElevatedButton(
              onPressed: () async {
                final name = nameCtrl.text.trim();
                if (name.isEmpty) return;

                final auth = context.read<AuthService>();
                final firestore = context.read<FirestoreService>();

                final newItem = ShoppingItemModel(
                  id: 'shop_${DateTime.now().millisecondsSinceEpoch}',
                  familyId: auth.currentUser?.familyId ?? 'family_101',
                  name: name,
                  quantity: double.tryParse(qtyCtrl.text.trim()) ?? 1.0,
                  unit: unit,
                  estimatedPrice: double.tryParse(priceCtrl.text.trim()),
                  addedByName: auth.currentUser?.name ?? 'Oila a\'zosi',
                  addedAt: DateTime.now(),
                );

                await firestore.addShoppingItem(newItem);
                Navigator.pop(ctx);
              },
              child: const Text('Qo\'shish'),
            ),
          ],
        ),
      ),
    );
  }
}
