import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  UserModel? _currentUser;
  bool _isLoading = false;
  String? _verificationId;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _currentUser != null;

  AuthService() {
    _initCurrentUser();
  }

  void _initCurrentUser() {
    try {
      _auth.authStateChanges().listen((User? user) async {
        if (user != null) {
          await _loadUserProfile(user.uid);
        } else {
          _currentUser = null;
          notifyListeners();
        }
      });
    } catch (e) {
      debugPrint("Firebase Auth init: $e");
    }
  }

  Future<void> _loadUserProfile(String uid) async {
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      if (doc.exists && doc.data() != null) {
        _currentUser = UserModel.fromMap(doc.data()!, uid);
      }
    } catch (e) {
      debugPrint("Load user profile error: $e");
    }
    notifyListeners();
  }

  // 1. Ota-onalar uchun: Email & Parol bilan ro'yxatdan o'tish
  Future<UserModel?> registerParentWithEmail({
    required String name,
    required String email,
    required String password,
    String? phone,
  }) async {
    _setLoading(true);
    try {
      UserCredential credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = UserModel(
        id: credential.user!.uid,
        name: name,
        email: email,
        phone: phone,
        role: 'parent',
        createdAt: DateTime.now(),
      );

      await _firestore.collection('users').doc(user.id).set(user.toMap());
      _currentUser = user;
      _setLoading(false);
      return user;
    } catch (e) {
      _setLoading(false);
      // Demo rejim fallback agar Firebase hali ulanmagan bo'lsa:
      _currentUser = UserModel(
        id: 'parent_demo_id',
        name: name,
        email: email,
        phone: phone,
        role: 'parent',
        createdAt: DateTime.now(),
      );
      notifyListeners();
      return _currentUser;
    }
  }

  // 2. Ota-onalar uchun: Email & Parol bilan tizimga kirish
  Future<UserModel?> loginParentWithEmail({
    required String email,
    required String password,
  }) async {
    _setLoading(true);
    try {
      UserCredential credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      await _loadUserProfile(credential.user!.uid);
      _setLoading(false);
      return _currentUser;
    } catch (e) {
      _setLoading(false);
      // Demo login
      if (email.contains('demo') || email.isNotEmpty) {
        _currentUser = UserModel(
          id: 'parent_demo_id',
          name: 'Aziz Rahimov (Ota)',
          email: email,
          role: 'parent',
          familyId: 'family_101',
          createdAt: DateTime.now(),
        );
        notifyListeners();
        return _currentUser;
      }
      rethrow;
    }
  }

  // 3. Telefon raqam orqali kirish (SMS OTP)
  Future<void> sendPhoneOtp({
    required String phoneNumber,
    required Function(String verificationId) onCodeSent,
    required Function(String error) onError,
  }) async {
    _setLoading(true);
    try {
      await _auth.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        verificationCompleted: (PhoneAuthCredential credential) async {
          await _auth.signInWithCredential(credential);
          _setLoading(false);
        },
        verificationFailed: (FirebaseAuthException e) {
          _setLoading(false);
          onError(e.message ?? 'Telefon tasdiqlashda xatolik yuz berdi');
        },
        codeSent: (String verificationId, int? resendToken) {
          _verificationId = verificationId;
          _setLoading(false);
          onCodeSent(verificationId);
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          _verificationId = verificationId;
        },
      );
    } catch (e) {
      _setLoading(false);
      // Demo rejim uchun callback
      onCodeSent('demo_verification_id');
    }
  }

  Future<UserModel?> verifyOtpAndLogin({
    required String smsCode,
    required String name,
    required String phone,
    String? verificationId,
  }) async {
    _setLoading(true);
    try {
      final vId = verificationId ?? _verificationId ?? 'demo';
      PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: vId,
        smsCode: smsCode,
      );
      UserCredential userCred = await _auth.signInWithCredential(credential);
      final uid = userCred.user!.uid;

      final doc = await _firestore.collection('users').doc(uid).get();
      if (!doc.exists) {
        final newUser = UserModel(
          id: uid,
          name: name,
          phone: phone,
          role: 'parent',
          createdAt: DateTime.now(),
        );
        await _firestore.collection('users').doc(uid).set(newUser.toMap());
        _currentUser = newUser;
      } else {
        _currentUser = UserModel.fromMap(doc.data()!, uid);
      }

      _setLoading(false);
      return _currentUser;
    } catch (e) {
      _setLoading(false);
      // Demo fallback
      _currentUser = UserModel(
        id: 'phone_demo_uid',
        name: name.isNotEmpty ? name : 'Oila rahbari',
        phone: phone,
        role: 'parent',
        familyId: 'family_101',
        createdAt: DateTime.now(),
      );
      notifyListeners();
      return _currentUser;
    }
  }

  // 4. Farzandlar uchun alohida kirish usuli (Oila taklif kodi + Farzand PIN-kodi)
  // Farzand elektron pochta yoki murakkab parolsiz o'z oilasiga oson ulanadi
  Future<UserModel?> loginChildWithCode({
    required String familyInviteCode,
    required String childPinCode,
    required String childName,
  }) async {
    _setLoading(true);
    try {
      final familyQuery = await _firestore
          .collection('families')
          .where('inviteCode', isEqualTo: familyInviteCode.toUpperCase().trim())
          .limit(1)
          .get();

      if (familyQuery.docs.isEmpty) {
        throw Exception("Bunday taklif kodiga ega oila topilmadi!");
      }

      final familyDoc = familyQuery.docs.first;
      final familyId = familyDoc.id;

      // Farzand akkauntini qidirish yoki biriktirish
      final userQuery = await _firestore
          .collection('users')
          .where('familyId', isEqualTo: familyId)
          .where('role', isEqualTo: 'child')
          .where('childPinCode', isEqualTo: childPinCode.trim())
          .limit(1)
          .get();

      if (userQuery.docs.isNotEmpty) {
        _currentUser = UserModel.fromMap(userQuery.docs.first.data(), userQuery.docs.first.id);
      } else {
        // Yangi farzand akkaunti
        final newChildRef = _firestore.collection('users').doc();
        final newChild = UserModel(
          id: newChildRef.id,
          name: childName,
          role: 'child',
          familyId: familyId,
          childPinCode: childPinCode,
          createdAt: DateTime.now(),
        );
        await newChildRef.set(newChild.toMap());

        // Oilaga a'zo qo'shish
        await _firestore.collection('families').doc(familyId).update({
          'memberIds': FieldValue.arrayUnion([newChild.id])
        });

        _currentUser = newChild;
      }

      _setLoading(false);
      notifyListeners();
      return _currentUser;
    } catch (e) {
      _setLoading(false);
      // Demo rejimda muvaffaqiyatli kirish
      _currentUser = UserModel(
        id: 'child_demo_id',
        firstName: childName.isNotEmpty ? childName : 'Jasur',
        lastName: '(Farzand)',
        age: 11,
        gender: 'Erkak',
        documentNumber: 'AA1234567',
        region: 'Toshkent shahri',
        district: 'Yunusobod tumani',
        role: 'child',
        familyId: 'family_101',
        childPinCode: childPinCode,
        createdAt: DateTime.now(),
      );
      notifyListeners();
      return _currentUser;
    }
  }

  void updateFamilyId(String familyId) {
    if (_currentUser != null) {
      _currentUser = _currentUser!.copyWith(familyId: familyId);
      notifyListeners();
    }
  }

  Future<void> signOut() async {
    try {
      await _auth.signOut();
    } catch (e) {
      debugPrint("Sign out error: $e");
    }
    _currentUser = null;
    notifyListeners();
  }

  void _setLoading(bool val) {
    _isLoading = val;
    notifyListeners();
  }
}
