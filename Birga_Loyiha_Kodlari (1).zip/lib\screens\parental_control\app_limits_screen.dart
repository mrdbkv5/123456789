import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../models/app_rule_model.dart';
import '../../services/firestore_service.dart';

class AppLimitsScreen extends StatelessWidget {
  const AppLimitsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final appRules = firestore.getAppRules();
    final bedtime = firestore.getBedtimeSchedule();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ilova Cheklovlari & Uyqu Jadvali'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // BEDTIME SCHEDULE (TUNGI REJIM) CARD
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF312E81), Color(0xFF1E1B4B)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF312E81).withOpacity(0.3),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.bedtime_rounded, color: Colors.amberAccent, size: 26),
                        SizedBox(width: 10),
                        Text(
                          'Tungi Uyqu Rejimi',
                          style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    Switch(
                      value: bedtime.isEnabled,
                      activeColor: Colors.amberAccent,
                      onChanged: (val) {
                        firestore.updateBedtimeSchedule(bedtime.copyWith(isEnabled: val));
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  bedtime.isEnabled
                      ? 'Har kuni soat ${bedtime.startTime} dan ${bedtime.endTime} gacha farzand telefoni avtomatik qulflanadi (faqat ota-onaga qo\'ng\'iroq qilish ochiq qoladi).'
                      : 'Tungi rejim o\'chirilgan. Bolaning telefoni tungi paytda ham ishlaydi.',
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),
                if (bedtime.isEnabled) ...[
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      _buildTimeBadge('Boshlanish: ${bedtime.startTime}', Icons.nights_stay_rounded),
                      const SizedBox(width: 10),
                      _buildTimeBadge('Tugash: ${bedtime.endTime}', Icons.wb_sunny_rounded),
                    ],
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 26),

          // APP-BY-APP RESTRICTIONS (ILOVA BO'YICHA CHEKLOVLAR)
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Ilovalarni Alohida Boshqarish',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
              Text(
                '${appRules.length} ta ilova',
                style: const TextStyle(color: AppColors.textSecondaryLight, fontSize: 13),
              ),
            ],
          ),
          const SizedBox(height: 12),

          ...appRules.map((rule) {
            final isExceeded = rule.isLimitExceeded;
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: rule.isBlocked
                      ? Colors.red.withOpacity(0.5)
                      : (isExceeded ? Colors.orange.withOpacity(0.5) : AppColors.borderLight),
                  width: rule.isBlocked || isExceeded ? 1.5 : 1,
                ),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: rule.isBlocked
                        ? Colors.red.withOpacity(0.12)
                        : (rule.isAlwaysAllowed ? Colors.green.withOpacity(0.12) : AppColors.softBlueLight),
                    child: Icon(
                      _getAppIcon(rule.iconKey),
                      color: rule.isBlocked
                          ? Colors.red
                          : (rule.isAlwaysAllowed ? Colors.green : AppColors.primaryNavy),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              rule.appName,
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                            ),
                            if (rule.isAlwaysAllowed) ...[
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Colors.green.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: const Text(
                                  'Har doim ochiq',
                                  style: TextStyle(fontSize: 10, color: Colors.green, fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          rule.isAlwaysAllowed
                              ? 'Ta\'lim va aloqa uchun cheklanmagan'
                              : 'Bugun ishlatildi: ${rule.usedMinutesToday} daq / Limit: ${rule.dailyLimitMinutes} daq',
                          style: TextStyle(
                            fontSize: 12,
                            color: isExceeded ? Colors.red : AppColors.textSecondaryLight,
                            fontWeight: isExceeded ? FontWeight.bold : FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Block / Unblock Toggle
                  if (!rule.isAlwaysAllowed)
                    IconButton(
                      icon: Icon(
                        rule.isBlocked ? Icons.block_rounded : Icons.lock_open_rounded,
                        color: rule.isBlocked ? Colors.red : Colors.grey,
                      ),
                      tooltip: rule.isBlocked ? 'Qulfdan chiqarish' : 'Bloklash',
                      onPressed: () {
                        firestore.toggleAppBlock(rule.packageName, !rule.isBlocked);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              !rule.isBlocked
                                  ? '${rule.appName} darhol bloklandi!'
                                  : '${rule.appName} qulfdan chiqarildi.',
                            ),
                            backgroundColor: !rule.isBlocked ? Colors.red : Colors.green,
                          ),
                        );
                      },
                    ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildTimeBadge(String text, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.white),
          const SizedBox(width: 6),
          Text(text, style: const TextStyle(color: Colors.white, fontSize: 12)),
        ],
      ),
    );
  }

  IconData _getAppIcon(String key) {
    switch (key) {
      case 'tiktok':
        return Icons.music_note_rounded;
      case 'pubg':
        return Icons.sports_esports_rounded;
      case 'youtube':
        return Icons.play_circle_fill_rounded;
      case 'instagram':
        return Icons.camera_alt_rounded;
      case 'telegram':
        return Icons.send_rounded;
      case 'duolingo':
        return Icons.translate_rounded;
      case 'kundalik':
        return Icons.menu_book_rounded;
      default:
        return Icons.apps_rounded;
    }
  }
}
