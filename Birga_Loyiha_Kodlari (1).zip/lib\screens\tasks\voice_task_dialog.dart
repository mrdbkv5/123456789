import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../core/utils/speech_task_parser.dart';
import '../../models/task_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../../services/speech_service.dart';

class VoiceTaskDialog extends StatefulWidget {
  const VoiceTaskDialog({super.key});

  @override
  State<VoiceTaskDialog> createState() => _VoiceTaskDialogState();
}

class _VoiceTaskDialogState extends State<VoiceTaskDialog> {
  final _titleController = TextEditingController();
  DateTime _selectedDate = DateTime.now().add(const Duration(hours: 2));
  TimeOfDay _selectedTime = TimeOfDay.fromDateTime(DateTime.now().add(const Duration(hours: 2)));
  bool _isParsed = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startVoiceListening();
    });
  }

  void _startVoiceListening() {
    final speech = context.read<SpeechService>();
    speech.startListening(onResult: (text) {
      if (speech.parsedTask != null) {
        final parsed = speech.parsedTask!;
        setState(() {
          _titleController.text = parsed.title;
          if (parsed.dueDate != null) {
            _selectedDate = parsed.dueDate!;
            _selectedTime = TimeOfDay(hour: parsed.dueDate!.hour, minute: parsed.dueDate!.minute);
          }
          _isParsed = true;
        });
      }
    });
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final speech = context.watch<SpeechService>();
    final auth = context.watch<AuthService>();
    final firestore = context.watch<FirestoreService>();

    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.accentGreenLight,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.mic_rounded, color: AppColors.accentGreen),
          ),
          const SizedBox(width: 12),
          const Text(
            'Ovozli vazifa yaratish',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Voice Listening Animation / Status
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: speech.isListening
                    ? AppColors.danger.withOpacity(0.08)
                    : AppColors.softBlueLight.withOpacity(0.4),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: speech.isListening ? AppColors.danger : AppColors.softBlue,
                  width: 1.5,
                ),
              ),
              child: Column(
                children: [
                  Icon(
                    speech.isListening ? Icons.graphic_eq_rounded : Icons.check_circle_outline,
                    size: 40,
                    color: speech.isListening ? AppColors.danger : AppColors.softBlue,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    speech.isListening
                        ? 'Tinglanmoqda... Vazifani ayting'
                        : (speech.lastWords.isNotEmpty ? 'Ovoz muvaffaqiyatli aniqlandi' : 'Mikrofon tayyor'),
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: speech.isListening ? AppColors.danger : AppColors.primaryNavy,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    speech.lastWords.isNotEmpty
                        ? '"${speech.lastWords}"'
                        : 'Masalan: "Ertaga soat beshda ukamni kursdan olib kelishim kerak"',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Parsed Result Confirmation Field
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Vazifa nomi (Aniqlangan)',
                prefixIcon: Icon(Icons.task_alt_rounded),
              ),
            ),
            const SizedBox(height: 14),

            // Sana va Vaqt sozlamalari
            Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: _selectedDate,
                        firstDate: DateTime.now(),
                        lastDate: DateTime.now().add(const Duration(days: 365)),
                      );
                      if (picked != null) {
                        setState(() => _selectedDate = picked);
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                      decoration: BoxDecoration(
                        border: Border.all(color: AppColors.borderLight),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.calendar_today, size: 16, color: AppColors.primaryNavy),
                          const SizedBox(width: 8),
                          Text(DateFormat('dd.MM.yyyy').format(_selectedDate), style: const TextStyle(fontSize: 13)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: InkWell(
                    onTap: () async {
                      final picked = await showTimePicker(
                        context: context,
                        initialTime: _selectedTime,
                      );
                      if (picked != null) {
                        setState(() => _selectedTime = picked);
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                      decoration: BoxDecoration(
                        border: Border.all(color: AppColors.borderLight),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.access_time, size: 16, color: AppColors.primaryNavy),
                          const SizedBox(width: 8),
                          Text(_selectedTime.format(context), style: const TextStyle(fontSize: 13)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            speech.reset();
            Navigator.of(context).pop();
          },
          child: const Text('Bekor qilish'),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.accentGreen,
            foregroundColor: Colors.white,
            minimumSize: const Size(120, 44),
          ),
          onPressed: () async {
            final title = _titleController.text.trim();
            if (title.isEmpty) return;

            final finalDateTime = DateTime(
              _selectedDate.year,
              _selectedDate.month,
              _selectedDate.day,
              _selectedTime.hour,
              _selectedTime.minute,
            );

            final newTask = TaskModel(
              id: 'task_${DateTime.now().millisecondsSinceEpoch}',
              familyId: auth.currentUser?.familyId ?? 'family_101',
              title: title,
              assignedToName: auth.currentUser?.name ?? 'Oila a\'zosi',
              dueDate: finalDateTime,
              priority: 'medium',
              createdBy: auth.currentUser?.id ?? 'user',
            );

            await firestore.addTask(newTask);
            speech.reset();
            if (mounted) Navigator.of(context).pop();
          },
          child: const Text('Tasdiqlash va Saqlash'),
        ),
      ],
    );
  }
}
