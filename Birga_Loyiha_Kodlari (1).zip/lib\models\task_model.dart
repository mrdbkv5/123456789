class TaskModel {
  final String id;
  final String familyId;
  final String title;
  final String? description;
  final String? assignedToId;
  final String? assignedToName;
  final DateTime dueDate;
  final String priority; // 'low', 'medium', 'high'
  final String recurrence; // 'none', 'daily', 'weekly', 'monthly'
  final bool isCompleted;
  final DateTime? completedAt;
  final String createdBy;

  TaskModel({
    required this.id,
    required this.familyId,
    required this.title,
    this.description,
    this.assignedToId,
    this.assignedToName,
    required this.dueDate,
    this.priority = 'medium',
    this.recurrence = 'none',
    this.isCompleted = false,
    this.completedAt,
    required this.createdBy,
  });

  bool get isOverdue {
    if (isCompleted) return false;
    return dueDate.isBefore(DateTime.now());
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'familyId': familyId,
      'title': title,
      'description': description,
      'assignedToId': assignedToId,
      'assignedToName': assignedToName,
      'dueDate': dueDate.toIso8601String(),
      'priority': priority,
      'recurrence': recurrence,
      'isCompleted': isCompleted,
      'completedAt': completedAt?.toIso8601String(),
      'createdBy': createdBy,
    };
  }

  factory TaskModel.fromMap(Map<String, dynamic> map, String docId) {
    return TaskModel(
      id: docId,
      familyId: map['familyId'] ?? '',
      title: map['title'] ?? '',
      description: map['description'],
      assignedToId: map['assignedToId'],
      assignedToName: map['assignedToName'],
      dueDate: map['dueDate'] != null
          ? DateTime.tryParse(map['dueDate']) ?? DateTime.now()
          : DateTime.now(),
      priority: map['priority'] ?? 'medium',
      recurrence: map['recurrence'] ?? 'none',
      isCompleted: map['isCompleted'] ?? false,
      completedAt: map['completedAt'] != null
          ? DateTime.tryParse(map['completedAt'])
          : null,
      createdBy: map['createdBy'] ?? '',
    );
  }

  TaskModel copyWith({
    bool? isCompleted,
    DateTime? completedAt,
  }) {
    return TaskModel(
      id: id,
      familyId: familyId,
      title: title,
      description: description,
      assignedToId: assignedToId,
      assignedToName: assignedToName,
      dueDate: dueDate,
      priority: priority,
      recurrence: recurrence,
      isCompleted: isCompleted ?? this.isCompleted,
      completedAt: completedAt ?? this.completedAt,
      createdBy: createdBy,
    );
  }
}
