import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../models/user_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../calendar/calendar_screen.dart';
import '../expenses/expenses_screen.dart';
import '../map/family_map_screen.dart';
import '../parental_control/parental_dashboard_screen.dart';
import '../education/education_screen.dart';
import '../auth/auth_selection_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final firestore = context.watch<FirestoreService>();
    final user = auth.currentUser;
    final familyId = user?.familyId ?? 'family_101';
    final members = firestore.getFamilyMembers(familyId);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil va Oila Sozlamalari'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // User Card
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: user?.isParent == true ? AppColors.primaryNavy : AppColors.accentGreen,
                  child: Text(
                    user?.name.isNotEmpty == true ? user!.name[0] : 'U',
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user?.name ?? 'Foydalanuvchi',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        user?.isParent == true ? 'Ota-ona (Administrator)' : 'Farzand profili',
                        style: const TextStyle(fontSize: 13, color: AppColors.accentGreen, fontWeight: FontWeight.w600),
                      ),
                      if (user?.email != null) ...[
                        const SizedBox(height: 2),
                        Text(user!.email!, style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight)),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Family Invite Code Card (BRG842)
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1E293B), AppColors.primaryNavy],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Oilaga a\'zo taklif qilish kodi',
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'BRG842',
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        letterSpacing: 2,
                      ),
                    ),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accentGreen,
                        foregroundColor: Colors.white,
                        minimumSize: const Size(90, 36),
                      ),
                      icon: const Icon(Icons.copy_rounded, size: 16),
                      label: const Text('Nusxalash'),
                      onPressed: () {
                        Clipboard.setData(const ClipboardData(text: 'BRG842'));
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Taklif kodi nusxalandi: BRG842')),
                        );
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  'Farzandingiz yoki boshqa oila a\'zosi ushbu kod orqali qo\'shiladi',
                  style: TextStyle(color: Colors.white60, fontSize: 11),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Family Members Section
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Oila a\'zolari',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
              if (user?.isParent == true)
                TextButton.icon(
                  icon: const Icon(Icons.person_add_alt_1_rounded, size: 18),
                  label: const Text('Farzand qo\'shish'),
                  onPressed: () => _showAddChildDialog(context, familyId, firestore),
                ),
            ],
          ),
          const SizedBox(height: 8),

          ...members.map((m) {
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: m.isParent ? AppColors.softBlueLight : AppColors.accentGreenLight,
                  child: Icon(
                    m.isParent ? Icons.shield_rounded : Icons.face_rounded,
                    color: m.isParent ? AppColors.primaryBlue : AppColors.accentGreen,
                  ),
                ),
                title: Text(m.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(m.isParent ? 'Ota-ona / Admin' : 'Farzand • PIN: ${m.childPinCode ?? "****"}'),
                trailing: m.isParent
                    ? const Chip(label: Text('Admin', style: TextStyle(fontSize: 11, color: AppColors.primaryBlue)))
                    : null,
              ),
            );
          }),
          const SizedBox(height: 24),

          // All Sections Links
          const Text('Barcha Bo\'limlar', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),

          _buildNavigationTile(
            context,
            icon: Icons.calendar_month_rounded,
            title: 'Oilaviy Kalendar',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CalendarScreen())),
          ),
          _buildNavigationTile(
            context,
            icon: Icons.insights_rounded,
            title: 'Xarajatlar Tahlili',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ExpensesScreen())),
          ),
          _buildNavigationTile(
            context,
            icon: Icons.map_rounded,
            title: 'Oilaviy Xarita',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FamilyMapScreen())),
          ),
          _buildNavigationTile(
            context,
            icon: Icons.school_rounded,
            title: 'Ta\'lim va Baholar',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EducationScreen())),
          ),
          if (user?.isParent == true)
            _buildNavigationTile(
              context,
              icon: Icons.phonelink_lock_rounded,
              title: 'Ota-ona Nazorati va Ekran Vaqti',
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ParentalDashboardScreen())),
            ),

          const SizedBox(height: 20),

          // Logout
          ListTile(
            leading: const Icon(Icons.logout_rounded, color: AppColors.danger),
            title: const Text('Hisobdan chiqish', style: TextStyle(color: AppColors.danger, fontWeight: FontWeight.bold)),
            onTap: () async {
              await auth.signOut();
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const AuthSelectionScreen()),
                (route) => false,
              );
            },
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  Widget _buildNavigationTile(BuildContext context, {required IconData icon, required String title, required VoidCallback onTap}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: AppColors.primaryNavy),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 16),
        onTap: onTap,
      ),
    );
  }

  void _showAddChildDialog(BuildContext context, String familyId, FirestoreService firestore) {
    final nameCtrl = TextEditingController();
    final pinCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Yangi Farzand Profilini Yaratish'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(labelText: 'Farzand ismi (Masalan: Madina)'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: pinCtrl,
              keyboardType: TextInputType.number,
              maxLength: 4,
              decoration: const InputDecoration(labelText: '4 xonali PIN-kod (Masalan: 5678)'),
            ),
            const SizedBox(height: 6),
            const Text(
              'Farzandingiz o\'z telefonida Oila kodi (BRG842) va ushbu PIN-kod orqali osongina tizimga ulanadi.',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Bekor qilish')),
          ElevatedButton(
            onPressed: () {
              final name = nameCtrl.text.trim();
              final pin = pinCtrl.text.trim();
              if (name.isEmpty || pin.length != 4) return;

              firestore.addChildMember(familyId: familyId, childName: name, pinCode: pin);
              Navigator.pop(ctx);
            },
            child: const Text('Yaratish'),
          ),
        ],
      ),
    );
  }
}
