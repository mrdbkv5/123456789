class ExpenseModel {
  final String id;
  final String familyId;
  final String title;
  final double amount;
  final DateTime date;
  final String category;
  final String? note;
  final String paidByName;

  ExpenseModel({
    required this.id,
    required this.familyId,
    required this.title,
    required this.amount,
    required this.date,
    required this.category,
    this.note,
    required this.paidByName,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'familyId': familyId,
      'title': title,
      'amount': amount,
      'date': date.toIso8601String(),
      'category': category,
      'note': note,
      'paidByName': paidByName,
    };
  }

  factory ExpenseModel.fromMap(Map<String, dynamic> map, String docId) {
    return ExpenseModel(
      id: docId,
      familyId: map['familyId'] ?? '',
      title: map['title'] ?? '',
      amount: (map['amount'] as num?)?.toDouble() ?? 0.0,
      date: map['date'] != null
          ? DateTime.tryParse(map['date']) ?? DateTime.now()
          : DateTime.now(),
      category: map['category'] ?? 'Boshqa xarajatlar',
      note: map['note'],
      paidByName: map['paidByName'] ?? '',
    );
  }
}
