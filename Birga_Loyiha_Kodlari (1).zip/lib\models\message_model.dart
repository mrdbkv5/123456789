class MessageModel {
  final String id;
  final String chatId;
  final String senderId;
  final String senderName;
  final String text;
  final String type; // 'text', 'image', 'audio', 'file'
  final String? mediaUrl;
  final int? audioDurationSeconds;
  final String status; // 'sending', 'sent', 'delivered', 'read', 'failed'
  final DateTime timestamp;
  final String? replyToMessageId;

  MessageModel({
    required this.id,
    required this.chatId,
    required this.senderId,
    required this.senderName,
    required this.text,
    this.type = 'text',
    this.mediaUrl,
    this.audioDurationSeconds,
    this.status = 'sent',
    required this.timestamp,
    this.replyToMessageId,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'chatId': chatId,
      'senderId': senderId,
      'senderName': senderName,
      'text': text,
      'type': type,
      'mediaUrl': mediaUrl,
      'audioDurationSeconds': audioDurationSeconds,
      'status': status,
      'timestamp': timestamp.toIso8601String(),
      'replyToMessageId': replyToMessageId,
    };
  }

  factory MessageModel.fromMap(Map<String, dynamic> map, String docId) {
    return MessageModel(
      id: docId,
      chatId: map['chatId'] ?? '',
      senderId: map['senderId'] ?? '',
      senderName: map['senderName'] ?? '',
      text: map['text'] ?? '',
      type: map['type'] ?? 'text',
      mediaUrl: map['mediaUrl'],
      audioDurationSeconds: (map['audioDurationSeconds'] as num?)?.toInt(),
      status: map['status'] ?? 'sent',
      timestamp: map['timestamp'] != null
          ? DateTime.tryParse(map['timestamp']) ?? DateTime.now()
          : DateTime.now(),
      replyToMessageId: map['replyToMessageId'],
    );
  }
}
