import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/family_model.dart';
import '../models/task_model.dart';
import '../models/shopping_item_model.dart';
import '../models/bill_model.dart';
import '../models/expense_model.dart';
import '../models/grade_model.dart';
import '../models/screen_time_model.dart';
import '../models/location_update_model.dart';
import '../models/user_model.dart';
import '../models/medical_passport_model.dart';
import '../models/geofence_model.dart';
import '../models/remote_control_model.dart';
import '../models/reward_item_model.dart';
import '../models/app_rule_model.dart';
import '../models/ai_message_model.dart';

class FirestoreService extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  FamilyModel? _currentFamily;
  final List<TaskModel> _demoTasks = [];
  final List<ShoppingItemModel> _demoShoppingItems = [];
  final List<BillModel> _demoBills = [];
  final List<ExpenseModel> _demoExpenses = [];
  final List<GradeModel> _demoGrades = [];
  final List<ScreenTimeModel> _demoScreenTimes = [];
  final List<LocationUpdateModel> _demoLocations = [];
  final List<UserModel> _demoMembers = [];
  final List<MedicalPassportModel> _demoMedicalPassports = [];
  final List<GeofenceZoneModel> _demoGeofences = [];
  final Map<String, RemoteDeviceControlModel> _demoRemoteDevices = {};

  // --- YANGI: MUKOFOTLAR VA TANGALAR ---
  final List<RewardItemModel> _demoRewards = [];
  ChildCoinProfile _childCoinProfile = ChildCoinProfile(
    childId: 'child_demo_id',
    childName: 'Jasur Rahimov',
    totalCoins: 120,
    weeklyEarned: 45,
    level: 3,
  );

  // --- YANGI: ILOVA CHEKLOVLARI VA TUNGI REJIM ---
  final List<AppRuleModel> _demoAppRules = [];
  BedtimeScheduleModel _bedtimeSchedule = BedtimeScheduleModel();

  // --- YANGI: SOS VA SIRENA ---
  bool _isEmergencySirenActive = false;
  bool _isChildSOSActive = false;

  // --- YANGI: BIRGA AI CHAT ---
  final List<AIMessageModel> _demoAIChat = [];

  FirestoreService() {
    _initDemoData();
  }

  void _initDemoData() {
    _currentFamily = FamilyModel(
      id: 'family_101',
      name: 'Rahimovlar Oilasi',
      inviteCode: 'BRG842',
      createdBy: 'parent_demo_id',
      memberIds: ['parent_demo_id', 'child_demo_id'],
      createdAt: DateTime.now().subtract(const Duration(days: 30)),
    );

    _demoMembers.addAll([
      UserModel(
        id: 'parent_demo_id',
        firstName: 'Aziz',
        lastName: 'Rahimov',
        age: 38,
        gender: 'Erkak',
        documentNumber: 'AA1234567',
        phone: '+998901234567',
        email: 'aziz.rahimov@example.com',
        country: "O'zbekiston",
        region: 'Toshkent shahri',
        district: 'Chilonzor tumani',
        role: 'parent',
        familyId: 'family_101',
        emergencyPhone: '+998909876543',
        createdAt: DateTime.now(),
      ),
      UserModel(
        id: 'child_demo_id',
        firstName: 'Jasur',
        lastName: 'Rahimov',
        age: 12,
        gender: 'Erkak',
        documentNumber: 'I-TN 8765432',
        phone: '+998935554433',
        email: 'jasur2014@gmail.com',
        country: "O'zbekiston",
        region: 'Toshkent shahri',
        district: 'Chilonzor tumani',
        role: 'child',
        familyId: 'family_101',
        childPinCode: '1234',
        emergencyPhone: '+998901234567',
        createdAt: DateTime.now(),
      ),
    ]);

    _demoTasks.addAll([
      TaskModel(
        id: 't1',
        familyId: 'family_101',
        title: 'Non va sut sotib olish',
        description: 'Do\'kondan yangi tandir non va 2 litr sut',
        assignedToName: 'Jasur Rahimov',
        dueDate: DateTime.now().add(const Duration(hours: 2)),
        priority: 'medium',
        isCompleted: false,
        createdBy: 'parent_demo_id',
      ),
      TaskModel(
        id: 't2',
        familyId: 'family_101',
        title: 'Ukani kursdan olib kelish',
        description: 'Ingliz tili markazidan soat 18:00 da',
        assignedToName: 'Aziz Rahimov',
        dueDate: DateTime.now().add(const Duration(hours: 5)),
        priority: 'high',
        isCompleted: false,
        createdBy: 'parent_demo_id',
      ),
    ]);

    _demoShoppingItems.addAll([
      ShoppingItemModel(
        id: 's1',
        familyId: 'family_101',
        name: 'Tuxum (1 katak)',
        quantity: 1,
        unit: 'paket',
        estimatedPrice: 35000,
        isPurchased: false,
        addedByName: 'Ona',
        addedAt: DateTime.now().subtract(const Duration(hours: 3)),
      ),
    ]);

    _demoBills.addAll([
      BillModel(
        id: 'b1',
        familyId: 'family_101',
        title: 'Optik Internet (Uzonline)',
        amount: 150000,
        dueDate: DateTime.now().add(const Duration(days: 2)),
        category: 'Internet',
        status: 'pending',
        updatedAt: DateTime.now(),
      ),
    ]);

    _demoExpenses.addAll([
      ExpenseModel(
        id: 'e1',
        familyId: 'family_101',
        title: 'Bozorlik va oziq-ovqat',
        amount: 320000,
        date: DateTime.now().subtract(const Duration(days: 1)),
        category: 'Oziq-ovqat',
        paidByName: 'Aziz',
      ),
    ]);

    _demoGrades.addAll([
      GradeModel(
        id: 'g1',
        familyId: 'family_101',
        childId: 'child_demo_id',
        childName: 'Jasur Rahimov',
        subject: 'Matematika',
        score: 5.0,
        maxScore: 5.0,
        gradingScale: '5_scale',
        examType: 'Nazorat ishi',
        teacherNote: 'Mavzuni a\'lo darajada o\'zlashtirgan!',
        examDate: DateTime.now().subtract(const Duration(days: 2)),
        createdAt: DateTime.now(),
      ),
    ]);

    _demoScreenTimes.add(
      ScreenTimeModel(
        id: 'st1',
        childId: 'child_demo_id',
        childName: 'Jasur Rahimov',
        familyId: 'family_101',
        date: DateTime.now(),
        totalMinutes: 145,
        dailyGoalMinutes: 120,
        permissionsGranted: true,
        updatedAt: DateTime.now(),
        appUsages: [
          AppUsageItem(appName: 'Duolingo (Ta\'lim)', packageName: 'com.duolingo', usageMinutes: 45, category: 'education'),
          AppUsageItem(appName: 'YouTube Video', packageName: 'com.google.android.youtube', usageMinutes: 60, category: 'video'),
          AppUsageItem(appName: 'Telegram Messenger', packageName: 'org.telegram.messenger', usageMinutes: 25, category: 'social'),
        ],
      ),
    );

    _demoLocations.addAll([
      LocationUpdateModel(
        userId: 'child_demo_id',
        familyId: 'family_101',
        userName: 'Jasur (Maktabda)',
        latitude: 41.314200,
        longitude: 69.248100,
        batteryLevel: 64,
        updatedAt: DateTime.now().subtract(const Duration(minutes: 8)),
      ),
    ]);

    // Tibbiy Pasport namunalari
    _demoMedicalPassports.add(
      MedicalPassportModel(
        id: 'med_child_1',
        familyId: 'family_101',
        childId: 'child_demo_id',
        childName: 'Jasur Rahimov',
        bloodGroup: 'II (A+)',
        allergies: ['Penitsillin', 'Yong\'oq'],
        chronicIllnesses: ['Mavsumiy allergik rinit'],
        familyDoctorName: 'Dr. Karimov Shavkat',
        familyDoctorPhone: '+998901112233',
        notes: 'Sport mashg\'ulotlariga ruxsat berilgan.',
        updatedAt: DateTime.now(),
        vaccinations: [
          VaccinationRecord(name: 'BCG (Silga qarshi)', date: DateTime(2014, 5, 10), isCompleted: true),
          VaccinationRecord(name: 'Gepatit B (3-doza)', date: DateTime(2015, 2, 14), isCompleted: true),
          VaccinationRecord(name: 'Qizamiq va Parotit (MMR)', date: DateTime(2020, 6, 20), isCompleted: true),
        ],
      ),
    );

    // Geozonalar (Xavfsiz hududlar: Uy va Maktab)
    _demoGeofences.addAll([
      GeofenceZoneModel(
        id: 'geo_1',
        familyId: 'family_101',
        name: 'Uyimiz (Chilonzor)',
        address: 'Chilonzor 9-mavze, 12-uy',
        latitude: 41.285600,
        longitude: 69.203400,
        radiusMeters: 100,
        targetChildIds: ['child_demo_id'],
        notifyOnEntry: true,
        notifyOnExit: true,
        iconType: 'home',
      ),
      GeofenceZoneModel(
        id: 'geo_2',
        familyId: 'family_101',
        name: '178-sonli Umumta\'lim Maktabi',
        address: 'Muqimiy ko\'chasi, 45-maktab',
        latitude: 41.314200,
        longitude: 69.248100,
        radiusMeters: 150,
        targetChildIds: ['child_demo_id'],
        notifyOnEntry: true,
        notifyOnExit: true,
        iconType: 'school',
      ),
    ]);

    // Masofaviy Boshqaruv (Google Family Link kabi)
    _demoRemoteDevices['child_demo_id'] = RemoteDeviceControlModel(
      childId: 'child_demo_id',
      childName: 'Jasur Rahimov',
      familyId: 'family_101',
      isLocked: false,
      currentActiveApp: 'YouTube Video',
      activeAppDurationMinutes: 18,
      isScreenStreamActive: false,
      isAccessibilityGranted: true,
      isDeviceAdminGranted: true,
      batteryLevel: 64,
      lastHeartbeat: DateTime.now(),
    );

    // Boshlang'ich Mukofotlar do'koni
    _demoRewards.addAll([
      RewardItemModel(
        id: 'rew_1',
        title: 'Muzqaymoq & Shirinlik',
        category: 'treat',
        coinCost: 25,
        icon: 'icecream',
      ),
      RewardItemModel(
        id: 'rew_2',
        title: '1 Soat Qo\'shimcha O\'yin Vaqti',
        category: 'time',
        coinCost: 40,
        icon: 'gamepad',
      ),
      RewardItemModel(
        id: 'rew_3',
        title: 'Kinoga Borish (Oilaviy)',
        category: 'fun',
        coinCost: 80,
        icon: 'movie',
      ),
      RewardItemModel(
        id: 'rew_4',
        title: 'Yangi Kitoblar To\'plami',
        category: 'gift',
        coinCost: 60,
        icon: 'book',
        isApproved: true,
      ),
      RewardItemModel(
        id: 'rew_5',
        title: 'Sport Velosipedi (Bosh Orzu)',
        category: 'gift',
        coinCost: 350,
        icon: 'pedal_bike',
      ),
    ]);

    // Boshlang'ich Ilova Cheklovlari (App Whitelist & Blacklist)
    _demoAppRules.addAll([
      AppRuleModel(
        packageName: 'com.zhiliaoapp.musically',
        appName: 'TikTok',
        category: 'social',
        dailyLimitMinutes: 15,
        usedMinutesToday: 20,
        isBlocked: true,
        iconKey: 'tiktok',
      ),
      AppRuleModel(
        packageName: 'com.tencent.ig',
        appName: 'PUBG Mobile',
        category: 'game',
        dailyLimitMinutes: 30,
        usedMinutesToday: 30,
        isBlocked: true,
        iconKey: 'pubg',
      ),
      AppRuleModel(
        packageName: 'com.google.android.youtube',
        appName: 'YouTube',
        category: 'media',
        dailyLimitMinutes: 45,
        usedMinutesToday: 35,
        isBlocked: false,
        iconKey: 'youtube',
      ),
      AppRuleModel(
        packageName: 'com.instagram.android',
        appName: 'Instagram',
        category: 'social',
        dailyLimitMinutes: 20,
        usedMinutesToday: 12,
        isBlocked: false,
        iconKey: 'instagram',
      ),
      AppRuleModel(
        packageName: 'org.telegram.messenger',
        appName: 'Telegram',
        category: 'social',
        dailyLimitMinutes: 0,
        usedMinutesToday: 28,
        isAlwaysAllowed: true,
        iconKey: 'telegram',
      ),
      AppRuleModel(
        packageName: 'com.duolingo',
        appName: 'Duolingo (Ingliz tili)',
        category: 'education',
        dailyLimitMinutes: 0,
        usedMinutesToday: 25,
        isAlwaysAllowed: true,
        iconKey: 'duolingo',
      ),
      AppRuleModel(
        packageName: 'com.kundalik.mobile',
        appName: 'Kundalik.com',
        category: 'education',
        dailyLimitMinutes: 0,
        usedMinutesToday: 10,
        isAlwaysAllowed: true,
        iconKey: 'kundalik',
      ),
    ]);

    // Boshlang'ich Birga AI xabarlari
    _demoAIChat.addAll([
      AIMessageModel(
        id: 'ai_1',
        text: 'Salom! Men "Birga AI" aqlli yordamchisiman 🤖. Farzandingiz darslarida repetitorlik qilishim yoki ota-onalik bo\'yicha psixologik tavsiyalar berishim mumkin. Qanday savolingiz bor?',
        role: AIMessageRole.assistant,
        category: 'general',
        timestamp: DateTime.now().subtract(const Duration(minutes: 5)),
        suggestedFollowUps: [
          'Bolam dars qilishni xohlamayapti, nima qilay?',
          '5-sinf matematika kasrlar mavzusini tushuntir',
          'Telefonga bog\'lanib qolishni qanday kamaytirish mumkin?',
        ],
      ),
    ]);
  }

  // --- MASOFAVIY BOSHQARUV METODLARI ---
  RemoteDeviceControlModel? getRemoteDevice(String childId) {
    return _demoRemoteDevices[childId];
  }

  Future<void> toggleDeviceLock(String childId, bool lock, {String reason = "Ota-ona cheklovi"}) async {
    final device = _demoRemoteDevices[childId];
    if (device != null) {
      _demoRemoteDevices[childId] = device.copyWith(
        isLocked: lock,
        lockReason: lock ? reason : null,
      );
      notifyListeners();
    }
  }

  Future<void> toggleScreenStream(String childId, bool stream) async {
    final device = _demoRemoteDevices[childId];
    if (device != null) {
      _demoRemoteDevices[childId] = device.copyWith(
        isScreenStreamActive: stream,
      );
      notifyListeners();
    }
  }

  // --- TIBBIY PASPORT METODLARI ---
  MedicalPassportModel? getMedicalPassport(String childId) {
    try {
      return _demoMedicalPassports.firstWhere((m) => m.childId == childId);
    } catch (_) {
      return null;
    }
  }

  Future<void> saveMedicalPassport(MedicalPassportModel passport) async {
    final index = _demoMedicalPassports.indexWhere((m) => m.childId == passport.childId);
    if (index != -1) {
      _demoMedicalPassports[index] = passport;
    } else {
      _demoMedicalPassports.add(passport);
    }
    notifyListeners();
  }

  // --- GEOZONALAR METODLARI ---
  List<GeofenceZoneModel> getGeofences(String familyId) => _demoGeofences;

  Future<void> addGeofence(GeofenceZoneModel zone) async {
    _demoGeofences.add(zone);
    notifyListeners();
  }

  // --- OILA VA QOLGAN METODLAR ---
  List<UserModel> getFamilyMembers(String familyId) => _demoMembers;
  List<TaskModel> getTasks(String familyId) => _demoTasks;
  List<ShoppingItemModel> getShoppingItems(String familyId) => _demoShoppingItems;
  List<BillModel> getBills(String familyId) => _demoBills;
  List<ExpenseModel> getExpenses(String familyId) => _demoExpenses;
  List<GradeModel> getGrades(String familyId) => _demoGrades;
  List<ScreenTimeModel> getScreenTimes(String familyId) => _demoScreenTimes;
  List<LocationUpdateModel> getLocations(String familyId) => _demoLocations;

  Future<void> addTask(TaskModel task) async {
    _demoTasks.insert(0, task);
    notifyListeners();
  }

  Future<void> toggleTaskStatus(String taskId) async {
    final index = _demoTasks.indexWhere((t) => t.id == taskId);
    if (index != -1) {
      final current = _demoTasks[index];
      _demoTasks[index] = current.copyWith(isCompleted: !current.isCompleted);
      notifyListeners();
    }
  }

  Future<void> addShoppingItem(ShoppingItemModel item) async {
    _demoShoppingItems.insert(0, item);
    notifyListeners();
  }

  Future<void> toggleShoppingItem(String itemId) async {
    final index = _demoShoppingItems.indexWhere((s) => s.id == itemId);
    if (index != -1) {
      final current = _demoShoppingItems[index];
      _demoShoppingItems[index] = current.copyWith(isPurchased: !current.isPurchased);
      notifyListeners();
    }
  }

  Future<void> addBill(BillModel bill) async {
    _demoBills.insert(0, bill);
    notifyListeners();
  }

  Future<void> markBillAsPaid(String billId) async {
    final index = _demoBills.indexWhere((b) => b.id == billId);
    if (index != -1) {
      _demoBills[index] = _demoBills[index].copyWith(status: 'paid');
      notifyListeners();
    }
  }

  Future<void> updateScreenTimeLimit(String childId, int newGoalMinutes) async {
    final index = _demoScreenTimes.indexWhere((st) => st.childId == childId);
    if (index != -1) {
      final current = _demoScreenTimes[index];
      _demoScreenTimes[index] = ScreenTimeModel(
        id: current.id,
        childId: current.childId,
        childName: current.childName,
        familyId: current.familyId,
        date: current.date,
        totalMinutes: current.totalMinutes,
        dailyGoalMinutes: newGoalMinutes,
        appUsages: current.appUsages,
        permissionsGranted: current.permissionsGranted,
        updatedAt: DateTime.now(),
      );
      notifyListeners();
    }
  }

  Future<FamilyModel> createFamily(String name, String createdBy) async {
    final newFam = FamilyModel(
      id: 'family_${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      inviteCode: 'BRG${Random().nextInt(900) + 100}',
      createdBy: createdBy,
      memberIds: [createdBy],
      createdAt: DateTime.now(),
    );
    _currentFamily = newFam;
    notifyListeners();
    return newFam;
  }

  Future<FamilyModel?> joinFamilyByCode(String inviteCode, dynamic user) async {
    final userId = user is UserModel ? user.id : user.toString();
    if (_currentFamily != null) {
      if (!_currentFamily!.memberIds.contains(userId)) {
        _currentFamily!.memberIds.add(userId);
      }
      if (user is UserModel && !_demoMembers.any((m) => m.id == user.id)) {
        _demoMembers.add(user);
      }
      notifyListeners();
      return _currentFamily;
    }
    return null;
  }

  Future<void> addChildMember({required String familyId, required String childName, required String pinCode}) async {
    final newChild = UserModel(
      id: 'child_${DateTime.now().millisecondsSinceEpoch}',
      firstName: childName,
      lastName: '',
      age: 10,
      gender: 'Noma\'lum',
      documentNumber: '',
      phone: '',
      email: '',
      country: "O'zbekiston",
      region: '',
      district: '',
      role: 'child',
      familyId: familyId,
      childPinCode: pinCode,
      createdAt: DateTime.now(),
    );
    _demoMembers.add(newChild);
    if (_currentFamily != null && !_currentFamily!.memberIds.contains(newChild.id)) {
      _currentFamily!.memberIds.add(newChild.id);
    }
    notifyListeners();
  }

  Future<void> addGrade(GradeModel grade) async {
    _demoGrades.insert(0, grade);
    notifyListeners();
  }

  Future<void> addExpense(ExpenseModel expense) async {
    _demoExpenses.insert(0, expense);
    notifyListeners();
  }

  Future<void> updateMyLocation(LocationUpdateModel loc) async {
    final index = _demoLocations.indexWhere((l) => l.userId == loc.userId);
    if (index != -1) {
      _demoLocations[index] = loc;
    } else {
      _demoLocations.insert(0, loc);
    }
    notifyListeners();
  }

  // --- MUKOFOTLAR VA TANGALAR ---
  List<RewardItemModel> getRewards() => _demoRewards;
  ChildCoinProfile getChildCoins() => _childCoinProfile;

  Future<void> requestReward(String rewardId, String childName) async {
    final idx = _demoRewards.indexWhere((r) => r.id == rewardId);
    if (idx != -1) {
      _demoRewards[idx] = _demoRewards[idx].copyWith(
        requestedBy: childName,
        requestedAt: DateTime.now(),
      );
      notifyListeners();
    }
  }

  Future<void> approveReward(String rewardId) async {
    final idx = _demoRewards.indexWhere((r) => r.id == rewardId);
    if (idx != -1) {
      final item = _demoRewards[idx];
      if (_childCoinProfile.totalCoins >= item.coinCost) {
        _childCoinProfile = _childCoinProfile.copyWith(
          totalCoins: _childCoinProfile.totalCoins - item.coinCost,
        );
        _demoRewards[idx] = item.copyWith(isApproved: true, isRedeemed: true);
        notifyListeners();
      }
    }
  }

  Future<void> addCoinsToChild(int amount, String reason) async {
    _childCoinProfile = _childCoinProfile.copyWith(
      totalCoins: _childCoinProfile.totalCoins + amount,
      weeklyEarned: _childCoinProfile.weeklyEarned + amount,
    );
    notifyListeners();
  }

  // --- ILOVA CHEKLOVLARI VA TUNGI REJIM ---
  List<AppRuleModel> getAppRules() => _demoAppRules;

  Future<void> toggleAppBlock(String packageName, bool block) async {
    final idx = _demoAppRules.indexWhere((a) => a.packageName == packageName);
    if (idx != -1) {
      _demoAppRules[idx] = _demoAppRules[idx].copyWith(isBlocked: block);
      notifyListeners();
    }
  }

  Future<void> updateAppLimit(String packageName, int minutes) async {
    final idx = _demoAppRules.indexWhere((a) => a.packageName == packageName);
    if (idx != -1) {
      _demoAppRules[idx] = _demoAppRules[idx].copyWith(dailyLimitMinutes: minutes);
      notifyListeners();
    }
  }

  BedtimeScheduleModel getBedtimeSchedule() => _bedtimeSchedule;

  Future<void> updateBedtimeSchedule(BedtimeScheduleModel schedule) async {
    _bedtimeSchedule = schedule;
    notifyListeners();
  }

  // --- SOS VA SIRENA ---
  bool get isEmergencySirenActive => _isEmergencySirenActive;
  bool get isChildSOSActive => _isChildSOSActive;

  Future<void> toggleEmergencySiren(bool active) async {
    _isEmergencySirenActive = active;
    notifyListeners();
  }

  Future<void> triggerChildSOS(bool active) async {
    _isChildSOSActive = active;
    notifyListeners();
  }

  // --- BIRGA AI CHAT ---
  List<AIMessageModel> getAIChat() => _demoAIChat;

  Future<void> sendAIMessage(String text, String category) async {
    final userMsg = AIMessageModel(
      id: 'msg_${DateTime.now().millisecondsSinceEpoch}',
      text: text,
      role: AIMessageRole.user,
      category: category,
      timestamp: DateTime.now(),
    );
    _demoAIChat.add(userMsg);
    notifyListeners();

    // AI Aqlli javob logikasi
    String responseText = "";
    List<String> followUps = [];

    final lower = text.toLowerCase();
    if (lower.contains('dars') || lower.contains('xohlamayapti') || lower.contains('dangasa')) {
      responseText = "Farzandingiz dars qilishni istamayotgan bo'lsa, quyidagi usullarni sinab ko'ring:\n1. 25/5 Pomodoro texnikasi: 25 daqiqa dars, 5 daqiqa dam olish.\n2. Birga ilovasida 'Birga Coins' tizimi orqali har bir bajarilgan vazifaga +10 tanga berishni taklif qiling.\n3. Dars joyini qulay va telefonsiz muhitga aylantiring.";
      followUps = ["Qanday mukofot qo'yish kerak?", "Farzand bilan qanday suhbatlashish lozim?"];
    } else if (lower.contains('kasr') || lower.contains('matematika')) {
      responseText = "Kasrlar mavzusini tushuntirish juda oson!\nMasalan, bitta pitsani tasavvur qiling 🍕. Uni 4 ta teng bo'lakka bo'lsangiz, har bir bo'lagi 1/4 (to'rtdan bir) qism bo'ladi. Agar 2 ta bo'lagini yesangiz (2/4), bu yarimta (1/2) pitsa degani!";
      followUps = ["Kasrlarni qo'shish qoidasi", "Kasrlarni ko'paytirish"];
    } else if (lower.contains('telefon') || lower.contains('ekran') || lower.contains('bog\'lanib')) {
      responseText = "Telefonga bog'liqlikni kamaytirish sirlari:\n1. Tungi rejimni yoqing — soat 22:00 da ekran avtomatik qulflansin.\n2. TikTok va o'yinlarga kunlik 30 daqiqa chegara qo'ying.\n3. Telefon o'rniga oilaviy stol o'yinlari yoki velosiped haydashni taklif qiling.";
      followUps = ["Ilova cheklovlarini yoqish", "Tungi uyqu jadvalini sozlash"];
    } else {
      responseText = "Savolingiz uchun rahmat! Men 'Birga AI' sifatida oilangiz tinchligi, farzandlaringiz ta'limi va xavfsizligi bo'yicha har doim yordamga tayyorman. Yana qanday mavzuda yordam beray?";
      followUps = ["Matematika darsida yordam", "Sog'lom ovqatlanish ratsioni", "O'yin vaqtini cheklash"];
    }

    final aiMsg = AIMessageModel(
      id: 'ai_${DateTime.now().millisecondsSinceEpoch}',
      text: responseText,
      role: AIMessageRole.assistant,
      category: category,
      timestamp: DateTime.now(),
      suggestedFollowUps: followUps,
    );
    _demoAIChat.add(aiMsg);
    notifyListeners();
  }
}
