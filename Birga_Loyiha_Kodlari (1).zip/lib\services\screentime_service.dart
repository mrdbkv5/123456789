import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import '../models/screen_time_model.dart';
import 'firestore_service.dart';

class ScreenTimeService extends ChangeNotifier {
  final FirestoreService _firestoreService;
  static const MethodChannel _channel = MethodChannel('com.birga.app/screentime');

  bool _isPermissionGranted = true; // In production this is checked via MethodChannel
  bool get isPermissionGranted => _isPermissionGranted;

  ScreenTimeService(this._firestoreService);

  /// Android va iOS qurilmalarda ruxsat so'rash
  Future<bool> requestUsagePermission() async {
    try {
      final bool granted = await _channel.invokeMethod('requestUsageStatsPermission');
      _isPermissionGranted = granted;
      notifyListeners();
      return granted;
    } on PlatformException catch (e) {
      debugPrint("ScreenTime permission platform exception: $e");
      // Fallback: Foydalanuvchiga tizim sozlamalariga havola ko'rsatiladi
      return _isPermissionGranted;
    }
  }

  /// Haqiqiy ma'lumotlarni yig'ish va serverga jo'natish
  Future<void> syncChildUsageStats({
    required String childId,
    required String childName,
    required String familyId,
  }) async {
    try {
      final List<dynamic>? results = await _channel.invokeMethod('getTodayAppUsage');
      if (results != null && results.isNotEmpty) {
        List<AppUsageItem> items = results.map((item) {
          final map = Map<String, dynamic>.from(item);
          return AppUsageItem(
            appName: map['appName'] ?? '',
            packageName: map['packageName'] ?? '',
            usageMinutes: (map['usageMinutes'] as num).toInt(),
            category: map['category'] ?? 'other',
          );
        }).toList();

        int totalMins = items.fold(0, (sum, i) => sum + i.usageMinutes);

        final model = ScreenTimeModel(
          id: 'st_${DateTime.now().millisecondsSinceEpoch}',
          childId: childId,
          childName: childName,
          familyId: familyId,
          date: DateTime.now(),
          totalMinutes: totalMins,
          dailyGoalMinutes: 120,
          appUsages: items,
          permissionsGranted: true,
          updatedAt: DateTime.now(),
        );

        // Firestore'ga saqlash
        // _firestoreService...
        notifyListeners();
      }
    } catch (e) {
      debugPrint("Sync usage error: $e");
    }
  }
}
