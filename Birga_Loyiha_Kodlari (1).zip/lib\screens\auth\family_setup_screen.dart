import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../home/main_shell_screen.dart';

class FamilySetupScreen extends StatefulWidget {
  const FamilySetupScreen({super.key});

  @override
  State<FamilySetupScreen> createState() => _FamilySetupScreenState();
}

class _FamilySetupScreenState extends State<FamilySetupScreen> {
  final _familyNameController = TextEditingController();
  final _joinCodeController = TextEditingController();
  bool _isCreatingNew = true;

  @override
  void dispose() {
    _familyNameController.dispose();
    _joinCodeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authService = context.watch<AuthService>();
    final firestoreService = context.watch<FirestoreService>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Oila sozlamasi'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Tanlov tugmalari
            Row(
              children: [
                Expanded(
                  child: ChoiceChip(
                    label: const Text('Yangi oila yaratish'),
                    selected: _isCreatingNew,
                    selectedColor: AppColors.primaryNavy,
                    labelStyle: TextStyle(
                      color: _isCreatingNew ? Colors.white : AppColors.primaryNavy,
                      fontWeight: FontWeight.bold,
                    ),
                    onSelected: (val) => setState(() => _isCreatingNew = true),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ChoiceChip(
                    label: const Text('Oilaga qo\'shilish'),
                    selected: !_isCreatingNew,
                    selectedColor: AppColors.primaryNavy,
                    labelStyle: TextStyle(
                      color: !_isCreatingNew ? Colors.white : AppColors.primaryNavy,
                      fontWeight: FontWeight.bold,
                    ),
                    onSelected: (val) => setState(() => _isCreatingNew = false),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),

            if (_isCreatingNew) ...[
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppColors.softBlueLight.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.shield_outlined, color: AppColors.primaryBlue),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Oila yaratuvchisi avtomatik tarzda oila administratori bo\'ladi.',
                        style: TextStyle(fontSize: 13, color: AppColors.primaryBlue),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              TextField(
                controller: _familyNameController,
                decoration: const InputDecoration(
                  labelText: 'Oilangiz nomi',
                  hintText: 'Masalan: Rahimovlar Oilasi',
                  prefixIcon: Icon(Icons.home_outlined),
                ),
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () async {
                  final name = _familyNameController.text.trim();
                  if (name.isEmpty) return;

                  final family = await firestoreService.createFamily(
                    name,
                    authService.currentUser?.id ?? 'parent_demo_id',
                  );
                  authService.updateFamilyId(family.id);

                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const MainShellScreen()),
                    (route) => false,
                  );
                },
                child: const Text('Oilani yaratish'),
              ),
            ] else ...[
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppColors.accentGreenLight.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.vpn_key_rounded, color: AppColors.accentGreen),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Oila a\'zongiz tomonidan berilgan 6 xonali taklif kodini kiriting.',
                        style: TextStyle(fontSize: 13, color: AppColors.primaryNavy),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              TextField(
                controller: _joinCodeController,
                textCapitalization: TextCapitalization.characters,
                maxLength: 6,
                decoration: const InputDecoration(
                  labelText: 'Taklif kodi (Invite code)',
                  hintText: 'Masalan: BRG842',
                  prefixIcon: Icon(Icons.qr_code_scanner_rounded),
                ),
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () async {
                  final code = _joinCodeController.text.trim();
                  if (code.isEmpty) return;

                  final family = await firestoreService.joinFamilyByCode(
                    code,
                    authService.currentUser!,
                  );
                  if (family != null) {
                    authService.updateFamilyId(family.id);
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const MainShellScreen()),
                      (route) => false,
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Kiritilgan kod bo\'yicha oila topilmadi!'),
                        backgroundColor: AppColors.danger,
                      ),
                    );
                  }
                },
                child: const Text('Kodni tasdiqlash va Qo\'shilish'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
