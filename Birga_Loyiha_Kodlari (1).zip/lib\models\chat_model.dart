class ChatModel {
  final String id;
  final String familyId;
  final bool isGroup; // true = Oilaviy guruh chati, false = shaxsiy chat
  final String name; // Masalan: "Oila Chati" yoki suhbatdosh ismi
  final List<String> memberIds;
  final Map<String, String> memberNames;
  final String? lastMessageText;
  final String? lastMessageSenderName;
  final DateTime? lastMessageTimestamp;
  final Map<String, int> unreadCounts; // {'userId': 2}

  ChatModel({
    required this.id,
    required this.familyId,
    required this.isGroup,
    required this.name,
    required this.memberIds,
    required this.memberNames,
    this.lastMessageText,
    this.lastMessageSenderName,
    this.lastMessageTimestamp,
    this.unreadCounts = const {},
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'familyId': familyId,
      'isGroup': isGroup,
      'name': name,
      'memberIds': memberIds,
      'memberNames': memberNames,
      'lastMessageText': lastMessageText,
      'lastMessageSenderName': lastMessageSenderName,
      'lastMessageTimestamp': lastMessageTimestamp?.toIso8601String(),
      'unreadCounts': unreadCounts,
    };
  }

  factory ChatModel.fromMap(Map<String, dynamic> map, String docId) {
    return ChatModel(
      id: docId,
      familyId: map['familyId'] ?? '',
      isGroup: map['isGroup'] ?? false,
      name: map['name'] ?? '',
      memberIds: List<String>.from(map['memberIds'] ?? []),
      memberNames: Map<String, String>.from(map['memberNames'] ?? {}),
      lastMessageText: map['lastMessageText'],
      lastMessageSenderName: map['lastMessageSenderName'],
      lastMessageTimestamp: map['lastMessageTimestamp'] != null
          ? DateTime.tryParse(map['lastMessageTimestamp'])
          : null,
      unreadCounts: Map<String, int>.from(map['unreadCounts'] ?? {}),
    );
  }
}
