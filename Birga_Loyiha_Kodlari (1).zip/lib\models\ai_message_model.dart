enum AIMessageRole { user, assistant, system }

class AIMessageModel {
  final String id;
  final String text;
  final AIMessageRole role;
  final String category; // 'tutor', 'parenting', 'health', 'general'
  final DateTime timestamp;
  final List<String>? suggestedFollowUps;

  AIMessageModel({
    required this.id,
    required this.text,
    required this.role,
    this.category = 'general',
    required this.timestamp,
    this.suggestedFollowUps,
  });
}
