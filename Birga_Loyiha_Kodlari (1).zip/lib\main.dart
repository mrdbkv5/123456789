import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'core/theme/app_theme.dart';
import 'services/auth_service.dart';
import 'services/firestore_service.dart';
import 'services/chat_service.dart';
import 'services/location_service.dart';
import 'services/screentime_service.dart';
import 'services/speech_service.dart';
import 'screens/auth/auth_selection_screen.dart';
import 'screens/home/main_shell_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // O'zbek tili sanalar formatini yuklash
  await initializeDateFormatting('uz', null);

  // Status bar rangini moslash
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );

  runApp(const BirgaApp());
}

class BirgaApp extends StatelessWidget {
  const BirgaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<AuthService>(create: (_) => AuthService()),
        ChangeNotifierProvider<FirestoreService>(create: (_) => FirestoreService()),
        ChangeNotifierProvider<ChatService>(create: (_) => ChatService()),
        ChangeNotifierProxyProvider<FirestoreService, LocationService>(
          create: (ctx) => LocationService(ctx.read<FirestoreService>()),
          update: (ctx, firestore, prev) => prev ?? LocationService(firestore),
        ),
        ChangeNotifierProxyProvider<FirestoreService, ScreenTimeService>(
          create: (ctx) => ScreenTimeService(ctx.read<FirestoreService>()),
          update: (ctx, firestore, prev) => prev ?? ScreenTimeService(firestore),
        ),
        ChangeNotifierProvider<SpeechService>(create: (_) => SpeechService()),
      ],
      child: Consumer<AuthService>(
        builder: (context, auth, _) {
          return MaterialApp(
            title: 'Birga',
            debugShowCheckedModeBanner: false,
            theme: AppTheme.lightTheme,
            darkTheme: AppTheme.darkTheme,
            themeMode: ThemeMode.system,
            home: auth.isAuthenticated ? const MainShellScreen() : const AuthSelectionScreen(),
          );
        },
      ),
    );
  }
}
