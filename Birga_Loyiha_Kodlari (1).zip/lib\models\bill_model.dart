class BillModel {
  final String id;
  final String familyId;
  final String title;
  final double amount;
  final DateTime dueDate;
  final String? assignedToName;
  final String recurrence; // 'none', 'monthly', 'yearly'
  final String status; // 'pending', 'paid', 'overdue'
  final String category; // 'Elektr', 'Gaz', 'Suv', 'Internet', etc.
  final DateTime updatedAt;

  BillModel({
    required this.id,
    required this.familyId,
    required this.title,
    required this.amount,
    required this.dueDate,
    this.assignedToName,
    this.recurrence = 'monthly',
    this.status = 'pending',
    required this.category,
    required this.updatedAt,
  });

  bool get isOverdue {
    if (status == 'paid') return false;
    return dueDate.isBefore(DateTime.now());
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'familyId': familyId,
      'title': title,
      'amount': amount,
      'dueDate': dueDate.toIso8601String(),
      'assignedToName': assignedToName,
      'recurrence': recurrence,
      'status': status,
      'category': category,
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory BillModel.fromMap(Map<String, dynamic> map, String docId) {
    return BillModel(
      id: docId,
      familyId: map['familyId'] ?? '',
      title: map['title'] ?? '',
      amount: (map['amount'] as num?)?.toDouble() ?? 0.0,
      dueDate: map['dueDate'] != null
          ? DateTime.tryParse(map['dueDate']) ?? DateTime.now()
          : DateTime.now(),
      assignedToName: map['assignedToName'],
      recurrence: map['recurrence'] ?? 'monthly',
      status: map['status'] ?? 'pending',
      category: map['category'] ?? 'Boshqa to\'lovlar',
      updatedAt: map['updatedAt'] != null
          ? DateTime.tryParse(map['updatedAt']) ?? DateTime.now()
          : DateTime.now(),
    );
  }

  BillModel copyWith({String? status}) {
    return BillModel(
      id: id,
      familyId: familyId,
      title: title,
      amount: amount,
      dueDate: dueDate,
      assignedToName: assignedToName,
      recurrence: recurrence,
      status: status ?? this.status,
      category: category,
      updatedAt: DateTime.now(),
    );
  }
}
