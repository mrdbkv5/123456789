import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../models/task_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import 'add_task_dialog.dart';
import 'voice_task_dialog.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  String _selectedFilter = 'all'; // 'all', 'today', 'pending', 'completed'

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final auth = context.watch<AuthService>();
    final familyId = auth.currentUser?.familyId ?? 'family_101';
    final allTasks = firestore.getTasks(familyId);

    // Filter tasks
    final tasks = allTasks.where((task) {
      if (_selectedFilter == 'pending') return !task.isCompleted;
      if (_selectedFilter == 'completed') return task.isCompleted;
      if (_selectedFilter == 'today') {
        final now = DateTime.now();
        return task.dueDate.year == now.year &&
            task.dueDate.month == now.month &&
            task.dueDate.day == now.day;
      }
      return true;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Oilaviy Vazifalar'),
        actions: [
          // Voice Task Button
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: AppColors.accentGreenLight,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.mic, color: AppColors.accentGreen, size: 20),
            ),
            tooltip: 'Ovoz orqali vazifa kiritish',
            onPressed: () {
              showDialog(
                context: context,
                builder: (_) => const VoiceTaskDialog(),
              );
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          // Filter Chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              children: [
                _buildFilterChip('all', 'Barchasi (${allTasks.length})'),
                const SizedBox(width: 8),
                _buildFilterChip('today', 'Bugungi'),
                const SizedBox(width: 8),
                _buildFilterChip('pending', 'Kutilmoqda'),
                const SizedBox(width: 8),
                _buildFilterChip('completed', 'Bajarilgan'),
              ],
            ),
          ),

          // Task List
          Expanded(
            child: tasks.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.assignment_turned_in_outlined, size: 64, color: Colors.grey.shade400),
                        const SizedBox(height: 12),
                        const Text(
                          'Hozircha vazifalar mavjud emas',
                          style: TextStyle(fontSize: 16, color: AppColors.textSecondaryLight),
                        ),
                        const SizedBox(height: 8),
                        TextButton.icon(
                          onPressed: () => _openAddTaskDialog(context),
                          icon: const Icon(Icons.add),
                          label: const Text('Yangi vazifa qo\'shish'),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    itemCount: tasks.length,
                    itemBuilder: (context, index) {
                      final task = tasks[index];
                      return _buildTaskCard(task, firestore);
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.primaryNavy,
        foregroundColor: Colors.white,
        onPressed: () => _openAddTaskDialog(context),
        icon: const Icon(Icons.add),
        label: const Text('Vazifa qo\'shish'),
      ),
    );
  }

  Widget _buildFilterChip(String filterKey, String label) {
    final isSelected = _selectedFilter == filterKey;
    return ChoiceChip(
      label: Text(label),
      selected: isSelected,
      selectedColor: AppColors.primaryNavy,
      labelStyle: TextStyle(
        color: isSelected ? Colors.white : AppColors.primaryNavy,
        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
      ),
      onSelected: (val) {
        if (val) setState(() => _selectedFilter = filterKey);
      },
    );
  }

  Widget _buildTaskCard(TaskModel task, FirestoreService firestore) {
    Color priorityColor = AppColors.priorityMedium;
    if (task.priority == 'high') priorityColor = AppColors.priorityHigh;
    if (task.priority == 'low') priorityColor = AppColors.priorityLow;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Transform.scale(
          scale: 1.2,
          child: Checkbox(
            activeColor: AppColors.accentGreen,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
            value: task.isCompleted,
            onChanged: (val) {
              firestore.toggleTaskStatus(task.id);
            },
          ),
        ),
        title: Text(
          task.title,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            decoration: task.isCompleted ? TextDecoration.lineThrough : null,
            color: task.isCompleted ? AppColors.textSecondaryLight : null,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (task.description != null && task.description!.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(task.description!, maxLines: 2, overflow: TextOverflow.ellipsis),
            ],
            const SizedBox(height: 6),
            Row(
              children: [
                Icon(
                  Icons.access_time_rounded,
                  size: 14,
                  color: task.isOverdue ? AppColors.danger : AppColors.textSecondaryLight,
                ),
                const SizedBox(width: 4),
                Text(
                  DateFormat('dd.MM HH:mm').format(task.dueDate),
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: task.isOverdue ? FontWeight.bold : FontWeight.normal,
                    color: task.isOverdue ? AppColors.danger : AppColors.textSecondaryLight,
                  ),
                ),
                if (task.assignedToName != null) ...[
                  const SizedBox(width: 12),
                  const Icon(Icons.person_outline, size: 14, color: AppColors.textSecondaryLight),
                  const SizedBox(width: 4),
                  Text(
                    task.assignedToName!,
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                  ),
                ],
              ],
            ),
          ],
        ),
        trailing: Container(
          width: 8,
          height: 36,
          decoration: BoxDecoration(
            color: priorityColor,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
      ),
    );
  }

  void _openAddTaskDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => const AddTaskDialog(),
    );
  }
}
