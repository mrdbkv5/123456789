import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../models/medical_passport_model.dart';
import '../../services/firestore_service.dart';

class MedicalPassportScreen extends StatelessWidget {
  final String childId;

  const MedicalPassportScreen({super.key, this.childId = 'child_demo_id'});

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final passport = firestore.getMedicalPassport(childId);

    if (passport == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Tibbiy Pasport')),
        body: const Center(child: Text('Tibbiy ma\'lumotlar kiritilmagan')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('${passport.childName} — Tibbiy Pasport'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Blood Group Card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF991B1B), Color(0xFFDC2626)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(
                  color: Colors.red.withOpacity(0.3),
                  blurRadius: 15,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: const Center(
                    child: Icon(Icons.bloodtype_rounded, color: Colors.white, size: 36),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Qon Guruhi va Rezus', style: TextStyle(color: Colors.white70, fontSize: 13)),
                      const SizedBox(height: 2),
                      Text(
                        passport.bloodGroup,
                        style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Yangilangan: ${DateFormat('dd.MM.yyyy').format(passport.updatedAt)}',
                        style: const TextStyle(color: Colors.white60, fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Allergies Card
          _buildInfoSection(
            title: 'Allergiyalar va Nojo‘ya Ta’sirlar',
            icon: Icons.warning_amber_rounded,
            iconColor: AppColors.warning,
            items: passport.allergies,
            badgeColor: const Color(0xFFFEF3C7),
            textColor: const Color(0xFFB45309),
          ),
          const SizedBox(height: 16),

          // Chronic Illnesses
          _buildInfoSection(
            title: 'Surunkali Xastaliklar va Nazorat',
            icon: Icons.healing_rounded,
            iconColor: AppColors.info,
            items: passport.chronicIllnesses,
            badgeColor: const Color(0xFFCFFAFE),
            textColor: const Color(0xFF0E7490),
          ),
          const SizedBox(height: 20),

          // Vaccinations (Emlashlar Kalendari)
          const Text(
            'Emlashlar va Vaksinalar Tarixi',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),

          ...passport.vaccinations.map((vac) {
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: AppColors.accentGreenLight,
                  child: const Icon(Icons.check_circle_rounded, color: AppColors.accentGreen),
                ),
                title: Text(vac.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('Sana: ${DateFormat('dd.MM.yyyy').format(vac.date)}'),
                trailing: const Chip(
                  label: Text('Qabul qilingan', style: TextStyle(fontSize: 11, color: AppColors.accentGreen)),
                ),
              ),
            );
          }),
          const SizedBox(height: 20),

          // Family Doctor Info Card
          if (passport.familyDoctorName != null) ...[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppColors.borderLight),
              ),
              child: Row(
                children: [
                  const CircleAvatar(
                    backgroundColor: AppColors.softBlueLight,
                    child: Icon(Icons.medical_services_rounded, color: AppColors.primaryBlue),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          passport.familyDoctorName!,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                        Text(
                          'Oila shifokori • ${passport.familyDoctorPhone ?? ""}',
                          style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.phone_in_talk_rounded, color: AppColors.accentGreen),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('${passport.familyDoctorName} ga qo\'ng\'iroq qilinmoqda...')),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoSection({
    required String title,
    required IconData icon,
    required Color iconColor,
    required List<String> items,
    required Color badgeColor,
    required Color textColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: iconColor, size: 20),
              const SizedBox(width: 8),
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: items.map((item) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: badgeColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  item,
                  style: TextStyle(color: textColor, fontWeight: FontWeight.bold, fontSize: 13),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
