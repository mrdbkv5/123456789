import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/chat_model.dart';
import '../models/message_model.dart';

class ChatService extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final List<ChatModel> _demoChats = [];
  final Map<String, List<MessageModel>> _demoMessages = {};

  List<ChatModel> get chats => _demoChats;

  ChatService() {
    _initDemoChats();
  }

  void _initDemoChats() {
    final familyChat = ChatModel(
      id: 'family_group_chat_1',
      familyId: 'family_101',
      isGroup: true,
      name: 'Rahimovlar Oilasi (Umumiy)',
      memberIds: ['parent_demo_id', 'child_demo_id'],
      memberNames: {
        'parent_demo_id': 'Aziz Rahimov',
        'child_demo_id': 'Jasur Rahimov',
      },
      lastMessageText: 'Non va sut oldingmi, o\'g\'lim?',
      lastMessageSenderName: 'Aziz Rahimov',
      lastMessageTimestamp: DateTime.now().subtract(const Duration(minutes: 15)),
      unreadCounts: {'child_demo_id': 1},
    );

    final directChat = ChatModel(
      id: 'direct_chat_parent_child',
      familyId: 'family_101',
      isGroup: false,
      name: 'Jasur (Farzand)',
      memberIds: ['parent_demo_id', 'child_demo_id'],
      memberNames: {
        'parent_demo_id': 'Aziz Rahimov',
        'child_demo_id': 'Jasur Rahimov',
      },
      lastMessageText: 'Ha ota, hozir yo\'ldaman, olib kelyapman.',
      lastMessageSenderName: 'Jasur Rahimov',
      lastMessageTimestamp: DateTime.now().subtract(const Duration(minutes: 5)),
      unreadCounts: {'parent_demo_id': 0},
    );

    _demoChats.addAll([familyChat, directChat]);

    _demoMessages['family_group_chat_1'] = [
      MessageModel(
        id: 'm1',
        chatId: 'family_group_chat_1',
        senderId: 'child_demo_id',
        senderName: 'Jasur Rahimov',
        text: 'Assalomu alaykum, darslarim tugadi!',
        timestamp: DateTime.now().subtract(const Duration(minutes: 45)),
        status: 'read',
      ),
      MessageModel(
        id: 'm2',
        chatId: 'family_group_chat_1',
        senderId: 'parent_demo_id',
        senderName: 'Aziz Rahimov',
        text: 'Va alaykum assalom! Uyga kelishda do\'konga kirib o\'tgin.',
        timestamp: DateTime.now().subtract(const Duration(minutes: 30)),
        status: 'read',
      ),
      MessageModel(
        id: 'm3',
        chatId: 'family_group_chat_1',
        senderId: 'parent_demo_id',
        senderName: 'Aziz Rahimov',
        text: 'Non va sut oldingmi, o\'g\'lim?',
        timestamp: DateTime.now().subtract(const Duration(minutes: 15)),
        status: 'sent',
      ),
    ];

    _demoMessages['direct_chat_parent_child'] = [
      MessageModel(
        id: 'dm1',
        chatId: 'direct_chat_parent_child',
        senderId: 'parent_demo_id',
        senderName: 'Aziz Rahimov',
        text: 'Jasur, matematika bahong yaxshi chiqibdi, barakalla!',
        timestamp: DateTime.now().subtract(const Duration(minutes: 20)),
        status: 'read',
      ),
      MessageModel(
        id: 'dm2',
        chatId: 'direct_chat_parent_child',
        senderId: 'child_demo_id',
        senderName: 'Jasur Rahimov',
        text: 'Rahmat ota! Hozir yo\'ldaman, olib kelyapman.',
        timestamp: DateTime.now().subtract(const Duration(minutes: 5)),
        status: 'read',
      ),
    ];
  }

  List<MessageModel> getMessagesForChat(String chatId) {
    return _demoMessages[chatId] ?? [];
  }

  Future<void> sendMessage({
    required String chatId,
    required String senderId,
    required String senderName,
    required String text,
    String type = 'text',
    String? mediaUrl,
    int? audioDurationSeconds,
  }) async {
    final msg = MessageModel(
      id: 'msg_${DateTime.now().millisecondsSinceEpoch}',
      chatId: chatId,
      senderId: senderId,
      senderName: senderName,
      text: text,
      type: type,
      mediaUrl: mediaUrl,
      audioDurationSeconds: audioDurationSeconds,
      status: 'sent',
      timestamp: DateTime.now(),
    );

    if (!_demoMessages.containsKey(chatId)) {
      _demoMessages[chatId] = [];
    }
    _demoMessages[chatId]!.add(msg);

    // Chatning oxirgi xabarini yangilash
    final chatIndex = _demoChats.indexWhere((c) => c.id == chatId);
    if (chatIndex != -1) {
      final currentChat = _demoChats[chatIndex];
      _demoChats[chatIndex] = ChatModel(
        id: currentChat.id,
        familyId: currentChat.familyId,
        isGroup: currentChat.isGroup,
        name: currentChat.name,
        memberIds: currentChat.memberIds,
        memberNames: currentChat.memberNames,
        lastMessageText: type == 'audio' ? '🎤 Ovozli xabar' : (type == 'image' ? '📷 Rasm' : text),
        lastMessageSenderName: senderName,
        lastMessageTimestamp: DateTime.now(),
        unreadCounts: currentChat.unreadCounts,
      );
    }

    try {
      await _firestore
          .collection('chats')
          .doc(chatId)
          .collection('messages')
          .doc(msg.id)
          .set(msg.toMap());
      await _firestore.collection('chats').doc(chatId).update({
        'lastMessageText': msg.text,
        'lastMessageSenderName': senderName,
        'lastMessageTimestamp': msg.timestamp.toIso8601String(),
      });
    } catch (e) {
      debugPrint("Firestore send message fallback: $e");
    }

    notifyListeners();
  }

  Future<void> markMessagesAsRead(String chatId, String userId) async {
    final chatIndex = _demoChats.indexWhere((c) => c.id == chatId);
    if (chatIndex != -1) {
      final chat = _demoChats[chatIndex];
      final unread = Map<String, int>.from(chat.unreadCounts);
      unread[userId] = 0;
      _demoChats[chatIndex] = ChatModel(
        id: chat.id,
        familyId: chat.familyId,
        isGroup: chat.isGroup,
        name: chat.name,
        memberIds: chat.memberIds,
        memberNames: chat.memberNames,
        lastMessageText: chat.lastMessageText,
        lastMessageSenderName: chat.lastMessageSenderName,
        lastMessageTimestamp: chat.lastMessageTimestamp,
        unreadCounts: unread,
      );
      notifyListeners();
    }
  }
}
