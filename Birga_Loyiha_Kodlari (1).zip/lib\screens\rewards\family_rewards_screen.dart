import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../models/reward_item_model.dart';
import '../../services/firestore_service.dart';
import '../../services/auth_service.dart';

class FamilyRewardsScreen extends StatelessWidget {
  const FamilyRewardsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final auth = context.watch<AuthService>();
    final isParent = auth.currentUser?.isParent ?? true;

    final coinsProfile = firestore.getChildCoins();
    final rewards = firestore.getRewards();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Birga Coins & Mukofotlar'),
        actions: [
          if (isParent)
            IconButton(
              icon: const Icon(Icons.add_circle_outline_rounded),
              tooltip: 'Tanga qo\'shish',
              onPressed: () => _showAddCoinsDialog(context, firestore),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Coins Hero Card
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFF59E0B), Color(0xFFD97706)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFF59E0B).withOpacity(0.35),
                  blurRadius: 18,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          coinsProfile.childName,
                          style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 2),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            'Daraja: ${coinsProfile.level} • Tirishqoq',
                            style: const TextStyle(color: Colors.white, fontSize: 11),
                          ),
                        ),
                      ],
                    ),
                    const CircleAvatar(
                      radius: 26,
                      backgroundColor: Colors.white24,
                      child: Icon(Icons.monetization_on_rounded, size: 34, color: Colors.white),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    Text(
                      '${coinsProfile.totalCoins}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 44,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'tanga',
                      style: TextStyle(color: Colors.white70, fontSize: 18, fontWeight: FontWeight.w600),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        'Haftada: +${coinsProfile.weeklyEarned} 🪙',
                        style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // QUICK HOW TO EARN (Motivatsiya qoidalari)
          const Text(
            'Qanday qilib tanga yig\'iladi?',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildEarningCard(context, '📚 Dars qilish', '+20 tanga', Icons.menu_book_rounded, Colors.blue),
                const SizedBox(width: 10),
                _buildEarningCard(context, '📖 Kitob o\'qish', '+15 tanga', Icons.auto_stories_rounded, Colors.purple),
                const SizedBox(width: 10),
                _buildEarningCard(context, '🧹 Uy tozalash', '+10 tanga', Icons.cleaning_services_rounded, Colors.teal),
                const SizedBox(width: 10),
                _buildEarningCard(context, '⭐ 5 baho olish', '+25 tanga', Icons.grade_rounded, Colors.amber),
              ],
            ),
          ),
          const SizedBox(height: 26),

          // REWARD STORE
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Mukofotlar Do\'koni & Orzular',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
              Text(
                '${rewards.length} ta mavjud',
                style: const TextStyle(color: AppColors.textSecondaryLight, fontSize: 13),
              ),
            ],
          ),
          const SizedBox(height: 12),

          ...rewards.map((reward) {
            final canAfford = coinsProfile.totalCoins >= reward.coinCost;
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: reward.isApproved ? AppColors.accentGreen.withOpacity(0.5) : AppColors.borderLight,
                  width: reward.isApproved ? 1.5 : 1,
                ),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 24,
                    backgroundColor: const Color(0xFFF59E0B).withOpacity(0.12),
                    child: Icon(_getIconData(reward.icon), color: const Color(0xFFD97706)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          reward.title,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const Icon(Icons.monetization_on_rounded, size: 14, color: Color(0xFFF59E0B)),
                            const SizedBox(width: 4),
                            Text(
                              '${reward.coinCost} tanga',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                                color: Color(0xFFD97706),
                              ),
                            ),
                            if (reward.isApproved) ...[
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppColors.accentGreen.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Text(
                                  '✓ Berilgan',
                                  style: TextStyle(fontSize: 10, color: AppColors.accentGreen, fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),

                  // Button for Child or Parent
                  if (isParent) ...[
                    if (!reward.isRedeemed)
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryNavy,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          minimumSize: const Size(80, 36),
                        ),
                        onPressed: canAfford ? () => firestore.approveReward(reward.id) : null,
                        child: const Text('Berish', style: TextStyle(fontSize: 12)),
                      )
                    else
                      const Icon(Icons.check_circle_rounded, color: AppColors.accentGreen, size: 28),
                  ] else ...[
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: canAfford ? const Color(0xFFF59E0B) : Colors.grey,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        minimumSize: const Size(90, 36),
                      ),
                      onPressed: canAfford
                          ? () {
                              firestore.requestReward(reward.id, coinsProfile.childName);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('${reward.title} uchun ota-onaga so\'rov yuborildi!'),
                                  backgroundColor: const Color(0xFFD97706),
                                ),
                              );
                            }
                          : null,
                      child: Text(canAfford ? 'So\'rash' : 'Yetarli emas', style: const TextStyle(fontSize: 12)),
                    ),
                  ],
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildEarningCard(BuildContext context, String title, String coins, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 16,
            backgroundColor: color.withOpacity(0.12),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              Text(coins, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }

  void _showAddCoinsDialog(BuildContext context, FirestoreService firestore) {
    final amountController = TextEditingController(text: '15');
    final reasonController = TextEditingController(text: 'Darslarni a\'lo bajargani uchun');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Farzandga Tanga Qo\'shish'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Tanga miqdori (masalan: 20)'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: reasonController,
              decoration: const InputDecoration(labelText: 'Sabab / Rag\'bat'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Bekor qilish')),
          ElevatedButton(
            onPressed: () {
              final amount = int.tryParse(amountController.text) ?? 10;
              firestore.addCoinsToChild(amount, reasonController.text);
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Farzandga +$amount tanga qo\'shildi!'),
                  backgroundColor: AppColors.accentGreen,
                ),
              );
            },
            child: const Text('Qo\'shish'),
          ),
        ],
      ),
    );
  }

  IconData _getIconData(String key) {
    switch (key) {
      case 'icecream':
        return Icons.icecream_rounded;
      case 'gamepad':
        return Icons.sports_esports_rounded;
      case 'movie':
        return Icons.movie_rounded;
      case 'book':
        return Icons.menu_book_rounded;
      case 'pedal_bike':
        return Icons.pedal_bike_rounded;
      default:
        return Icons.stars_rounded;
    }
  }
}
