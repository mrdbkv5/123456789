import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/location_update_model.dart';
import 'firestore_service.dart';

class LocationService extends ChangeNotifier {
  final FirestoreService _firestoreService;
  bool _isSharingEnabled = true;
  bool _hasPermission = false;
  Position? _currentPosition;

  bool get isSharingEnabled => _isSharingEnabled;
  bool get hasPermission => _hasPermission;
  Position? get currentPosition => _currentPosition;

  LocationService(this._firestoreService);

  Future<bool> checkAndRequestPermission() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return false;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        _hasPermission = false;
        notifyListeners();
        return false;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      _hasPermission = false;
      notifyListeners();
      return false;
    }

    _hasPermission = true;
    notifyListeners();
    return true;
  }

  Future<void> updateCurrentLocation({
    required String userId,
    required String familyId,
    required String userName,
    String? avatarUrl,
  }) async {
    if (!_isSharingEnabled) return;

    try {
      final hasPerm = await checkAndRequestPermission();
      if (hasPerm) {
        final pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
          timeLimit: const Duration(seconds: 10),
        );
        _currentPosition = pos;

        final update = LocationUpdateModel(
          userId: userId,
          familyId: familyId,
          userName: userName,
          avatarUrl: avatarUrl,
          latitude: pos.latitude,
          longitude: pos.longitude,
          accuracy: pos.accuracy,
          batteryLevel: 85,
          isSharingEnabled: true,
          isGpsEnabled: true,
          updatedAt: DateTime.now(),
        );

        await _firestoreService.updateMyLocation(update);
        notifyListeners();
      }
    } catch (e) {
      debugPrint("Update location error fallback: $e");
    }
  }

  void toggleLocationSharing(bool enabled) {
    _isSharingEnabled = enabled;
    notifyListeners();
  }
}
