class RemoteDeviceControlModel {
  final String childId;
  final String childName;
  final String familyId;
  final bool isLocked;
  final String? lockReason; // 'Dars vaqti', 'Uxlash vaqti', 'Ota-ona cheklovi'
  final String currentActiveApp; // Ayni daqiqada ochiq ilova (masalan: 'YouTube')
  final int activeAppDurationMinutes; // Shu ilovada necha daqiqa o'tirgani
  final bool isScreenStreamActive; // Jonli ekran uzatilishi holati
  final String? screenStreamUrl; // WebRTC yoki Live stream URL
  final bool isAccessibilityGranted; // Android Accessibility ruxsati faolmi
  final bool isDeviceAdminGranted;   // Android Device Admin ruxsati faolmi
  final int batteryLevel;
  final DateTime lastHeartbeat;

  RemoteDeviceControlModel({
    required this.childId,
    required this.childName,
    required this.familyId,
    this.isLocked = false,
    this.lockReason,
    this.currentActiveApp = 'Bosh ekran',
    this.activeAppDurationMinutes = 5,
    this.isScreenStreamActive = false,
    this.screenStreamUrl,
    this.isAccessibilityGranted = true,
    this.isDeviceAdminGranted = true,
    this.batteryLevel = 78,
    required this.lastHeartbeat,
  });

  Map<String, dynamic> toMap() {
    return {
      'childId': childId,
      'childName': childName,
      'familyId': familyId,
      'isLocked': isLocked,
      'lockReason': lockReason,
      'currentActiveApp': currentActiveApp,
      'activeAppDurationMinutes': activeAppDurationMinutes,
      'isScreenStreamActive': isScreenStreamActive,
      'screenStreamUrl': screenStreamUrl,
      'isAccessibilityGranted': isAccessibilityGranted,
      'isDeviceAdminGranted': isDeviceAdminGranted,
      'batteryLevel': batteryLevel,
      'lastHeartbeat': lastHeartbeat.toIso8601String(),
    };
  }

  factory RemoteDeviceControlModel.fromMap(Map<String, dynamic> map, String docId) {
    return RemoteDeviceControlModel(
      childId: docId,
      childName: map['childName'] ?? '',
      familyId: map['familyId'] ?? '',
      isLocked: map['isLocked'] ?? false,
      lockReason: map['lockReason'],
      currentActiveApp: map['currentActiveApp'] ?? 'Bosh ekran',
      activeAppDurationMinutes: (map['activeAppDurationMinutes'] as num?)?.toInt() ?? 0,
      isScreenStreamActive: map['isScreenStreamActive'] ?? false,
      screenStreamUrl: map['screenStreamUrl'],
      isAccessibilityGranted: map['isAccessibilityGranted'] ?? false,
      isDeviceAdminGranted: map['isDeviceAdminGranted'] ?? false,
      batteryLevel: (map['batteryLevel'] as num?)?.toInt() ?? 100,
      lastHeartbeat: map['lastHeartbeat'] != null
          ? DateTime.tryParse(map['lastHeartbeat']) ?? DateTime.now()
          : DateTime.now(),
    );
  }

  RemoteDeviceControlModel copyWith({
    bool? isLocked,
    String? lockReason,
    bool? isScreenStreamActive,
    String? currentActiveApp,
    int? activeAppDurationMinutes,
  }) {
    return RemoteDeviceControlModel(
      childId: childId,
      childName: childName,
      familyId: familyId,
      isLocked: isLocked ?? this.isLocked,
      lockReason: lockReason ?? this.lockReason,
      currentActiveApp: currentActiveApp ?? this.currentActiveApp,
      activeAppDurationMinutes: activeAppDurationMinutes ?? this.activeAppDurationMinutes,
      isScreenStreamActive: isScreenStreamActive ?? this.isScreenStreamActive,
      screenStreamUrl: screenStreamUrl,
      isAccessibilityGranted: isAccessibilityGranted,
      isDeviceAdminGranted: isDeviceAdminGranted,
      batteryLevel: batteryLevel,
      lastHeartbeat: DateTime.now(),
    );
  }
}
