class AppConstants {
  static const String appName = 'Birga';
  static const String appMotto = 'Oilangizning barcha ishlari — bir joyda.';

  // User Roles
  static const String roleParent = 'parent';
  static const String roleChild = 'child';
  static const String roleMember = 'member';

  // Task Priorities
  static const String priorityLow = 'low';
  static const String priorityMedium = 'medium';
  static const String priorityHigh = 'high';

  // Task Statuses
  static const String taskPending = 'pending';
  static const String taskCompleted = 'completed';

  // Bill Statuses
  static const String billPending = 'pending';
  static const String billPaid = 'paid';
  static const String billOverdue = 'overdue';

  // Bill Categories
  static const List<String> billCategories = [
    'Elektr energiyasi',
    'Gaz',
    'Suv',
    'Internet',
    'Telefon',
    'Ijara',
    'Ta\'lim',
    'Boshqa to\'lovlar',
  ];

  // Expense Categories
  static const List<String> expenseCategories = [
    'Oziq-ovqat',
    'Transport',
    'Kommunal xizmatlar',
    'Ta\'lim',
    'Sog\'liq',
    'Kiyim-kechak',
    'Ko\'ngilochar',
    'Boshqa xarajatlar',
  ];

  // Grade Systems
  static const String gradeSystem5 = '5_scale';
  static const String gradeSystem100 = '100_scale';

  // Message Types
  static const String msgText = 'text';
  static const String msgImage = 'image';
  static const String msgAudio = 'audio';
  static const String msgFile = 'file';

  // Message Statuses
  static const String msgSending = 'sending';
  static const String msgSent = 'sent';
  static const String msgDelivered = 'delivered';
  static const String msgRead = 'read';
  static const String msgFailed = 'failed';
}
