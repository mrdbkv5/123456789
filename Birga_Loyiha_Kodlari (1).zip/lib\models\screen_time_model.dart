class AppUsageItem {
  final String appName;
  final String packageName;
  final int usageMinutes;
  final String category; // 'video', 'game', 'education', 'social', 'other'

  AppUsageItem({
    required this.appName,
    required this.packageName,
    required this.usageMinutes,
    this.category = 'other',
  });

  Map<String, dynamic> toMap() {
    return {
      'appName': appName,
      'packageName': packageName,
      'usageMinutes': usageMinutes,
      'category': category,
    };
  }

  factory AppUsageItem.fromMap(Map<String, dynamic> map) {
    return AppUsageItem(
      appName: map['appName'] ?? '',
      packageName: map['packageName'] ?? '',
      usageMinutes: (map['usageMinutes'] as num?)?.toInt() ?? 0,
      category: map['category'] ?? 'other',
    );
  }
}

class ScreenTimeModel {
  final String id;
  final String childId;
  final String childName;
  final String familyId;
  final DateTime date;
  final int totalMinutes;
  final int dailyGoalMinutes; // Masalan: 120 minut (2 soat)
  final List<AppUsageItem> appUsages;
  final bool permissionsGranted;
  final DateTime updatedAt;

  ScreenTimeModel({
    required this.id,
    required this.childId,
    required this.childName,
    required this.familyId,
    required this.date,
    required this.totalMinutes,
    this.dailyGoalMinutes = 120,
    required this.appUsages,
    this.permissionsGranted = true,
    required this.updatedAt,
  });

  bool get isLimitExceeded => totalMinutes > dailyGoalMinutes;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'childId': childId,
      'childName': childName,
      'familyId': familyId,
      'date': date.toIso8601String(),
      'totalMinutes': totalMinutes,
      'dailyGoalMinutes': dailyGoalMinutes,
      'appUsages': appUsages.map((e) => e.toMap()).toList(),
      'permissionsGranted': permissionsGranted,
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory ScreenTimeModel.fromMap(Map<String, dynamic> map, String docId) {
    return ScreenTimeModel(
      id: docId,
      childId: map['childId'] ?? '',
      childName: map['childName'] ?? '',
      familyId: map['familyId'] ?? '',
      date: map['date'] != null
          ? DateTime.tryParse(map['date']) ?? DateTime.now()
          : DateTime.now(),
      totalMinutes: (map['totalMinutes'] as num?)?.toInt() ?? 0,
      dailyGoalMinutes: (map['dailyGoalMinutes'] as num?)?.toInt() ?? 120,
      appUsages: (map['appUsages'] as List<dynamic>?)
              ?.map((item) => AppUsageItem.fromMap(Map<String, dynamic>.from(item)))
              .toList() ??
          [],
      permissionsGranted: map['permissionsGranted'] ?? false,
      updatedAt: map['updatedAt'] != null
          ? DateTime.tryParse(map['updatedAt']) ?? DateTime.now()
          : DateTime.now(),
    );
  }
}
