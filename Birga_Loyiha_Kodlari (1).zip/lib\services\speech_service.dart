import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import '../core/utils/speech_task_parser.dart';

class SpeechService extends ChangeNotifier {
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isListening = false;
  String _lastWords = '';
  ParsedVoiceTask? _parsedTask;

  bool get isListening => _isListening;
  String get lastWords => _lastWords;
  ParsedVoiceTask? get parsedTask => _parsedTask;

  Future<bool> initSpeech() async {
    try {
      bool available = await _speech.initialize(
        onError: (val) => debugPrint('Speech error: $val'),
        onStatus: (val) {
          if (val == 'done' || val == 'notListening') {
            _isListening = false;
            notifyListeners();
          }
        },
      );
      return available;
    } catch (e) {
      debugPrint("Speech init fallback: $e");
      return false;
    }
  }

  Future<void> startListening({Function(String words)? onResult}) async {
    _lastWords = '';
    _parsedTask = null;
    
    bool available = await _speech.initialize();
    if (available) {
      _isListening = true;
      notifyListeners();
      _speech.listen(
        localeId: 'uz_UZ', // O'zbek tili
        onResult: (val) {
          _lastWords = val.recognizedWords;
          if (_lastWords.isNotEmpty) {
            _parsedTask = SpeechTaskParser.parseUzbekSentence(_lastWords);
          }
          if (onResult != null) {
            onResult(_lastWords);
          }
          notifyListeners();
        },
      );
    } else {
      // Mock / Simulyatsiya testi (Agar emulator yoki mikrofonsiz bo'lsa)
      _isListening = true;
      notifyListeners();
      await Future.delayed(const Duration(seconds: 1));
      _lastWords = "Ertaga soat beshda ukamni kursdan olib kelishim kerak";
      _parsedTask = SpeechTaskParser.parseUzbekSentence(_lastWords);
      _isListening = false;
      notifyListeners();
    }
  }

  Future<void> stopListening() async {
    await _speech.stop();
    _isListening = false;
    if (_lastWords.isNotEmpty) {
      _parsedTask = SpeechTaskParser.parseUzbekSentence(_lastWords);
    }
    notifyListeners();
  }

  void reset() {
    _lastWords = '';
    _parsedTask = null;
    _isListening = false;
    notifyListeners();
  }
}
