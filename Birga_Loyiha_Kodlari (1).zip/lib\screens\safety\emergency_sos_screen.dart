import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../services/firestore_service.dart';
import '../../services/auth_service.dart';

class EmergencySosScreen extends StatefulWidget {
  const EmergencySosScreen({super.key});

  @override
  State<EmergencySosScreen> createState() => _EmergencySosScreenState();
}

class _EmergencySosScreenState extends State<EmergencySosScreen> {
  bool _isSosTriggered = false;

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final auth = context.watch<AuthService>();
    final isParent = auth.currentUser?.isParent ?? true;
    final isSirenActive = firestore.isEmergencySirenActive;
    final isChildSosActive = firestore.isChildSOSActive;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Favqulodda Xavfsizlik & SOS'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Banner for Parent or Child
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isChildSosActive || isSirenActive
                    ? [const Color(0xFFEF4444), const Color(0xFFB91C1C)]
                    : [const Color(0xFF1E293B), const Color(0xFF0F172A)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: (isChildSosActive || isSirenActive ? Colors.red : Colors.black).withOpacity(0.3),
                  blurRadius: 16,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              children: [
                Icon(
                  isChildSosActive || isSirenActive ? Icons.warning_amber_rounded : Icons.shield_rounded,
                  size: 64,
                  color: Colors.white,
                ),
                const SizedBox(height: 12),
                Text(
                  isChildSosActive
                      ? 'DIQQAT: Farzand SOS Signali Faollashdi!'
                      : (isSirenActive ? 'Masofaviy Sirena Ishlamoqda!' : 'Oilaviy Xavfsizlik Tizimi Faol'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  isParent
                      ? 'Farzand telefonini masofadan boshqarish, baland signal chalish va joylashuvni zudlik bilan aniqlash.'
                      : 'Xavf tug\'ilganda tugmani bosing — ota-onangizga darhol xarita va signal yuboriladi.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // LOUD SIREN CONTROLLER (For Parents)
          if (isParent) ...[
            const Text(
              'Masofaviy Ovozli Sirena (Farzand Qidiruvi)',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.borderLight),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 26,
                    backgroundColor: isSirenActive ? Colors.red.withOpacity(0.15) : AppColors.softBlueLight,
                    child: Icon(
                      Icons.volume_up_rounded,
                      color: isSirenActive ? Colors.red : AppColors.primaryNavy,
                      size: 28,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Baland Sirena Chalish',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          isSirenActive
                              ? 'Sirena to\'liq ovozda chalinmoqda'
                              : 'Telefon "Ovozsiz" rejimda bo\'lsa ham maksimal balandlikda signal beradi',
                          style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: isSirenActive,
                    activeColor: Colors.red,
                    onChanged: (val) {
                      firestore.toggleEmergencySiren(val);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(val
                              ? 'Jasurning telefonida baland sirena ishga tushirildi!'
                              : 'Sirena to\'xtatildi.'),
                          backgroundColor: val ? Colors.red : Colors.green,
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
          ],

          // BIG SOS BUTTON FOR CHILD OR PARENT
          const Text(
            'Favqulodda Signal (SOS)',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Center(
            child: GestureDetector(
              onTap: () {
                setState(() => _isSosTriggered = !_isSosTriggered);
                firestore.triggerChildSOS(_isSosTriggered);
                showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: Row(
                      children: [
                        Icon(
                          _isSosTriggered ? Icons.warning_rounded : Icons.check_circle_rounded,
                          color: _isSosTriggered ? Colors.red : Colors.green,
                        ),
                        const SizedBox(width: 8),
                        Text(_isSosTriggered ? 'SOS Faollashdi' : 'Bekor Qilindi'),
                      ],
                    ),
                    content: Text(_isSosTriggered
                        ? 'Oila a\'zolariga jonli koordinatangiz va audio ogohlantirish yuborildi!\nTezkor xizmatlar bilan bog\'lanishni xohlaysizmi?'
                        : 'SOS signali o\'chirildi. Barcha oila a\'zolari xavfsizligingizdan xabardor qilindi.'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text('Yopish'),
                      ),
                    ],
                  ),
                );
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: 170,
                height: 170,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: _isSosTriggered || isChildSosActive
                        ? [const Color(0xFFEF4444), const Color(0xFFDC2626)]
                        : [const Color(0xFFDC2626), const Color(0xFF991B1B)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.red.withOpacity(0.5),
                      blurRadius: _isSosTriggered ? 30 : 15,
                      spreadRadius: _isSosTriggered ? 8 : 2,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.touch_app_rounded, size: 48, color: Colors.white),
                    const SizedBox(height: 6),
                    Text(
                      _isSosTriggered || isChildSosActive ? 'SOS FAOL' : 'SOS TUGMASI',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Bosing',
                      style: TextStyle(color: Colors.white70, fontSize: 11),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 28),

          // EMERGENCY PHONE NUMBERS DIRECT CALL
          const Text(
            'Tezkor Davlat Xizmatlari',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildEmergencyPhoneCard(
                  title: 'Ichki Ishlar',
                  number: '102',
                  icon: Icons.local_police_rounded,
                  color: Colors.blue,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildEmergencyPhoneCard(
                  title: 'Tez Yordam',
                  number: '103',
                  icon: Icons.medical_services_rounded,
                  color: Colors.red,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildEmergencyPhoneCard(
                  title: 'FVV / Qutqaruv',
                  number: '1050',
                  icon: Icons.fire_truck_rounded,
                  color: Colors.orange,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEmergencyPhoneCard({
    required String title,
    required String number,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(
        children: [
          CircleAvatar(
            backgroundColor: color.withOpacity(0.12),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          Text(
            number,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: color),
          ),
        ],
      ),
    );
  }
}
