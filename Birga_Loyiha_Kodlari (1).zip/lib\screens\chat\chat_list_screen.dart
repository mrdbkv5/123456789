import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../models/chat_model.dart';
import '../../services/auth_service.dart';
import '../../services/chat_service.dart';
import 'chat_room_screen.dart';

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final chatService = context.watch<ChatService>();
    final auth = context.watch<AuthService>();
    final currentUserId = auth.currentUser?.id ?? 'parent_demo_id';
    final chats = chatService.chats;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Birga Chat'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search_rounded),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Xabarlardan qidirish oynasi')),
              );
            },
          ),
        ],
      ),
      body: chats.isEmpty
          ? const Center(
              child: Text(
                'Hozircha chatlar mavjud emas',
                style: TextStyle(color: AppColors.textSecondaryLight),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: chats.length,
              separatorBuilder: (_, __) => const Divider(height: 1, indent: 80),
              itemBuilder: (context, index) {
                final chat = chats[index];
                final unreadCount = chat.unreadCounts[currentUserId] ?? 0;

                return ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  leading: Stack(
                    children: [
                      CircleAvatar(
                        radius: 26,
                        backgroundColor: chat.isGroup
                            ? AppColors.primaryNavy
                            : AppColors.accentGreen,
                        child: Icon(
                          chat.isGroup ? Icons.groups_rounded : Icons.person_rounded,
                          color: Colors.white,
                          size: 28,
                        ),
                      ),
                      if (chat.isGroup)
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.home, size: 14, color: AppColors.primaryNavy),
                          ),
                        ),
                    ],
                  ),
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          chat.name,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (chat.lastMessageTimestamp != null)
                        Text(
                          DateFormat('HH:mm').format(chat.lastMessageTimestamp!),
                          style: TextStyle(
                            fontSize: 12,
                            color: unreadCount > 0 ? AppColors.accentGreen : AppColors.textSecondaryLight,
                            fontWeight: unreadCount > 0 ? FontWeight.bold : FontWeight.normal,
                          ),
                        ),
                    ],
                  ),
                  subtitle: Row(
                    children: [
                      Expanded(
                        child: Text(
                          chat.lastMessageText ?? 'Yangi chat boshlandi',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: unreadCount > 0 ? AppColors.primaryNavy : AppColors.textSecondaryLight,
                            fontWeight: unreadCount > 0 ? FontWeight.w600 : FontWeight.normal,
                          ),
                        ),
                      ),
                      if (unreadCount > 0)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppColors.accentGreen,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '$unreadCount',
                            style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                          ),
                        ),
                    ],
                  ),
                  onTap: () {
                    chatService.markMessagesAsRead(chat.id, currentUserId);
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => ChatRoomScreen(chat: chat),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}
