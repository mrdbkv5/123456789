import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../services/chat_service.dart';
import '../../services/auth_service.dart';
import 'dashboard_screen.dart';
import '../tasks/tasks_screen.dart';
import '../chat/chat_list_screen.dart';
import '../shopping/shopping_screen.dart';
import '../profile/profile_screen.dart';

class MainShellScreen extends StatefulWidget {
  const MainShellScreen({super.key});

  @override
  State<MainShellScreen> createState() => _MainShellScreenState();
}

class _MainShellScreenState extends State<MainShellScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    DashboardScreen(),
    TasksScreen(),
    ChatListScreen(),
    ShoppingScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final chatService = context.watch<ChatService>();
    final auth = context.watch<AuthService>();
    final currentUserId = auth.currentUser?.id ?? 'parent_demo_id';

    // Total unread chat count
    int totalUnreadChats = 0;
    for (var c in chatService.chats) {
      totalUnreadChats += (c.unreadCounts[currentUserId] ?? 0);
    }

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) {
          setState(() => _currentIndex = index);
        },
        backgroundColor: Theme.of(context).cardColor,
        indicatorColor: AppColors.softBlueLight,
        destinations: [
          const NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded, color: AppColors.primaryNavy),
            label: 'Asosiy',
          ),
          const NavigationDestination(
            icon: Icon(Icons.check_circle_outline_rounded),
            selectedIcon: Icon(Icons.check_circle_rounded, color: AppColors.primaryNavy),
            label: 'Vazifalar',
          ),
          NavigationDestination(
            icon: totalUnreadChats > 0
                ? Badge(
                    label: Text('$totalUnreadChats'),
                    child: const Icon(Icons.chat_bubble_outline_rounded),
                  )
                : const Icon(Icons.chat_bubble_outline_rounded),
            selectedIcon: const Icon(Icons.chat_bubble_rounded, color: AppColors.primaryNavy),
            label: 'Chat',
          ),
          const NavigationDestination(
            icon: Icon(Icons.shopping_bag_outlined),
            selectedIcon: Icon(Icons.shopping_bag_rounded, color: AppColors.primaryNavy),
            label: 'Xaridlar',
          ),
          const NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings_rounded, color: AppColors.primaryNavy),
            label: 'Sozlamalar',
          ),
        ],
      ),
    );
  }
}
