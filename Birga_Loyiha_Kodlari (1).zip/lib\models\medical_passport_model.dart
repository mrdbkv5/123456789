class MedicalPassportModel {
  final String id;
  final String familyId;
  final String childId;
  final String childName;
  final String bloodGroup; // 'I (O+)', 'II (A+)', 'III (B+)', 'IV (AB+)' va h.k.
  final List<String> allergies; // Allergiya ro'yxati (masalan, yong'oq, penitsillin)
  final List<String> chronicIllnesses; // Surunkali xastaliklar (masalan, astma)
  final List<VaccinationRecord> vaccinations; // Emlashlar kalendari
  final String? familyDoctorName;
  final String? familyDoctorPhone;
  final String? notes;
  final DateTime updatedAt;

  MedicalPassportModel({
    required this.id,
    required this.familyId,
    required this.childId,
    required this.childName,
    required this.bloodGroup,
    required this.allergies,
    required this.chronicIllnesses,
    required this.vaccinations,
    this.familyDoctorName,
    this.familyDoctorPhone,
    this.notes,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'familyId': familyId,
      'childId': childId,
      'childName': childName,
      'bloodGroup': bloodGroup,
      'allergies': allergies,
      'chronicIllnesses': chronicIllnesses,
      'vaccinations': vaccinations.map((v) => v.toMap()).toList(),
      'familyDoctorName': familyDoctorName,
      'familyDoctorPhone': familyDoctorPhone,
      'notes': notes,
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory MedicalPassportModel.fromMap(Map<String, dynamic> map, String docId) {
    return MedicalPassportModel(
      id: docId,
      familyId: map['familyId'] ?? '',
      childId: map['childId'] ?? '',
      childName: map['childName'] ?? '',
      bloodGroup: map['bloodGroup'] ?? 'I (O+)',
      allergies: List<String>.from(map['allergies'] ?? []),
      chronicIllnesses: List<String>.from(map['chronicIllnesses'] ?? []),
      vaccinations: (map['vaccinations'] as List<dynamic>?)
              ?.map((v) => VaccinationRecord.fromMap(Map<String, dynamic>.from(v)))
              .toList() ??
          [],
      familyDoctorName: map['familyDoctorName'],
      familyDoctorPhone: map['familyDoctorPhone'],
      notes: map['notes'],
      updatedAt: map['updatedAt'] != null
          ? DateTime.tryParse(map['updatedAt']) ?? DateTime.now()
          : DateTime.now(),
    );
  }
}

class VaccinationRecord {
  final String name; // Vaktsina nomi (masalan: BCG, Gepatit B, Qizamiq)
  final DateTime date;
  final bool isCompleted;

  VaccinationRecord({
    required this.name,
    required this.date,
    this.isCompleted = true,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'date': date.toIso8601String(),
      'isCompleted': isCompleted,
    };
  }

  factory VaccinationRecord.fromMap(Map<String, dynamic> map) {
    return VaccinationRecord(
      name: map['name'] ?? '',
      date: map['date'] != null
          ? DateTime.tryParse(map['date']) ?? DateTime.now()
          : DateTime.now(),
      isCompleted: map['isCompleted'] ?? true,
    );
  }
}
