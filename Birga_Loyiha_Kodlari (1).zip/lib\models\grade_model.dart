class GradeModel {
  final String id;
  final String familyId;
  final String childId;
  final String childName;
  final String subject;
  final double score;
  final double maxScore; // 5.0 yoki 100.0
  final String gradingScale; // '5_scale' yoki '100_scale'
  final String examType; // 'Nazorat ishi', 'Uy vazifasi', 'Choraklik', 'Kundalik dars'
  final String? teacherNote;
  final DateTime examDate;
  final DateTime? nextExamDate;
  final String? homework;
  final DateTime createdAt;

  GradeModel({
    required this.id,
    required this.familyId,
    required this.childId,
    required this.childName,
    required this.subject,
    required this.score,
    this.maxScore = 5.0,
    this.gradingScale = '5_scale',
    required this.examType,
    this.teacherNote,
    required this.examDate,
    this.nextExamDate,
    this.homework,
    required this.createdAt,
  });

  // Foiz ko'rinishidagi baho
  double get percentage => (score / maxScore) * 100;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'familyId': familyId,
      'childId': childId,
      'childName': childName,
      'subject': subject,
      'score': score,
      'maxScore': maxScore,
      'gradingScale': gradingScale,
      'examType': examType,
      'teacherNote': teacherNote,
      'examDate': examDate.toIso8601String(),
      'nextExamDate': nextExamDate?.toIso8601String(),
      'homework': homework,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory GradeModel.fromMap(Map<String, dynamic> map, String docId) {
    return GradeModel(
      id: docId,
      familyId: map['familyId'] ?? '',
      childId: map['childId'] ?? '',
      childName: map['childName'] ?? '',
      subject: map['subject'] ?? '',
      score: (map['score'] as num?)?.toDouble() ?? 0.0,
      maxScore: (map['maxScore'] as num?)?.toDouble() ?? 5.0,
      gradingScale: map['gradingScale'] ?? '5_scale',
      examType: map['examType'] ?? 'Kundalik dars',
      teacherNote: map['teacherNote'],
      examDate: map['examDate'] != null
          ? DateTime.tryParse(map['examDate']) ?? DateTime.now()
          : DateTime.now(),
      nextExamDate: map['nextExamDate'] != null
          ? DateTime.tryParse(map['nextExamDate'])
          : null,
      homework: map['homework'],
      createdAt: map['createdAt'] != null
          ? DateTime.tryParse(map['createdAt']) ?? DateTime.now()
          : DateTime.now(),
    );
  }
}
