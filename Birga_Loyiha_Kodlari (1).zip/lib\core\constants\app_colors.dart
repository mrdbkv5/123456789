import 'package:flutter/material.dart';

class AppColors {
  // Premium Brand Colors (Deep Obsidian Navy & Vibrant Emerald)
  static const Color primaryNavy = Color(0xFF0A1120);
  static const Color primaryBlue = Color(0xFF1E3A8A);
  static const Color accentGreen = Color(0xFF10B981);
  static const Color accentGreenDark = Color(0xFF059669);
  static const Color accentGreenLight = Color(0xFFD1FAE5);
  static const Color cyberBlue = Color(0xFF2563EB);
  static const Color softBlue = Color(0xFF38BDF8);
  static const Color softBlueLight = Color(0xFFDBEAFE);
  static const Color electricViolet = Color(0xFF7C3AED);

  // Status & Priority Colors
  static const Color success = Color(0xFF10B981);
  static const Color warning = Color(0xFFF59E0B);
  static const Color danger = Color(0xFFEF4444);
  static const Color info = Color(0xFF06B6D4);

  // Priority Colors
  static const Color priorityLow = Color(0xFF10B981);
  static const Color priorityMedium = Color(0xFFF59E0B);
  static const Color priorityHigh = Color(0xFFEF4444);

  // Background & Surfaces (Light Luxury Mode)
  static const Color backgroundLight = Color(0xFFF6F8FC);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color cardLight = Color(0xFFFFFFFF);
  static const Color borderLight = Color(0xFFE2E8F0);

  // Background & Surfaces (Dark Luxury Mode)
  static const Color backgroundDark = Color(0xFF070B14);
  static const Color surfaceDark = Color(0xFF0F172A);
  static const Color cardDark = Color(0xFF131D31);
  static const Color borderDark = Color(0xFF233047);

  // Text Colors
  static const Color textPrimaryLight = Color(0xFF09101D);
  static const Color textSecondaryLight = Color(0xFF64748B);
  static const Color textPrimaryDark = Color(0xFFF8FAFC);
  static const Color textSecondaryDark = Color(0xFF94A3B8);

  // Gradients
  static const LinearGradient heroGradient = LinearGradient(
    colors: [Color(0xFF0A1120), Color(0xFF1E3A8A)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient greenGradient = LinearGradient(
    colors: [Color(0xFF059669), Color(0xFF10B981)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient dangerGradient = LinearGradient(
    colors: [Color(0xFF991B1B), Color(0xFFEF4444)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
