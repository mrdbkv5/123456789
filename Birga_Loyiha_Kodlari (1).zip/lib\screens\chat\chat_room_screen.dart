import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../models/chat_model.dart';
import '../../models/message_model.dart';
import '../../services/auth_service.dart';
import '../../services/chat_service.dart';

class ChatRoomScreen extends StatefulWidget {
  final ChatModel chat;

  const ChatRoomScreen({super.key, required this.chat});

  @override
  State<ChatRoomScreen> createState() => _ChatRoomScreenState();
}

class _ChatRoomScreenState extends State<ChatRoomScreen> {
  final _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _isRecordingVoice = false;
  int _voiceDuration = 0;

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent + 80,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final chatService = context.watch<ChatService>();
    final auth = context.watch<AuthService>();
    final currentUserId = auth.currentUser?.id ?? 'parent_demo_id';
    final currentUserName = auth.currentUser?.name ?? 'Foydalanuvchi';
    final messages = chatService.getMessagesForChat(widget.chat.id);

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: widget.chat.isGroup ? AppColors.primaryNavy : AppColors.accentGreen,
              child: Icon(
                widget.chat.isGroup ? Icons.groups_rounded : Icons.person_rounded,
                color: Colors.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.chat.name,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    widget.chat.isGroup ? '${widget.chat.memberIds.length} ta a\'zo' : 'Onlayn',
                    style: const TextStyle(fontSize: 12, color: AppColors.accentGreen),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          // Audio Call Button
          IconButton(
            icon: const Icon(Icons.call_rounded),
            onPressed: () => _showCallDialog(context, isVideo: false),
          ),
          // Video Call Button
          IconButton(
            icon: const Icon(Icons.videocam_rounded),
            onPressed: () => _showCallDialog(context, isVideo: true),
          ),
        ],
      ),
      body: Column(
        children: [
          // Message List
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final msg = messages[index];
                final isMe = msg.senderId == currentUserId;
                return _buildMessageBubble(msg, isMe);
              },
            ),
          ),

          // Voice Recording Indicator (if recording)
          if (_isRecordingVoice)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              color: AppColors.danger.withOpacity(0.1),
              child: Row(
                children: [
                  const Icon(Icons.mic, color: AppColors.danger),
                  const SizedBox(width: 10),
                  Text(
                    'Ovoz yozilmoqda... ${_voiceDuration}s',
                    style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  TextButton(
                    onPressed: () => setState(() => _isRecordingVoice = false),
                    child: const Text('Bekor qilish'),
                  ),
                ],
              ),
            ),

          // Message Input Field
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 10,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: SafeArea(
              child: Row(
                children: [
                  // Attachment Button (Image / File)
                  IconButton(
                    icon: const Icon(Icons.attach_file_rounded, color: AppColors.textSecondaryLight),
                    onPressed: () => _showAttachmentOptions(context),
                  ),

                  // Text Input Field
                  Expanded(
                    child: TextField(
                      controller: _messageController,
                      textCapitalization: TextCapitalization.sentences,
                      decoration: const InputDecoration(
                        hintText: 'Xabar yozing...',
                        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                      ),
                      onSubmitted: (_) => _sendTextMessage(chatService, currentUserId, currentUserName),
                    ),
                  ),

                  // Voice Record or Send Button
                  _messageController.text.trim().isEmpty
                      ? GestureDetector(
                          onLongPressStart: (_) {
                            setState(() {
                              _isRecordingVoice = true;
                              _voiceDuration = 3;
                            });
                          },
                          onLongPressEnd: (_) async {
                            setState(() => _isRecordingVoice = false);
                            await chatService.sendMessage(
                              chatId: widget.chat.id,
                              senderId: currentUserId,
                              senderName: currentUserName,
                              text: '🎤 Ovozli xabar (0:04)',
                              type: 'audio',
                              audioDurationSeconds: 4,
                            );
                            _scrollToBottom();
                          },
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: const BoxDecoration(
                              color: AppColors.primaryNavy,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.mic, color: Colors.white, size: 20),
                          ),
                        )
                      : Container(
                          decoration: const BoxDecoration(
                            color: AppColors.accentGreen,
                            shape: BoxShape.circle,
                          ),
                          child: IconButton(
                            icon: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                            onPressed: () => _sendTextMessage(chatService, currentUserId, currentUserName),
                          ),
                        ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _sendTextMessage(ChatService chatService, String senderId, String senderName) {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    chatService.sendMessage(
      chatId: widget.chat.id,
      senderId: senderId,
      senderName: senderName,
      text: text,
      type: 'text',
    );

    _messageController.clear();
    _scrollToBottom();
  }

  Widget _buildMessageBubble(MessageModel msg, bool isMe) {
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: isMe ? AppColors.accentGreen : Theme.of(context).cardColor,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(isMe ? 16 : 4),
            bottomRight: Radius.circular(isMe ? 4 : 16),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!isMe && widget.chat.isGroup) ...[
              Text(
                msg.senderName,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primaryNavy,
                ),
              ),
              const SizedBox(height: 4),
            ],
            if (msg.type == 'audio') ...[
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.play_circle_fill_rounded,
                    size: 32,
                    color: isMe ? Colors.white : AppColors.accentGreen,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Ovozli xabar (${msg.audioDurationSeconds ?? 3}s)',
                    style: TextStyle(
                      color: isMe ? Colors.white : AppColors.textPrimaryLight,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ] else ...[
              Text(
                msg.text,
                style: TextStyle(
                  fontSize: 15,
                  color: isMe ? Colors.white : null,
                ),
              ),
            ],
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  DateFormat('HH:mm').format(msg.timestamp),
                  style: TextStyle(
                    fontSize: 11,
                    color: isMe ? Colors.white.withOpacity(0.8) : AppColors.textSecondaryLight,
                  ),
                ),
                if (isMe) ...[
                  const SizedBox(width: 4),
                  Icon(
                    msg.status == 'read' ? Icons.done_all_rounded : Icons.check_rounded,
                    size: 14,
                    color: Colors.white.withOpacity(0.9),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showAttachmentOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildAttachmentItem(Icons.photo_library_rounded, 'Galereya', AppColors.softBlue),
              _buildAttachmentItem(Icons.camera_alt_rounded, 'Kamera', AppColors.accentGreen),
              _buildAttachmentItem(Icons.insert_drive_file_rounded, 'Hujjat', AppColors.primaryNavy),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAttachmentItem(IconData icon, String label, Color color) {
    return InkWell(
      onTap: () {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$label tanlash oynasi ochilmoqda...')),
        );
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 26,
            backgroundColor: color.withOpacity(0.12),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  void _showCallDialog(BuildContext context, {required bool isVideo}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(isVideo ? 'Video qo\'ng\'iroq' : 'Ovozli qo\'ng\'iroq'),
        content: Text(
          '${widget.chat.name} bilan ${isVideo ? 'video' : 'ovozli'} muloqot xizmati WebRTC/Signaling orqali ulanmoqda.\n\n(Eslatma: Qo\'ng\'iroqlar uchun STUN/TURN server konfiguratsiyasi talab etiladi).',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Yopish'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.accentGreen),
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Qo\'ng\'iroq yo\'llanmoqda...')),
              );
            },
            child: const Text('Ulanish'),
          ),
        ],
      ),
    );
  }
}
