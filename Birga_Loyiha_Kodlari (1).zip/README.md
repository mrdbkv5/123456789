﻿# 🌟 BIRGA — Innovatsion Oilaviy Super-Ilova & Ota-Ona Nazorati Tizimi

Ushbu yangilangan talqin oddiy ilovadan to'laqonli, qiziqarli, xavfsiz va yuqori darajadagi boshqaruv tizimiga (Super-App) aylantirildi.

---

## 🚀 Yangi Qo'shilgan Innovatsion Funksiyalar:

### 1. 🚨 Favqulodda SOS & Masofaviy Baland Sirena (Safety Hub)
- **Masofaviy Baland Sirena:** Bolaning telefoni "Ovozsiz" (Silent/Vibrate) rejimda bo'lsa ham, ota-ona o'z telefonidan bitta tugma bilan bolaning telefonida eng baland ovozda qidiruv/ogohlantirish sirenasini chalishi mumkin.
- **Farzand SOS Tugmasi:** Farzand xavf ostida qolganda bitta bosish bilan butun oilaga jonli GPS koordinata, xabar va batareya foizini yuboradi.
- **Tezkor Davlat Xizmatlari:** 102 (Ichki Ishlar), 103 (Tez Yordam), 1050 (FVV) bilan bitta bosishda bog'lanish.

### 2. 🤖 "Birga AI" — Aqlli Oila Assistent & Repetitori
- **Bolalar uchun repetitor:** 5-11 sinf matematika, ingliz tili, tarix va boshqa fanlar bo'yicha masalalarni bosqichma-bosqich, oson tushuntirib berish.
- **Ota-onalar uchun psixolog & maslahatchi:** Farzandning injiqliklari, telefonga bog'lanib qolishni kamaytirish va to'g'ri muloqot qilish sirlari.
- **Sog'lom turmush tarzi:** Bolalar uchun foydali taomnoma va kun tartibi.

### 3. 🪙 Gamifikatsiya: "Birga Coins" & Mukofotlar Do'koni
- **Bolalar motivatsiyasi:** Dars qilish (+20 tanga), kitob o'qish (+15 tanga), xonani tozalash (+10 tanga), 5 baho olish (+25 tanga).
- **Mukofotlar Do'koni:** Bolalar to'plagan tangalarini muzqaymoq, 1 soat qo'shimcha o'yin vaqti, kinoga borish yoki yangi velosipedga almashtirishni ota-onadan so'raydi. Ota-ona tasdiqlaydi!

### 4. 🛡️ Chuqur Masofaviy Nazorat & Ilova Cheklovlari (App Limits & Bedtime)
- **Ilovalarni alohida boshqarish:** TikTok, PUBG, Instagram va YouTube ilovalariga alohida kunlik daqiqalar qo'yish yoki bitta tugma bilan bloklash.
- **Tungi Uyqu Rejimi (Bedtime 22:00 - 07:00):** Belgilangan vaqtda bolaning telefoni avtomatik qulflanadi (faqat ota-onaga qo'ng'iroq qilish ochiq qoladi).
- **Jonli Ekran va AnyDesk uslubidagi monitoring:** Farzand nima bilan bandligini real-vaqtda ko'rish va xavfsizligini ta'minlash.

### 5. 🏥 Tibbiy Pasport & Geozonalar
- Qon guruhi, vaksinalar, surunkali kasalliklar, shoshilinch aloqa.
- Uy, maktab va bog'cha bo'yicha xavfsiz geozonalar (bolaning kirib-chiqqanini avtomatik bildirish).

### 6. 💬 Oilaviy Chat & Ovozli Vazifalar (Voice Tasks)
- Ovozli xabar orqali bir soniyada topshiriq va xaridlar ro'yxatini yaratish.

---

## 💻 Ishga tushirish:
1. Flutter orqali: lutter pub get -> lutter run
2. Veb (PWA) sifatida: web_production_build papkasidagi fayllar bevosita brauzerda yoki PWABuilder (pwabuilder.com) da ishlaydi.
