import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../models/location_update_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../../services/location_service.dart';

class FamilyMapScreen extends StatefulWidget {
  const FamilyMapScreen({super.key});

  @override
  State<FamilyMapScreen> createState() => _FamilyMapScreenState();
}

class _FamilyMapScreenState extends State<FamilyMapScreen> {
  LocationUpdateModel? _selectedMember;

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final auth = context.watch<AuthService>();
    final locationService = context.watch<LocationService>();
    final familyId = auth.currentUser?.familyId ?? 'family_101';
    final locations = firestore.getLocations(familyId);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Oilaviy Xarita'),
        actions: [
          IconButton(
            icon: Icon(
              locationService.isSharingEnabled ? Icons.location_on : Icons.location_off,
              color: locationService.isSharingEnabled ? AppColors.accentGreen : AppColors.danger,
            ),
            tooltip: 'Joylashuv ulashish sozlamasi',
            onPressed: () {
              locationService.toggleLocationSharing(!locationService.isSharingEnabled);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    locationService.isSharingEnabled
                        ? 'Sizning joylashuvingiz oila a\'zolari bilan ulashilmoqda'
                        : 'Joylashuv ulashish to\'xtatildi',
                  ),
                ),
              );
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          // Simulated Map Background (Google Maps interfeysi konteyneri)
          Container(
            color: const Color(0xFFE8ECEF),
            child: Stack(
              children: [
                // Map Grid Lines & Roads styling
                CustomPaint(
                  size: Size.infinite,
                  painter: _MapGridPainter(),
                ),

                // Members Pins on Map
                ...locations.asMap().entries.map((entry) {
                  final index = entry.key;
                  final loc = entry.value;

                  // Coordinates mapping to screen space for preview
                  final topOffset = 180.0 + (index * 130.0);
                  final leftOffset = 80.0 + (index * 120.0);

                  return Positioned(
                    top: topOffset,
                    left: leftOffset,
                    child: GestureDetector(
                      onTap: () => setState(() => _selectedMember = loc),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.15),
                                  blurRadius: 8,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  loc.userName,
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                                ),
                                const SizedBox(width: 4),
                                Icon(
                                  Icons.battery_std_rounded,
                                  size: 14,
                                  color: loc.batteryLevel > 20 ? AppColors.accentGreen : AppColors.danger,
                                ),
                                Text('${loc.batteryLevel}%', style: const TextStyle(fontSize: 10)),
                              ],
                            ),
                          ),
                          const SizedBox(height: 4),
                          Container(
                            width: 46,
                            height: 46,
                            decoration: BoxDecoration(
                              color: AppColors.primaryNavy,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 3),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.2),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: const Icon(Icons.person, color: Colors.white, size: 26),
                          ),
                          Container(
                            width: 6,
                            height: 6,
                            decoration: const BoxDecoration(
                              color: AppColors.primaryNavy,
                              shape: BoxShape.circle,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),

          // Top Info Banner: Consent & Transparency
          Positioned(
            top: 12,
            left: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.95),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: Row(
                children: [
                  Icon(
                    locationService.isSharingEnabled ? Icons.visibility : Icons.visibility_off,
                    size: 18,
                    color: locationService.isSharingEnabled ? AppColors.accentGreen : AppColors.danger,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      locationService.isSharingEnabled
                          ? 'Joylashuv o\'zaro rozilik asosida ko\'rinmoqda'
                          : 'Joylashuv ulashish o\'chirilgan',
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Bottom Member Info Sheet (when member selected or default list)
          Positioned(
            bottom: 20,
            left: 16,
            right: 16,
            child: _selectedMember != null
                ? _buildSelectedMemberCard(_selectedMember!)
                : _buildMembersHorizontalList(locations),
          ),
        ],
      ),
    );
  }

  Widget _buildSelectedMemberCard(LocationUpdateModel member) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.12),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const CircleAvatar(
                    backgroundColor: AppColors.primaryNavy,
                    child: Icon(Icons.person, color: Colors.white),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        member.userName,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      Text(
                        'Yangilangan: ${DateFormat('HH:mm').format(member.updatedAt)} (${DateTime.now().difference(member.updatedAt).inMinutes} daqiqa oldin)',
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                      ),
                    ],
                  ),
                ],
              ),
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => setState(() => _selectedMember = null),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildInfoBadge(Icons.battery_charging_full_rounded, '${member.batteryLevel}% batareya'),
              const SizedBox(width: 8),
              _buildInfoBadge(Icons.gps_fixed_rounded, 'GPS aniqligi: ~${member.accuracy.toInt()}m'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMembersHorizontalList(List<LocationUpdateModel> locations) {
    return Container(
      height: 80,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 15,
          ),
        ],
      ),
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        scrollDirection: Axis.horizontal,
        itemCount: locations.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          final loc = locations[index];
          return InkWell(
            onTap: () => setState(() => _selectedMember = loc),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundColor: AppColors.softBlueLight,
                  child: Text(loc.userName[0], style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryBlue)),
                ),
                const SizedBox(width: 8),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(loc.userName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    Text('${loc.batteryLevel}% batareya', style: const TextStyle(fontSize: 11, color: AppColors.textSecondaryLight)),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildInfoBadge(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.backgroundLight,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: AppColors.primaryNavy),
          const SizedBox(width: 6),
          Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _MapGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.6)
      ..strokeWidth = 2;

    // Simulated roads
    canvas.drawLine(Offset(0, size.height * 0.3), Offset(size.width, size.height * 0.35), paint);
    canvas.drawLine(Offset(0, size.height * 0.65), Offset(size.width, size.height * 0.6), paint);
    canvas.drawLine(Offset(size.width * 0.4, 0), Offset(size.width * 0.45, size.height), paint);
    canvas.drawLine(Offset(size.width * 0.75, 0), Offset(size.width * 0.7, size.height), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
