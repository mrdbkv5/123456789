class ParsedVoiceTask {
  final String title;
  final DateTime? dueDate;
  final String? timeString;
  final bool isDateCertain;
  final bool isTimeCertain;

  ParsedVoiceTask({
    required this.title,
    this.dueDate,
    this.timeString,
    this.isDateCertain = true,
    this.isTimeCertain = true,
  });
}

class SpeechTaskParser {
  /// O'zbek tilidagi ovozli gapdan vazifa nomi, sana va vaqtni aniqlash
  static ParsedVoiceTask parseUzbekSentence(String rawText) {
    if (rawText.trim().isEmpty) {
      return ParsedVoiceTask(title: '', isDateCertain: false, isTimeCertain: false);
    }

    String text = rawText.toLowerCase().trim();
    DateTime now = DateTime.now();
    DateTime targetDate = now;
    bool foundDate = false;
    bool foundTime = false;
    int targetHour = 12;
    int targetMinute = 0;

    // 1. Sana aniqlash (Bugun, Ertaga, Indinga, Haftaning kunlari)
    if (text.contains('bugun')) {
      targetDate = now;
      foundDate = true;
      text = text.replaceAll('bugun', '');
    } else if (text.contains('ertaga')) {
      targetDate = now.add(const Duration(days: 1));
      foundDate = true;
      text = text.replaceAll('ertaga', '');
    } else if (text.contains('indinga')) {
      targetDate = now.add(const Duration(days: 2));
      foundDate = true;
      text = text.replaceAll('indinga', '');
    }

    // 2. Vaqt aniqlash (soat 5 da, soat beshda, 18:00 da, ertalab, kechqurun)
    final timeRegex = RegExp(r'soat\s*(\d{1,2})(?::(\d{2}))?\s*(?:da|ga|lar)?');
    final match = timeRegex.firstMatch(text);
    if (match != null) {
      int hour = int.parse(match.group(1)!);
      int minute = match.group(2) != null ? int.parse(match.group(2)!) : 0;
      
      // Agar "kechqurun" yoki "kunduzi/tushdan keyin" bo'lsa va soat < 12 bo'lsa
      if ((text.contains('kechqurun') || text.contains('kechki')) && hour < 12) {
        hour += 12;
      }
      targetHour = hour;
      targetMinute = minute;
      foundTime = true;
      text = text.replaceAll(match.group(0)!, '');
    } else {
      // So'z bilan aytilgan sonlar: birda, ikkida, uchda, to'rtda, beshda, oltida, yettida, sakkizda, to'qqizda, o'nda, o'n birda, o'n ikkida
      final wordNumbers = {
        'birda': 1, 'ikkida': 2, 'uchda': 3, 'to\'rtda': 4, 'turtda': 4,
        'beshda': 5, 'oltida': 6, 'yettida': 7, 'sakkizda': 8,
        'to\'qqizda': 9, 'tuqqizda': 9, 'o\'nda': 10, 'unda': 10,
        'o\'n birda': 11, 'o\'n ikkida': 12
      };

      for (var entry in wordNumbers.entries) {
        if (text.contains(entry.key)) {
          int h = entry.value;
          if ((text.contains('kechqurun') || text.contains('abeddan keyin') || text.contains('tushdan keyin')) && h < 12) {
            h += 12;
          }
          targetHour = h;
          targetMinute = 0;
          foundTime = true;
          text = text.replaceAll(entry.key, '');
          break;
        }
      }
    }

    // "kerak", "lozim", "bo'lishi shart", "soat" so'zlarini tozalash
    text = text.replaceAll('kerak', '')
               .replaceAll('lozim', '')
               .replaceAll('qilishim', 'qilish')
               .replaceAll('aytishim', 'aytish')
               .replaceAll('olib kelishim', 'olib kelish')
               .replaceAll('borishim', 'borish')
               .replaceAll('soat', '')
               .replaceAll('kechqurun', '')
               .replaceAll('ertalab', '')
               .trim();

    // Birinchi harfni bosh harf qilish
    String cleanedTitle = text.isNotEmpty 
        ? text[0].toUpperCase() + text.substring(1) 
        : rawText;

    DateTime finalDateTime = DateTime(
      targetDate.year,
      targetDate.month,
      targetDate.day,
      foundTime ? targetHour : 12,
      foundTime ? targetMinute : 0,
    );

    return ParsedVoiceTask(
      title: cleanedTitle,
      dueDate: finalDateTime,
      timeString: foundTime ? '${targetHour.toString().padLeft(2, '0')}:${targetMinute.toString().padLeft(2, '0')}' : null,
      isDateCertain: foundDate,
      isTimeCertain: foundTime,
    );
  }
}
