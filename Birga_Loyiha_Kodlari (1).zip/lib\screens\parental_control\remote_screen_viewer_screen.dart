import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../models/remote_control_model.dart';
import '../../services/firestore_service.dart';

class RemoteScreenViewerScreen extends StatefulWidget {
  final String childId;

  const RemoteScreenViewerScreen({super.key, this.childId = 'child_demo_id'});

  @override
  State<RemoteScreenViewerScreen> createState() => _RemoteScreenViewerScreenState();
}

class _RemoteScreenViewerScreenState extends State<RemoteScreenViewerScreen> {
  bool _isConnecting = false;

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final device = firestore.getRemoteDevice(widget.childId) ??
        RemoteDeviceControlModel(
          childId: widget.childId,
          childName: 'Jasur Rahimov',
          familyId: 'family_101',
          lastHeartbeat: DateTime.now(),
        );

    return Scaffold(
      appBar: AppBar(
        title: Text('${device.childName} — Jonli Nazorat'),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            onPressed: () => _showPermissionExplanation(context),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Device Status Card
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.borderLight),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: device.isLocked ? AppColors.danger.withOpacity(0.15) : AppColors.accentGreenLight,
                  child: Icon(
                    device.isLocked ? Icons.lock_rounded : Icons.phone_android_rounded,
                    color: device.isLocked ? AppColors.danger : AppColors.accentGreen,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            device.childName,
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                          const SizedBox(width: 8),
                          Icon(Icons.battery_std_rounded, size: 14, color: device.batteryLevel > 20 ? AppColors.accentGreen : AppColors.danger),
                          Text('${device.batteryLevel}%', style: const TextStyle(fontSize: 12)),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        device.isLocked
                            ? 'Qurilma qulflangan: ${device.lockReason ?? "Ota-ona cheklovi"}'
                            : 'Ayni paytda ochiq: ${device.currentActiveApp} (${device.activeAppDurationMinutes} daqiqa)',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: device.isLocked ? AppColors.danger : AppColors.primaryBlue,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),

          // Live Screen Stream Box (AnyDesk uslubida masofaviy ekran)
          Container(
            height: 380,
            decoration: BoxDecoration(
              color: const Color(0xFF0F172A),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: device.isScreenStreamActive ? AppColors.accentGreen : AppColors.borderDark,
                width: device.isScreenStreamActive ? 2 : 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 15,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Stack(
              children: [
                if (!device.isScreenStreamActive) ...[
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.screen_share_outlined,
                          size: 64,
                          color: Colors.white.withOpacity(0.4),
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'Ekran uzatilishi to\'xtatilgan',
                          style: TextStyle(color: Colors.white70, fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'Jonli ko\'rish uchun quyidagi tugmani bosing',
                          style: TextStyle(color: Colors.white38, fontSize: 12),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.accentGreen,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                          ),
                          onPressed: () async {
                            setState(() => _isConnecting = true);
                            await Future.delayed(const Duration(seconds: 1));
                            await firestore.toggleScreenStream(widget.childId, true);
                            setState(() => _isConnecting = false);
                          },
                          icon: _isConnecting
                              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                              : const Icon(Icons.videocam_rounded),
                          label: Text(_isConnecting ? 'Ulanmoqda...' : 'Ekranni Jonli Ko\'rish'),
                        ),
                      ],
                    ),
                  ),
                ] else ...[
                  // Simulated Live Phone Screen (AnyDesk Stream)
                  Positioned.fill(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(22),
                      child: Container(
                        color: Colors.black,
                        child: Column(
                          children: [
                            // Top Bar of Stream
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                              color: Colors.red.withOpacity(0.85),
                              child: const Row(
                                children: [
                                  Icon(Icons.fiber_manual_record, color: Colors.white, size: 14),
                                  SizedBox(width: 8),
                                  Text(
                                    'JONLI EFIR (WebRTC Secure Stream)',
                                    style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                                  ),
                                  Spacer(),
                                  Text('FPS: 30 • 720p', style: TextStyle(color: Colors.white70, fontSize: 10)),
                                ],
                              ),
                            ),
                            // Simulated App Window on Child Device (e.g. YouTube or Game)
                            Expanded(
                              child: Container(
                                color: const Color(0xFF1E293B),
                                padding: const EdgeInsets.all(16),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(20),
                                      decoration: BoxDecoration(
                                        color: Colors.red.withOpacity(0.15),
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                      child: const Icon(Icons.play_circle_fill, size: 60, color: Colors.red),
                                    ),
                                    const SizedBox(height: 14),
                                    Text(
                                      'Ayni daqiqada: ${device.currentActiveApp}',
                                      style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      'Davomiyligi: ${device.activeAppDurationMinutes} daqiqa',
                                      style: const TextStyle(color: Colors.white70, fontSize: 13),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  // Stop Stream Button
                  Positioned(
                    bottom: 16,
                    right: 16,
                    child: FloatingActionButton.extended(
                      backgroundColor: AppColors.danger,
                      foregroundColor: Colors.white,
                      onPressed: () {
                        firestore.toggleScreenStream(widget.childId, false);
                      },
                      icon: const Icon(Icons.stop_circle_outlined),
                      label: const Text('Efirni to\'xtatish'),
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Remote Actions (Lock Device, Limit App)
          const Text(
            'Tezkor Boshqaruv Buyruqlari',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),

          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: device.isLocked ? AppColors.accentGreen : AppColors.danger,
                    foregroundColor: Colors.white,
                    minimumSize: const Size.fromHeight(54),
                  ),
                  onPressed: () {
                    if (device.isLocked) {
                      firestore.toggleDeviceLock(widget.childId, false);
                    } else {
                      _showLockReasonDialog(context, firestore);
                    }
                  },
                  icon: Icon(device.isLocked ? Icons.lock_open_rounded : Icons.lock_rounded),
                  label: Text(device.isLocked ? 'Qulfdan Chiqarish' : 'Telefoni Qulflash'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // System Permissions Info (Google Family Link kabi)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.softBlueLight.withOpacity(0.5),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.verified_user_rounded, color: AppColors.primaryBlue),
                    SizedBox(width: 8),
                    Text(
                      'Tizim Ruxsatlari Holati (Google Family Link)',
                      style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryNavy),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                _buildPermissionRow('Accessibility Service (Maxsus imkoniyatlar):', device.isAccessibilityGranted),
                const SizedBox(height: 6),
                _buildPermissionRow('Device Admin (Qurilma ma\'muri):', device.isDeviceAdminGranted),
                const SizedBox(height: 6),
                _buildPermissionRow('Doimiy Masofaviy Bog\'lanish:', true),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPermissionRow(String title, bool isGranted) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: const TextStyle(fontSize: 12, color: AppColors.primaryNavy)),
        Row(
          children: [
            Icon(
              isGranted ? Icons.check_circle : Icons.cancel,
              color: isGranted ? AppColors.accentGreen : AppColors.danger,
              size: 16,
            ),
            const SizedBox(width: 4),
            Text(
              isGranted ? 'Faol' : 'O\'chirilgan',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: isGranted ? AppColors.accentGreen : AppColors.danger,
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _showLockReasonDialog(BuildContext context, FirestoreService firestore) {
    String selectedReason = "Dars vaqti";
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Farzand telefonini qulflash'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Qurilma ekranga ota-ona xabarini chiqarib, vaqtincha bloklanadi:'),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: selectedReason,
                items: const [
                  DropdownMenuItem(value: 'Dars vaqti', child: Text('Dars vaqti (Kitob o\'qish)')),
                  DropdownMenuItem(value: 'Uxlash vaqti', child: Text('Uxlash vaqti (Kechki dam olish)')),
                  DropdownMenuItem(value: 'Ovqatlanish vaqti', child: Text('Oilaviy ovqatlanish vaqti')),
                  DropdownMenuItem(value: 'Ota-ona cheklovi', child: Text('Ota-ona cheklovi')),
                ],
                onChanged: (val) => setDialogState(() => selectedReason = val ?? selectedReason),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Bekor qilish')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger, foregroundColor: Colors.white),
              onPressed: () {
                firestore.toggleDeviceLock(widget.childId, true, reason: selectedReason);
                Navigator.pop(ctx);
              },
              child: const Text('Qulflash'),
            ),
          ],
        ),
      ),
    );
  }

  void _showPermissionExplanation(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Xavfsiz va Qonuniy Boshqaruv'),
        content: const Text(
          'Farzand telefoni birinchi marta ulanganda, ota-ona farzand telefonida Android Accessibility Service va Device Administrator ruxsatlarini yoqadi.\n\nShundan keyin ota-ona istalgan payt o\'z telefonidagi Birga ilovasi orqali qayta ruxsat so\'ramasdan ekranni ko\'rishi va bloklashi mumkin.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tushundim')),
        ],
      ),
    );
  }
}
