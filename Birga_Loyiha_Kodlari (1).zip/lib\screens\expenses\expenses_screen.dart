import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_constants.dart';
import '../../models/expense_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';

class ExpensesScreen extends StatelessWidget {
  const ExpensesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final auth = context.watch<AuthService>();
    final familyId = auth.currentUser?.familyId ?? 'family_101';
    final expenses = firestore.getExpenses(familyId);

    final double totalSpent = expenses.fold(0.0, (sum, e) => sum + e.amount);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Oilaviy Xarajatlar'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Total Spent Summary Card
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF065F46), AppColors.accentGreen],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(
                  color: AppColors.accentGreen.withOpacity(0.3),
                  blurRadius: 16,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Bu oydagi jami xarajatlar',
                  style: TextStyle(color: Colors.white70, fontSize: 14),
                ),
                const SizedBox(height: 8),
                Text(
                  '${NumberFormat('#,###').format(totalSpent)} so\'m',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    const Icon(Icons.insights_rounded, color: Colors.white70, size: 16),
                    const SizedBox(width: 6),
                    Text(
                      '${expenses.length} ta operatsiya kiritildi',
                      style: const TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Categories Breakdown List
          const Text(
            'Kategoriyalar bo\'yicha taqsimot',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),

          ...expenses.map((expense) {
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: AppColors.softBlueLight,
                  child: const Icon(Icons.account_balance_wallet_outlined, color: AppColors.primaryBlue),
                ),
                title: Text(expense.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${expense.category} • ${DateFormat('dd.MM.yyyy').format(expense.date)} • ${expense.paidByName}'),
                trailing: Text(
                  '-${NumberFormat('#,###').format(expense.amount)} so\'m',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.danger),
                ),
              ),
            );
          }),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.accentGreen,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('Xarajat kiritish'),
        onPressed: () => _showAddExpenseDialog(context),
      ),
    );
  }

  void _showAddExpenseDialog(BuildContext context) {
    final titleCtrl = TextEditingController();
    final amountCtrl = TextEditingController();
    String category = AppConstants.expenseCategories.first;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Yangi xarajat kiritish'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: category,
                  decoration: const InputDecoration(labelText: 'Kategoriya'),
                  items: AppConstants.expenseCategories
                      .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                      .toList(),
                  onChanged: (val) => setDialogState(() => category = val ?? category),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: titleCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Nima uchun xarajat qilindi?',
                    hintText: 'Masalan: Bozorlik, yo\'lkira',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: amountCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Summasi (so\'m)',
                    hintText: 'Masalan: 50000',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Bekor qilish'),
            ),
            ElevatedButton(
              onPressed: () async {
                final title = titleCtrl.text.trim();
                final amt = double.tryParse(amountCtrl.text.trim()) ?? 0;
                if (title.isEmpty || amt <= 0) return;

                final auth = context.read<AuthService>();
                final firestore = context.read<FirestoreService>();

                final newExp = ExpenseModel(
                  id: 'exp_${DateTime.now().millisecondsSinceEpoch}',
                  familyId: auth.currentUser?.familyId ?? 'family_101',
                  title: title,
                  amount: amt,
                  date: DateTime.now(),
                  category: category,
                  paidByName: auth.currentUser?.name ?? 'Oila a\'zosi',
                );

                await firestore.addExpense(newExp);
                Navigator.pop(ctx);
              },
              child: const Text('Saqlash'),
            ),
          ],
        ),
      ),
    );
  }
}
