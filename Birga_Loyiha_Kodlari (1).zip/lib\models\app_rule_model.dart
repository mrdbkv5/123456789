class AppRuleModel {
  final String packageName;
  final String appName;
  final String category; // 'social', 'game', 'education', 'media'
  final int dailyLimitMinutes;
  final int usedMinutesToday;
  final bool isBlocked;
  final bool isAlwaysAllowed;
  final String iconKey;

  AppRuleModel({
    required this.packageName,
    required this.appName,
    required this.category,
    required this.dailyLimitMinutes,
    required this.usedMinutesToday,
    this.isBlocked = false,
    this.isAlwaysAllowed = false,
    required this.iconKey,
  });

  bool get isLimitExceeded => !isAlwaysAllowed && (usedMinutesToday >= dailyLimitMinutes);

  AppRuleModel copyWith({
    String? packageName,
    String? appName,
    String? category,
    int? dailyLimitMinutes,
    int? usedMinutesToday,
    bool? isBlocked,
    bool? isAlwaysAllowed,
    String? iconKey,
  }) {
    return AppRuleModel(
      packageName: packageName ?? this.packageName,
      appName: appName ?? this.appName,
      category: category ?? this.category,
      dailyLimitMinutes: dailyLimitMinutes ?? this.dailyLimitMinutes,
      usedMinutesToday: usedMinutesToday ?? this.usedMinutesToday,
      isBlocked: isBlocked ?? this.isBlocked,
      isAlwaysAllowed: isAlwaysAllowed ?? this.isAlwaysAllowed,
      iconKey: iconKey ?? this.iconKey,
    );
  }
}

class BedtimeScheduleModel {
  final bool isEnabled;
  final String startTime; // e.g. "22:00"
  final String endTime;   // e.g. "07:00"
  final List<int> activeDays; // 1 to 7 (Mon-Sun)
  final bool allowEmergencyCallsOnly;

  BedtimeScheduleModel({
    this.isEnabled = true,
    this.startTime = "22:00",
    this.endTime = "07:00",
    this.activeDays = const [1, 2, 3, 4, 5, 6, 7],
    this.allowEmergencyCallsOnly = true,
  });

  BedtimeScheduleModel copyWith({
    bool? isEnabled,
    String? startTime,
    String? endTime,
    List<int>? activeDays,
    bool? allowEmergencyCallsOnly,
  }) {
    return BedtimeScheduleModel(
      isEnabled: isEnabled ?? this.isEnabled,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      activeDays: activeDays ?? this.activeDays,
      allowEmergencyCallsOnly: allowEmergencyCallsOnly ?? this.allowEmergencyCallsOnly,
    );
  }
}
