import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../services/auth_service.dart';
import 'family_setup_screen.dart';
import '../home/main_shell_screen.dart';

class ParentAuthScreen extends StatefulWidget {
  const ParentAuthScreen({super.key});

  @override
  State<ParentAuthScreen> createState() => _ParentAuthScreenState();
}

class _ParentAuthScreenState extends State<ParentAuthScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // Phone Auth Controllers
  final _phoneController = TextEditingController(text: '+998 ');
  final _otpController = TextEditingController();
  final _phoneNameController = TextEditingController();
  bool _isOtpSent = false;
  String? _verificationId;

  // Email Auth Controllers
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _emailNameController = TextEditingController();
  bool _isRegisterMode = false;
  bool _obscurePassword = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _phoneController.dispose();
    _otpController.dispose();
    _phoneNameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _emailNameController.dispose();
    super.dispose();
  }

  void _onAuthSuccess() {
    final auth = context.read<AuthService>();
    if (auth.currentUser?.familyId != null && auth.currentUser!.familyId!.isNotEmpty) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const MainShellScreen()),
        (route) => false,
      );
    } else {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const FamilySetupScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final authService = context.watch<AuthService>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ota-ona sifatida kirish'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppColors.primaryNavy,
          unselectedLabelColor: AppColors.textSecondaryLight,
          indicatorColor: AppColors.accentGreen,
          indicatorWeight: 3,
          tabs: const [
            Tab(icon: Icon(Icons.phone_android_rounded), text: 'Telefon orqali'),
            Tab(icon: Icon(Icons.email_outlined), text: 'Email orqali'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // 1. TELEFON RAQAMI TABI
          SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 10),
                const Text(
                  'Telefon raqamingizga tasdiqlash kodi yuboriladi',
                  style: TextStyle(fontSize: 14, color: AppColors.textSecondaryLight),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _phoneNameController,
                  decoration: const InputDecoration(
                    labelText: 'Ismingiz (Ota-ona)',
                    prefixIcon: Icon(Icons.person_outline),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  enabled: !_isOtpSent,
                  decoration: const InputDecoration(
                    labelText: 'Telefon raqam',
                    prefixIcon: Icon(Icons.phone),
                  ),
                ),
                const SizedBox(height: 16),
                if (_isOtpSent) ...[
                  TextField(
                    controller: _otpController,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    decoration: const InputDecoration(
                      labelText: 'SMS orqali kelgan 6 xonali kod',
                      prefixIcon: Icon(Icons.lock_clock_outlined),
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: authService.isLoading
                        ? null
                        : () async {
                            final user = await authService.verifyOtpAndLogin(
                              smsCode: _otpController.text.trim(),
                              name: _phoneNameController.text.trim(),
                              phone: _phoneController.text.trim(),
                              verificationId: _verificationId,
                            );
                            if (user != null) {
                              _onAuthSuccess();
                            }
                          },
                    child: authService.isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text('Kodni tasdiqlash va Kirish'),
                  ),
                ] else ...[
                  ElevatedButton(
                    onPressed: authService.isLoading
                        ? null
                        : () async {
                            await authService.sendPhoneOtp(
                              phoneNumber: _phoneController.text.trim(),
                              onCodeSent: (vId) {
                                setState(() {
                                  _verificationId = vId;
                                  _isOtpSent = true;
                                });
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Tasdiqlash kodi yuborildi!')),
                                );
                              },
                              onError: (err) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text(err), backgroundColor: AppColors.danger),
                                );
                              },
                            );
                          },
                    child: authService.isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text('SMS Kod Olish'),
                  ),
                ],
              ],
            ),
          ),

          // 2. EMAIL VA PAROL TABI
          SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 10),
                Text(
                  _isRegisterMode
                      ? 'Yangi ota-ona profilini ro\'yxatdan o\'tkazing'
                      : 'Mavjud hisobingizga email va parol orqali kiring',
                  style: const TextStyle(fontSize: 14, color: AppColors.textSecondaryLight),
                ),
                const SizedBox(height: 20),
                if (_isRegisterMode) ...[
                  TextField(
                    controller: _emailNameController,
                    decoration: const InputDecoration(
                      labelText: 'To\'liq ismingiz',
                      prefixIcon: Icon(Icons.person_outline),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
                TextField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Elektron pochta manzili',
                    prefixIcon: Icon(Icons.email_outlined),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _passwordController,
                  obscureText: _obscurePassword,
                  decoration: InputDecoration(
                    labelText: 'Parol',
                    prefixIcon: const Icon(Icons.lock_outline),
                    suffixIcon: IconButton(
                      icon: Icon(_obscurePassword ? Icons.visibility_off : Icons.visibility),
                      onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: authService.isLoading
                      ? null
                      : () async {
                          if (_isRegisterMode) {
                            final user = await authService.registerParentWithEmail(
                              name: _emailNameController.text.trim(),
                              email: _emailController.text.trim(),
                              password: _passwordController.text.trim(),
                            );
                            if (user != null) _onAuthSuccess();
                          } else {
                            final user = await authService.loginParentWithEmail(
                              email: _emailController.text.trim(),
                              password: _passwordController.text.trim(),
                            );
                            if (user != null) _onAuthSuccess();
                          }
                        },
                  child: authService.isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : Text(_isRegisterMode ? 'Ro\'yxatdan o\'tish' : 'Tizimga kirish'),
                ),
                const SizedBox(height: 16),
                TextButton(
                  onPressed: () => setState(() => _isRegisterMode = !_isRegisterMode),
                  child: Text(
                    _isRegisterMode
                        ? 'Hisobingiz bormi? Tizimga kiring'
                        : 'Hisobingiz yo\'qmi? Ro\'yxatdan o\'ting',
                    style: const TextStyle(color: AppColors.primaryNavy, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
