import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../models/task_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';

class AddTaskDialog extends StatefulWidget {
  const AddTaskDialog({super.key});

  @override
  State<AddTaskDialog> createState() => _AddTaskDialogState();
}

class _AddTaskDialogState extends State<AddTaskDialog> {
  final _titleController = TextEditingController();
  final _descController = TextEditingController();
  DateTime _selectedDate = DateTime.now().add(const Duration(hours: 3));
  TimeOfDay _selectedTime = TimeOfDay.fromDateTime(DateTime.now().add(const Duration(hours: 3)));
  String _priority = 'medium';
  String _recurrence = 'none';
  String? _assignedMemberName;

  @override
  void dispose() {
    _titleController.dispose();
    _descController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final firestore = context.watch<FirestoreService>();
    final members = firestore.getFamilyMembers(auth.currentUser?.familyId ?? 'family_101');

    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Yangi vazifa yaratish', style: TextStyle(fontWeight: FontWeight.bold)),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Vazifa nomi',
                hintText: 'Masalan: Non va sut sotib olish',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _descController,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'Qo\'shimcha izoh (ixtiyoriy)',
              ),
            ),
            const SizedBox(height: 12),

            // Mas'ul shaxs tanlash
            DropdownButtonFormField<String>(
              value: _assignedMemberName,
              hint: const Text('Mas\'ul oila a\'zosi'),
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.person_outline),
              ),
              items: members.map((m) {
                return DropdownMenuItem<String>(
                  value: m.name,
                  child: Text(m.name),
                );
              }).toList(),
              onChanged: (val) => setState(() => _assignedMemberName = val),
            ),
            const SizedBox(height: 12),

            // Muhimlik darajasi
            DropdownButtonFormField<String>(
              value: _priority,
              decoration: const InputDecoration(
                labelText: 'Muhimlik darajasi',
                prefixIcon: Icon(Icons.flag_outlined),
              ),
              items: const [
                DropdownMenuItem(value: 'low', child: Text('Past muhimlik')),
                DropdownMenuItem(value: 'medium', child: Text('O\'rtacha muhimlik')),
                DropdownMenuItem(value: 'high', child: Text('Yuqori (Shoshilinch)')),
              ],
              onChanged: (val) => setState(() => _priority = val ?? 'medium'),
            ),
            const SizedBox(height: 12),

            // Sana va Vaqt
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.calendar_today, size: 16),
                    label: Text(DateFormat('dd.MM.yyyy').format(_selectedDate)),
                    onPressed: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: _selectedDate,
                        firstDate: DateTime.now(),
                        lastDate: DateTime.now().add(const Duration(days: 365)),
                      );
                      if (picked != null) setState(() => _selectedDate = picked);
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.access_time, size: 16),
                    label: Text(_selectedTime.format(context)),
                    onPressed: () async {
                      final picked = await showTimePicker(
                        context: context,
                        initialTime: _selectedTime,
                      );
                      if (picked != null) setState(() => _selectedTime = picked);
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Bekor qilish'),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primaryNavy,
            foregroundColor: Colors.white,
          ),
          onPressed: () async {
            final title = _titleController.text.trim();
            if (title.isEmpty) return;

            final finalDueDate = DateTime(
              _selectedDate.year,
              _selectedDate.month,
              _selectedDate.day,
              _selectedTime.hour,
              _selectedTime.minute,
            );

            final task = TaskModel(
              id: 'task_${DateTime.now().millisecondsSinceEpoch}',
              familyId: auth.currentUser?.familyId ?? 'family_101',
              title: title,
              description: _descController.text.trim().isNotEmpty ? _descController.text.trim() : null,
              assignedToName: _assignedMemberName ?? auth.currentUser?.name,
              dueDate: finalDueDate,
              priority: _priority,
              recurrence: _recurrence,
              createdBy: auth.currentUser?.id ?? 'parent',
            );

            await firestore.addTask(task);
            if (mounted) Navigator.of(context).pop();
          },
          child: const Text('Qo\'shish'),
        ),
      ],
    );
  }
}
