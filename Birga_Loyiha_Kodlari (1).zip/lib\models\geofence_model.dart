class GeofenceZoneModel {
  final String id;
  final String familyId;
  final String name; // 'Uy', 'Maktab', 'O\'quv markazi', 'Bobomiznik'
  final String address;
  final double latitude;
  final double longitude;
  final double radiusMeters; // Masalan: 150 metr
  final List<String> targetChildIds;
  final bool notifyOnEntry; // Hududga kirganda ogohlantirish
  final bool notifyOnExit;  // Hududdan chiqqanda ogohlantirish
  final String iconType;    // 'home', 'school', 'sports', 'other'

  GeofenceZoneModel({
    required this.id,
    required this.familyId,
    required this.name,
    required this.address,
    required this.latitude,
    required this.longitude,
    this.radiusMeters = 150.0,
    required this.targetChildIds,
    this.notifyOnEntry = true,
    this.notifyOnExit = true,
    this.iconType = 'school',
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'familyId': familyId,
      'name': name,
      'address': address,
      'latitude': latitude,
      'longitude': longitude,
      'radiusMeters': radiusMeters,
      'targetChildIds': targetChildIds,
      'notifyOnEntry': notifyOnEntry,
      'notifyOnExit': notifyOnExit,
      'iconType': iconType,
    };
  }

  factory GeofenceZoneModel.fromMap(Map<String, dynamic> map, String docId) {
    return GeofenceZoneModel(
      id: docId,
      familyId: map['familyId'] ?? '',
      name: map['name'] ?? '',
      address: map['address'] ?? '',
      latitude: (map['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (map['longitude'] as num?)?.toDouble() ?? 0.0,
      radiusMeters: (map['radiusMeters'] as num?)?.toDouble() ?? 150.0,
      targetChildIds: List<String>.from(map['targetChildIds'] ?? []),
      notifyOnEntry: map['notifyOnEntry'] ?? true,
      notifyOnExit: map['notifyOnExit'] ?? true,
      iconType: map['iconType'] ?? 'school',
    );
  }
}
