import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../services/auth_service.dart';
import '../home/main_shell_screen.dart';

class ChildLoginScreen extends StatefulWidget {
  const ChildLoginScreen({super.key});

  @override
  State<ChildLoginScreen> createState() => _ChildLoginScreenState();
}

class _ChildLoginScreenState extends State<ChildLoginScreen> {
  final _childNameController = TextEditingController();
  final _familyCodeController = TextEditingController(text: 'BRG842');
  final _pinController = TextEditingController(text: '1234');
  String? _errorMessage;

  @override
  void dispose() {
    _childNameController.dispose();
    _familyCodeController.dispose();
    _pinController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authService = context.watch<AuthService>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Farzand sifatida ulanish'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Top Friendly Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.accentGreenLight.withOpacity(0.5),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppColors.accentGreen.withOpacity(0.3)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.family_restroom, size: 40, color: AppColors.accentGreen),
                  SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      'Ota-onangiz bergan Oila kodi va PIN-kodni kiriting',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.primaryNavy,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),

            TextField(
              controller: _childNameController,
              decoration: const InputDecoration(
                labelText: 'Ismingiz',
                hintText: 'Masalan: Jasur',
                prefixIcon: Icon(Icons.face_rounded, color: AppColors.accentGreen),
              ),
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _familyCodeController,
              textCapitalization: TextCapitalization.characters,
              maxLength: 6,
              decoration: const InputDecoration(
                labelText: 'Oila taklif kodi (6 ta belgi)',
                hintText: 'Masalan: BRG842',
                prefixIcon: Icon(Icons.vpn_key_rounded, color: AppColors.accentGreen),
              ),
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _pinController,
              keyboardType: TextInputType.number,
              obscureText: true,
              maxLength: 4,
              decoration: const InputDecoration(
                labelText: 'Farzand PIN-kodi (4 ta raqam)',
                hintText: '****',
                prefixIcon: Icon(Icons.password_rounded, color: AppColors.accentGreen),
              ),
            ),

            if (_errorMessage != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.danger.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _errorMessage!,
                  style: const TextStyle(color: AppColors.danger, fontSize: 13),
                ),
              ),
            ],

            const SizedBox(height: 24),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.accentGreen,
                foregroundColor: Colors.white,
              ),
              onPressed: authService.isLoading
                  ? null
                  : () async {
                      setState(() => _errorMessage = null);
                      final name = _childNameController.text.trim();
                      final code = _familyCodeController.text.trim();
                      final pin = _pinController.text.trim();

                      if (code.isEmpty || pin.isEmpty) {
                        setState(() => _errorMessage = 'Iltimos, oila kodi va PIN-kodni to\'liq kiriting');
                        return;
                      }

                      final user = await authService.loginChildWithCode(
                        familyInviteCode: code,
                        childPinCode: pin,
                        childName: name.isNotEmpty ? name : 'Farzand',
                      );

                      if (user != null) {
                        Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const MainShellScreen()),
                          (route) => false,
                        );
                      }
                    },
              child: authService.isLoading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Oilaga ulanish', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}
