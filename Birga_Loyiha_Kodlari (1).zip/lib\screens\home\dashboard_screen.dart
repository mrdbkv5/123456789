import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../tasks/voice_task_dialog.dart';
import '../tasks/tasks_screen.dart';
import '../shopping/shopping_screen.dart';
import '../bills/bills_screen.dart';
import '../education/education_screen.dart';
import '../education/medical_passport_screen.dart';
import '../parental_control/parental_dashboard_screen.dart';
import '../parental_control/remote_screen_viewer_screen.dart';
import '../parental_control/app_limits_screen.dart';
import '../safety/emergency_sos_screen.dart';
import '../ai_assistant/ai_family_assistant_screen.dart';
import '../rewards/family_rewards_screen.dart';
import '../map/family_map_screen.dart';
import '../chat/chat_list_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final firestore = context.watch<FirestoreService>();
    final user = auth.currentUser;
    final isParent = user?.isParent ?? true;
    final familyId = user?.familyId ?? 'family_101';

    final tasks = firestore.getTasks(familyId);
    final todayTasks = tasks.where((t) {
      final now = DateTime.now();
      return t.dueDate.year == now.year && t.dueDate.month == now.month && t.dueDate.day == now.day;
    }).toList();
    final completedCount = tasks.where((t) => t.isCompleted).length;

    final shoppingItems = firestore.getShoppingItems(familyId);
    final unpurchasedCount = shoppingItems.where((i) => !i.isPurchased).length;

    final bills = firestore.getBills(familyId);
    final pendingBills = bills.where((b) => b.status != 'paid').toList();

    final screenTimes = firestore.getScreenTimes(familyId);
    final childScreenTime = screenTimes.isNotEmpty ? screenTimes.first : null;
    final coins = firestore.getChildCoins();
    final isSirenActive = firestore.isEmergencySirenActive;
    final isSosActive = firestore.isChildSOSActive;

    final todayFormatted = DateFormat('EEEE, d-MMMM', 'uz').format(DateTime.now());

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {},
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            children: [
              // HEADER: User Info & Family Code
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Assalomu alaykum, ${user?.name.split(" ").first ?? "Oila a'zosi"}! 👋',
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Bugun $todayFormatted',
                        style: const TextStyle(fontSize: 13, color: AppColors.textSecondaryLight),
                      ),
                    ],
                  ),
                  CircleAvatar(
                    radius: 24,
                    backgroundColor: isParent ? AppColors.primaryNavy : AppColors.accentGreen,
                    child: Text(
                      user?.name.isNotEmpty == true ? user!.name[0] : 'B',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),

              // SOS / EMERGENCY ALERT BANNER (If active)
              if (isSosActive || isSirenActive) ...[
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const EmergencySosScreen()));
                  },
                  borderRadius: BorderRadius.circular(18),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.red.shade600,
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.red.withOpacity(0.4),
                          blurRadius: 14,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.warning_amber_rounded, color: Colors.white, size: 30),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'FAVQULODDA SIGNAL FAOL!',
                                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                              ),
                              Text(
                                'Batafsil ko\'rish va boshqarish uchun bosing',
                                style: TextStyle(color: Colors.white70, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white, size: 16),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
              ],

              // HERO CARD: Today's Tasks & Voice Action
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppColors.primaryNavy, Color(0xFF1E3A8A)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(22),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primaryNavy.withOpacity(0.25),
                      blurRadius: 16,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Bugun ${todayTasks.length} ta vazifa bor',
                          style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '$completedCount / ${tasks.length} bajarildi',
                            style: const TextStyle(color: Colors.white, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    if (todayTasks.isNotEmpty) ...[
                      Text(
                        '• ${todayTasks.first.title}',
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Muddat: soat ${DateFormat('HH:mm').format(todayTasks.first.dueDate)}',
                        style: const TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                    ] else ...[
                      const Text(
                        'Bugungi hamma ishlar bajarilgan yoki rejalashtirilmagan',
                        style: TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                    ],
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.accentGreen,
                            foregroundColor: Colors.white,
                            minimumSize: const Size(120, 38),
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                          ),
                          onPressed: () {
                            showDialog(
                              context: context,
                              builder: (_) => const VoiceTaskDialog(),
                            );
                          },
                          icon: const Icon(Icons.mic, size: 18),
                          label: const Text('Ovozli kiritish', style: TextStyle(fontSize: 13)),
                        ),
                        const SizedBox(width: 10),
                        OutlinedButton(
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.white,
                            side: const BorderSide(color: Colors.white54),
                            minimumSize: const Size(100, 38),
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                          ),
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => const TasksScreen()));
                          },
                          child: const Text('Barchasi', style: TextStyle(fontSize: 13)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),

              // SECTION: INNOVATIVE & RICH FEATURES HUB (SUPER-APP GRID)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Super-Ilova & Xavfsizlik Paneli',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: AppColors.accentGreenLight,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Text(
                      'PRO',
                      style: TextStyle(color: AppColors.accentGreen, fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Super-App Feature Grid
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.35,
                children: [
                  _buildSuperAppFeature(
                    context,
                    title: 'Favqulodda SOS',
                    subtitle: 'Baland Sirena & Xavf',
                    icon: Icons.emergency_rounded,
                    gradient: const [Color(0xFFEF4444), Color(0xFFDC2626)],
                    badge: isSirenActive ? 'Faol!' : null,
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const EmergencySosScreen()));
                    },
                  ),
                  _buildSuperAppFeature(
                    context,
                    title: 'Birga AI Repetitor',
                    subtitle: 'Aqlli Oila Assistent',
                    icon: Icons.auto_awesome,
                    gradient: const [Color(0xFF6366F1), Color(0xFF4F46E5)],
                    badge: 'AI',
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AiFamilyAssistantScreen()));
                    },
                  ),
                  _buildSuperAppFeature(
                    context,
                    title: 'Birga Coins',
                    subtitle: '${coins.totalCoins} tanga • Orzular',
                    icon: Icons.monetization_on_rounded,
                    gradient: const [Color(0xFFF59E0B), Color(0xFFD97706)],
                    badge: '+${coins.weeklyEarned}',
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const FamilyRewardsScreen()));
                    },
                  ),
                  _buildSuperAppFeature(
                    context,
                    title: 'Masofaviy Nazorat',
                    subtitle: 'Ekran & Bloklash',
                    icon: Icons.phone_android_rounded,
                    gradient: const [Color(0xFF0EA5E9), Color(0xFF0284C7)],
                    badge: 'Live',
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const RemoteScreenViewerScreen()));
                    },
                  ),
                  _buildSuperAppFeature(
                    context,
                    title: 'Ilova Cheklovlari',
                    subtitle: 'Uyqu & Cheklovlar',
                    icon: Icons.bedtime_rounded,
                    gradient: const [Color(0xFF8B5CF6), Color(0xFF7C3AED)],
                    badge: '22:00',
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AppLimitsScreen()));
                    },
                  ),
                  _buildSuperAppFeature(
                    context,
                    title: 'Jonli Xarita',
                    subtitle: 'Geozonalar & GPS',
                    icon: Icons.map_rounded,
                    gradient: const [Color(0xFF10B981), Color(0xFF059669)],
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const FamilyMapScreen()));
                    },
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // SECTION: DAILY OPERATIONS (Shopping, Bills, Education, Medical)
              const Text(
                'Kundalik Rejalar & Salomatlik',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(
                    child: _buildDashboardCard(
                      context,
                      icon: Icons.shopping_basket_rounded,
                      iconColor: AppColors.accentGreen,
                      title: 'Xaridlar',
                      value: '$unpurchasedCount ta mahsulot',
                      subtitle: 'Umumiy ro\'yxat',
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const ShoppingScreen()));
                      },
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: _buildDashboardCard(
                      context,
                      icon: Icons.receipt_long_rounded,
                      iconColor: AppColors.warning,
                      title: 'To\'lovlar',
                      value: '${pendingBills.length} ta kutilmoqda',
                      subtitle: pendingBills.isNotEmpty ? pendingBills.first.category : 'Barchasi to\'langan',
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const BillsScreen()));
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),

              Row(
                children: [
                  Expanded(
                    child: _buildDashboardCard(
                      context,
                      icon: Icons.medical_services_rounded,
                      iconColor: Colors.redAccent,
                      title: 'Tibbiy Pasport',
                      value: 'Oila xavfsizligi',
                      subtitle: 'Qon guruhi & allergiya',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const MedicalPassportScreen(childId: 'child_demo_id'),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: _buildDashboardCard(
                      context,
                      icon: Icons.timer_rounded,
                      iconColor: childScreenTime?.isLimitExceeded == true ? AppColors.danger : AppColors.primaryNavy,
                      title: 'Ekran Vaqti',
                      value: childScreenTime != null ? '${childScreenTime.totalMinutes ~/ 60}s ${childScreenTime.totalMinutes % 60}d' : '0s 0d',
                      subtitle: 'Maqsad: 2 soat',
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const ParentalDashboardScreen()));
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // BIRGA CHAT BANNER
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatListScreen()));
                },
                borderRadius: BorderRadius.circular(18),
                child: Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: AppColors.softBlueLight.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppColors.softBlue.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: const BoxDecoration(
                          color: AppColors.softBlue,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.forum_rounded, color: Colors.white, size: 24),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Birga Chat — Oilaviy Yozishmalar',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                            ),
                            SizedBox(height: 2),
                            Text(
                              'Guruh suhbati, shaxsiy va ovozli xabarlar',
                              style: TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: AppColors.primaryNavy),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSuperAppFeature(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required List<Color> gradient,
    String? badge,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: gradient.first.withOpacity(0.28),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CircleAvatar(
                  radius: 16,
                  backgroundColor: Colors.white24,
                  child: Icon(icon, color: Colors.white, size: 18),
                ),
                if (badge != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      badge,
                      style: TextStyle(
                        color: gradient.first,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(color: Colors.white70, fontSize: 11),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardCard(
    BuildContext context, {
    required IconData icon,
    required Color iconColor,
    required String title,
    required String value,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.borderLight),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: iconColor.withOpacity(0.12),
              child: Icon(icon, color: iconColor, size: 20),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(fontSize: 13, color: AppColors.textSecondaryLight, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              style: const TextStyle(fontSize: 11, color: AppColors.textSecondaryLight),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
