import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../models/grade_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';

class EducationScreen extends StatelessWidget {
  const EducationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final auth = context.watch<AuthService>();
    final familyId = auth.currentUser?.familyId ?? 'family_101';
    final grades = firestore.getGrades(familyId);

    // O'rtacha baho hisoblash (5 ballik ekvivalentida)
    double totalEquivalent = 0;
    for (var g in grades) {
      if (g.gradingScale == '100_scale') {
        totalEquivalent += (g.score / 20.0);
      } else {
        totalEquivalent += g.score;
      }
    }
    double gpa = grades.isNotEmpty ? totalEquivalent / grades.length : 0.0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Farzandlar Ta\'limi'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // GPA Card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.primaryNavy, AppColors.primaryBlue],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primaryNavy.withOpacity(0.2),
                  blurRadius: 15,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 65,
                  height: 65,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      gpa.toStringAsFixed(1),
                      style: const TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 18),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Umumiy O\'rtacha Baho (GPA)',
                        style: TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'A\'lo o\'zlashtirish',
                        style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 2),
                      Text(
                        '5 va 100 ballik shkalalar asosida',
                        style: TextStyle(color: Colors.white60, fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Baholar ro'yxati
          const Text(
            'So\'nggi baholar va nazorat ishlari',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),

          if (grades.isEmpty)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text('Baholar hali kiritilmagan'),
              ),
            )
          else
            ...grades.map((grade) => _buildGradeCard(context, grade)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.accentGreen,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_chart_rounded),
        label: const Text('Baho kiritish'),
        onPressed: () => _showAddGradeDialog(context),
      ),
    );
  }

  Widget _buildGradeCard(BuildContext context, GradeModel grade) {
    Color scoreColor = AppColors.accentGreen;
    if (grade.percentage < 60) {
      scoreColor = AppColors.danger;
    } else if (grade.percentage < 80) {
      scoreColor = AppColors.warning;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  grade.subject,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: scoreColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '${grade.score.toStringAsFixed(grade.score.truncateToDouble() == grade.score ? 0 : 1)} / ${grade.maxScore.toInt()}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: scoreColor,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              '${grade.childName} • ${grade.examType} • ${DateFormat('dd.MM.yyyy').format(grade.examDate)}',
              style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
            ),
            if (grade.teacherNote != null && grade.teacherNote!.isNotEmpty) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.backgroundLight,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.comment_outlined, size: 16, color: AppColors.textSecondaryLight),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'O\'qituvchi izohi: ${grade.teacherNote!}',
                        style: const TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            if (grade.homework != null && grade.homework!.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(
                'Uy vazifasi: ${grade.homework}',
                style: const TextStyle(fontSize: 12, color: AppColors.primaryBlue),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _showAddGradeDialog(BuildContext context) {
    final subjectCtrl = TextEditingController();
    final scoreCtrl = TextEditingController();
    final noteCtrl = TextEditingController();
    final hwCtrl = TextEditingController();
    String gradingScale = '5_scale';
    String examType = 'Kundalik dars';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Yangi baho kiritish'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: subjectCtrl,
                  decoration: const InputDecoration(labelText: 'Fan nomi (Masalan: Matematika)'),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: TextField(
                        controller: scoreCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Baho'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      flex: 3,
                      child: DropdownButtonFormField<String>(
                        value: gradingScale,
                        items: const [
                          DropdownMenuItem(value: '5_scale', child: Text('5 ballik tizim')),
                          DropdownMenuItem(value: '100_scale', child: Text('100 ballik tizim')),
                        ],
                        onChanged: (val) => setDialogState(() => gradingScale = val ?? '5_scale'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: examType,
                  decoration: const InputDecoration(labelText: 'Topshiriq / Imtihon turi'),
                  items: const [
                    DropdownMenuItem(value: 'Kundalik dars', child: Text('Kundalik dars')),
                    DropdownMenuItem(value: 'Nazorat ishi', child: Text('Nazorat ishi')),
                    DropdownMenuItem(value: 'Choraklik imtihon', child: Text('Choraklik imtihon')),
                    DropdownMenuItem(value: 'Uy vazifasi', child: Text('Uy vazifasi')),
                  ],
                  onChanged: (val) => setDialogState(() => examType = val ?? examType),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: noteCtrl,
                  decoration: const InputDecoration(labelText: 'O\'qituvchi izohi (ixtiyoriy)'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: hwCtrl,
                  decoration: const InputDecoration(labelText: 'Uy vazifasi (ixtiyoriy)'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Bekor qilish'),
            ),
            ElevatedButton(
              onPressed: () async {
                final subj = subjectCtrl.text.trim();
                final score = double.tryParse(scoreCtrl.text.trim()) ?? 0;
                if (subj.isEmpty || score <= 0) return;

                final auth = context.read<AuthService>();
                final firestore = context.read<FirestoreService>();

                final newGrade = GradeModel(
                  id: 'grade_${DateTime.now().millisecondsSinceEpoch}',
                  familyId: auth.currentUser?.familyId ?? 'family_101',
                  childId: 'child_demo_id',
                  childName: 'Jasur Rahimov',
                  subject: subj,
                  score: score,
                  maxScore: gradingScale == '100_scale' ? 100.0 : 5.0,
                  gradingScale: gradingScale,
                  examType: examType,
                  teacherNote: noteCtrl.text.trim().isNotEmpty ? noteCtrl.text.trim() : null,
                  homework: hwCtrl.text.trim().isNotEmpty ? hwCtrl.text.trim() : null,
                  examDate: DateTime.now(),
                  createdAt: DateTime.now(),
                );

                await firestore.addGrade(newGrade);
                Navigator.pop(ctx);
              },
              child: const Text('Saqlash'),
            ),
          ],
        ),
      ),
    );
  }
}
