class ShoppingItemModel {
  final String id;
  final String familyId;
  final String name;
  final double quantity;
  final String unit; // 'dona', 'kg', 'litr', 'paket'
  final double? estimatedPrice;
  final String? note;
  final bool isPurchased;
  final String addedByName;
  final DateTime addedAt;

  ShoppingItemModel({
    required this.id,
    required this.familyId,
    required this.name,
    this.quantity = 1,
    this.unit = 'dona',
    this.estimatedPrice,
    this.note,
    this.isPurchased = false,
    required this.addedByName,
    required this.addedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'familyId': familyId,
      'name': name,
      'quantity': quantity,
      'unit': unit,
      'estimatedPrice': estimatedPrice,
      'note': note,
      'isPurchased': isPurchased,
      'addedByName': addedByName,
      'addedAt': addedAt.toIso8601String(),
    };
  }

  factory ShoppingItemModel.fromMap(Map<String, dynamic> map, String docId) {
    return ShoppingItemModel(
      id: docId,
      familyId: map['familyId'] ?? '',
      name: map['name'] ?? '',
      quantity: (map['quantity'] as num?)?.toDouble() ?? 1.0,
      unit: map['unit'] ?? 'dona',
      estimatedPrice: (map['estimatedPrice'] as num?)?.toDouble(),
      note: map['note'],
      isPurchased: map['isPurchased'] ?? false,
      addedByName: map['addedByName'] ?? '',
      addedAt: map['addedAt'] != null
          ? DateTime.tryParse(map['addedAt']) ?? DateTime.now()
          : DateTime.now(),
    );
  }

  ShoppingItemModel copyWith({bool? isPurchased}) {
    return ShoppingItemModel(
      id: id,
      familyId: familyId,
      name: name,
      quantity: quantity,
      unit: unit,
      estimatedPrice: estimatedPrice,
      note: note,
      isPurchased: isPurchased ?? this.isPurchased,
      addedByName: addedByName,
      addedAt: addedAt,
    );
  }
}
