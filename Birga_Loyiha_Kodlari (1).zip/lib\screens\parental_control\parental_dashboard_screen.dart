import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../models/screen_time_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';

class ParentalDashboardScreen extends StatelessWidget {
  const ParentalDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final auth = context.watch<AuthService>();
    final familyId = auth.currentUser?.familyId ?? 'family_101';
    final screenTimes = firestore.getScreenTimes(familyId);

    final currentData = screenTimes.isNotEmpty ? screenTimes.first : null;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ota-ona Nazorati'),
      ),
      body: currentData == null
          ? const Center(child: Text('Statistika hali mavjud emas'))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // Child Selector & Status
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.borderLight),
                  ),
                  child: Row(
                    children: [
                      const CircleAvatar(
                        radius: 24,
                        backgroundColor: AppColors.accentGreenLight,
                        child: Icon(Icons.child_care_rounded, color: AppColors.accentGreen, size: 28),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              currentData.childName,
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                            ),
                            const SizedBox(height: 2),
                            Row(
                              children: [
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: const BoxDecoration(
                                    color: AppColors.accentGreen,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                const Text(
                                  'Qurilma ulangan • Ruxsat faol',
                                  style: TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),

                // Screen Time Summary Card
                _buildScreenTimeCard(context, currentData, firestore),
                const SizedBox(height: 20),

                // Top Used Apps
                const Text(
                  'Ilovalar bo\'yicha foydalanish',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                ...currentData.appUsages.map((app) => _buildAppUsageTile(app, currentData.totalMinutes)),
                const SizedBox(height: 24),

                // Platform & Privacy Notice
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.softBlueLight.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.privacy_tip_outlined, color: AppColors.primaryBlue),
                          SizedBox(width: 8),
                          Text(
                            'Shaffoflik va Maxfiylik Kafolati',
                            style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryNavy),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Birga ilovasi shaxsiy xabarlar, brauzer tarixi yoki parollarni o\'qimaydi. Ma\'lumotlar faqatgina Android UsageStats API va Apple FamilyControls rasmiy ruxsatlari asosida raqamli sog\'lom odatlarni ta\'minlash uchun yig\'iladi.',
                        style: TextStyle(fontSize: 12, color: AppColors.primaryNavy),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildScreenTimeCard(BuildContext context, ScreenTimeModel data, FirestoreService firestore) {
    final int hours = data.totalMinutes ~/ 60;
    final int mins = data.totalMinutes % 60;
    final int goalHours = data.dailyGoalMinutes ~/ 60;
    final double progress = (data.totalMinutes / data.dailyGoalMinutes).clamp(0.0, 1.0);
    final bool isExceeded = data.isLimitExceeded;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isExceeded ? AppColors.danger.withOpacity(0.5) : AppColors.borderLight,
          width: isExceeded ? 1.5 : 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Bugungi ekran vaqti',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.textSecondaryLight),
              ),
              InkWell(
                onTap: () => _showLimitDialog(context, data, firestore),
                child: const Row(
                  children: [
                    Icon(Icons.tune_rounded, size: 16, color: AppColors.primaryNavy),
                    SizedBox(width: 4),
                    Text(
                      'Chegarani sozlash',
                      style: TextStyle(fontSize: 13, color: AppColors.primaryNavy, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${hours}s ${mins}d',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.w800,
                  color: isExceeded ? AppColors.danger : AppColors.primaryNavy,
                ),
              ),
              const SizedBox(width: 8),
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  '/ maqsad ${goalHours} soat',
                  style: const TextStyle(fontSize: 14, color: AppColors.textSecondaryLight),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 10,
              backgroundColor: AppColors.borderLight,
              color: isExceeded ? AppColors.danger : AppColors.accentGreen,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppUsageTile(AppUsageItem app, int totalMinutes) {
    final int hours = app.usageMinutes ~/ 60;
    final int mins = app.usageMinutes % 60;
    final double percentage = totalMinutes > 0 ? (app.usageMinutes / totalMinutes) * 100 : 0;

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: AppColors.softBlueLight,
          child: Icon(_getAppCategoryIcon(app.category), color: AppColors.primaryBlue),
        ),
        title: Text(app.appName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        subtitle: Text('${percentage.toStringAsFixed(0)}% umumiy ekrandan'),
        trailing: Text(
          hours > 0 ? '${hours}s ${mins}d' : '${mins} daqiqa',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
        ),
      ),
    );
  }

  IconData _getAppCategoryIcon(String cat) {
    switch (cat) {
      case 'education':
        return Icons.school_rounded;
      case 'video':
        return Icons.play_arrow_rounded;
      case 'social':
        return Icons.chat_bubble_outline_rounded;
      case 'game':
        return Icons.sports_esports_rounded;
      default:
        return Icons.apps_rounded;
    }
  }

  void _showLimitDialog(BuildContext context, ScreenTimeModel data, FirestoreService firestore) {
    int selectedMinutes = data.dailyGoalMinutes;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Ekran vaqti chegarasi'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '${selectedMinutes ~/ 60} soat ${selectedMinutes % 60} daqiqa',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.primaryNavy),
              ),
              const SizedBox(height: 16),
              Slider(
                value: selectedMinutes.toDouble(),
                min: 30,
                max: 360,
                divisions: 11,
                label: '${selectedMinutes ~/ 60} soat',
                activeColor: AppColors.accentGreen,
                onChanged: (val) {
                  setDialogState(() => selectedMinutes = val.toInt());
                },
              ),
              const SizedBox(height: 10),
              const Text(
                'Chegara yaqinlashganda farzand telefoniga eslatma bildirishnomasi jo\'natiladi.',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                textAlign: TextAlign.center,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Bekor qilish'),
            ),
            ElevatedButton(
              onPressed: () {
                firestore.updateScreenTimeLimit(data.childId, selectedMinutes);
                Navigator.pop(ctx);
              },
              child: const Text('Saqlash'),
            ),
          ],
        ),
      ),
    );
  }
}
