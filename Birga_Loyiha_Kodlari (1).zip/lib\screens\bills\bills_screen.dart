import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_constants.dart';
import '../../models/bill_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';

class BillsScreen extends StatelessWidget {
  const BillsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final auth = context.watch<AuthService>();
    final familyId = auth.currentUser?.familyId ?? 'family_101';
    final bills = firestore.getBills(familyId);

    final pendingBills = bills.where((b) => b.status != 'paid').toList();
    final paidBills = bills.where((b) => b.status == 'paid').toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('To\'lovlar va Eslatmalar'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Info banner: Xavfsizlik va bank cheklovi haqida
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.softBlueLight.withOpacity(0.5),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Row(
              children: [
                Icon(Icons.info_outline_rounded, color: AppColors.primaryBlue),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Ilova faqat to\'lov muddatlari va eslatmalarni yuritadi. Bank kartalari saqlanmaydi va bevosita pul o\'tkazilmaydi.',
                    style: TextStyle(fontSize: 12, color: AppColors.primaryNavy),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          if (pendingBills.isNotEmpty) ...[
            const Text(
              'Kutilayotgan to\'lovlar',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            ...pendingBills.map((bill) => _buildBillCard(context, bill, firestore)),
            const SizedBox(height: 20),
          ],

          if (paidBills.isNotEmpty) ...[
            const Text(
              'To\'langanlar tarixi',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: AppColors.textSecondaryLight),
            ),
            const SizedBox(height: 10),
            ...paidBills.map((bill) => _buildBillCard(context, bill, firestore)),
          ],
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.primaryNavy,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('To\'lov qo\'shish'),
        onPressed: () => _showAddBillDialog(context),
      ),
    );
  }

  Widget _buildBillCard(BuildContext context, BillModel bill, FirestoreService firestore) {
    final isPaid = bill.status == 'paid';
    final isOverdue = bill.isOverdue;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: isPaid
                      ? AppColors.accentGreenLight
                      : (isOverdue ? AppColors.danger.withOpacity(0.15) : AppColors.softBlueLight),
                  child: Icon(
                    _getCategoryIcon(bill.category),
                    color: isPaid
                        ? AppColors.accentGreen
                        : (isOverdue ? AppColors.danger : AppColors.primaryBlue),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        bill.title,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Muddat: ${DateFormat('dd.MM.yyyy').format(bill.dueDate)}',
                        style: TextStyle(
                          fontSize: 12,
                          color: isOverdue ? AppColors.danger : AppColors.textSecondaryLight,
                          fontWeight: isOverdue ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  '${NumberFormat('#,###').format(bill.amount)} so\'m',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: isPaid
                        ? AppColors.accentGreenLight
                        : (isOverdue ? AppColors.danger.withOpacity(0.1) : AppColors.warning.withOpacity(0.1)),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    isPaid ? 'To\'langan' : (isOverdue ? 'Muddati o\'tgan' : 'Kutilmoqda'),
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: isPaid
                          ? AppColors.accentGreen
                          : (isOverdue ? AppColors.danger : AppColors.warning),
                    ),
                  ),
                ),
                if (!isPaid)
                  TextButton.icon(
                    onPressed: () => firestore.markBillAsPaid(bill.id),
                    icon: const Icon(Icons.check_circle_outline, size: 18),
                    label: const Text('To\'landi deb belgilash'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Elektr energiyasi':
        return Icons.bolt_rounded;
      case 'Gaz':
        return Icons.local_fire_department_rounded;
      case 'Suv':
        return Icons.water_drop_rounded;
      case 'Internet':
        return Icons.wifi_rounded;
      case 'Telefon':
        return Icons.phone_android_rounded;
      case 'Ijara':
        return Icons.home_work_rounded;
      case 'Ta\'lim':
        return Icons.school_rounded;
      default:
        return Icons.receipt_long_rounded;
    }
  }

  void _showAddBillDialog(BuildContext context) {
    final titleCtrl = TextEditingController();
    final amountCtrl = TextEditingController();
    DateTime dueDate = DateTime.now().add(const Duration(days: 7));
    String category = AppConstants.billCategories.first;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Yangi to\'lov kiritish'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: category,
                  decoration: const InputDecoration(labelText: 'Kategoriya'),
                  items: AppConstants.billCategories
                      .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                      .toList(),
                  onChanged: (val) => setDialogState(() => category = val ?? category),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: titleCtrl,
                  decoration: const InputDecoration(
                    labelText: 'To\'lov nomi',
                    hintText: 'Masalan: Uy interneti to\'lovi',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: amountCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Summa (so\'m)',
                    hintText: 'Masalan: 150000',
                  ),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  icon: const Icon(Icons.calendar_today, size: 16),
                  label: Text('To\'lov oxirgi muddati: ${DateFormat('dd.MM.yyyy').format(dueDate)}'),
                  onPressed: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: dueDate,
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (picked != null) setDialogState(() => dueDate = picked);
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Bekor qilish'),
            ),
            ElevatedButton(
              onPressed: () async {
                final title = titleCtrl.text.trim();
                final amt = double.tryParse(amountCtrl.text.trim()) ?? 0;
                if (title.isEmpty || amt <= 0) return;

                final auth = context.read<AuthService>();
                final firestore = context.read<FirestoreService>();

                final newBill = BillModel(
                  id: 'bill_${DateTime.now().millisecondsSinceEpoch}',
                  familyId: auth.currentUser?.familyId ?? 'family_101',
                  title: title,
                  amount: amt,
                  dueDate: dueDate,
                  category: category,
                  status: 'pending',
                  updatedAt: DateTime.now(),
                );

                await firestore.addBill(newBill);
                Navigator.pop(ctx);
              },
              child: const Text('Saqlash'),
            ),
          ],
        ),
      ),
    );
  }
}
