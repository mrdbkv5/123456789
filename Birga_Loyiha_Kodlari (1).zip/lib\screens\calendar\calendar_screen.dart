import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _selectedDate = DateTime.now();

  final List<Map<String, dynamic>> _demoEvents = [
    {
      'title': 'Jasurning ota-onalar majlisi',
      'time': '14:00',
      'type': 'Maktab tadbiri',
      'responsible': 'Aziz (Ota)',
      'color': AppColors.softBlue,
    },
    {
      'title': 'Bobomizning tug\'ilgan kuni',
      'time': '18:30',
      'type': 'Tug\'ilgan kun',
      'responsible': 'Butun oila',
      'color': AppColors.accentGreen,
    },
    {
      'title': 'Stomatolog ko\'rigi',
      'time': '11:00',
      'type': 'Shifokor qabuli',
      'responsible': 'Madina',
      'color': AppColors.warning,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Oilaviy Kalendar'),
      ),
      body: Column(
        children: [
          // Simulated Weekly Calendar Strip
          Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(7, (index) {
                final dayDate = DateTime.now().add(Duration(days: index - 2));
                final isSelected = dayDate.day == _selectedDate.day;

                return InkWell(
                  onTap: () => setState(() => _selectedDate = dayDate),
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: isSelected ? AppColors.primaryNavy : Colors.transparent,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      children: [
                        Text(
                          DateFormat('E', 'uz').format(dayDate).substring(0, 2),
                          style: TextStyle(
                            fontSize: 12,
                            color: isSelected ? Colors.white70 : AppColors.textSecondaryLight,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '${dayDate.day}',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: isSelected ? Colors.white : null,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
          const SizedBox(height: 16),

          // Events for the selected date
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${DateFormat('d-MMMM', 'uz').format(_selectedDate)} tadbirlari',
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
                Text(
                  '${_demoEvents.length} ta tadbir',
                  style: const TextStyle(fontSize: 13, color: AppColors.textSecondaryLight),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _demoEvents.length,
              itemBuilder: (context, index) {
                final ev = _demoEvents[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    leading: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: (ev['color'] as Color).withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(Icons.event_note_rounded, color: ev['color'] as Color),
                    ),
                    title: Text(
                      ev['title'],
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                    subtitle: Text('${ev['type']} • Mas\'ul: ${ev['responsible']}'),
                    trailing: Text(
                      ev['time'],
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.primaryNavy),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.primaryNavy,
        foregroundColor: Colors.white,
        child: const Icon(Icons.add),
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Yangi oilaviy tadbir qo\'shish oynasi')),
          );
        },
      ),
    );
  }
}
