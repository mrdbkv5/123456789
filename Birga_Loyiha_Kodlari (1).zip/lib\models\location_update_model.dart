class LocationUpdateModel {
  final String userId;
  final String familyId;
  final String userName;
  final String? avatarUrl;
  final double latitude;
  final double longitude;
  final double accuracy;
  final int batteryLevel;
  final bool isSharingEnabled;
  final bool isGpsEnabled;
  final DateTime updatedAt;

  LocationUpdateModel({
    required this.userId,
    required this.familyId,
    required this.userName,
    this.avatarUrl,
    required this.latitude,
    required this.longitude,
    this.accuracy = 10.0,
    this.batteryLevel = 100,
    this.isSharingEnabled = true,
    this.isGpsEnabled = true,
    required this.updatedAt,
  });

  bool get isStale => DateTime.now().difference(updatedAt).inMinutes > 30;

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'familyId': familyId,
      'userName': userName,
      'avatarUrl': avatarUrl,
      'latitude': latitude,
      'longitude': longitude,
      'accuracy': accuracy,
      'batteryLevel': batteryLevel,
      'isSharingEnabled': isSharingEnabled,
      'isGpsEnabled': isGpsEnabled,
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory LocationUpdateModel.fromMap(Map<String, dynamic> map, String docId) {
    return LocationUpdateModel(
      userId: docId,
      familyId: map['familyId'] ?? '',
      userName: map['userName'] ?? '',
      avatarUrl: map['avatarUrl'],
      latitude: (map['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (map['longitude'] as num?)?.toDouble() ?? 0.0,
      accuracy: (map['accuracy'] as num?)?.toDouble() ?? 10.0,
      batteryLevel: (map['batteryLevel'] as num?)?.toInt() ?? 100,
      isSharingEnabled: map['isSharingEnabled'] ?? true,
      isGpsEnabled: map['isGpsEnabled'] ?? true,
      updatedAt: map['updatedAt'] != null
          ? DateTime.tryParse(map['updatedAt']) ?? DateTime.now()
          : DateTime.now(),
    );
  }
}
