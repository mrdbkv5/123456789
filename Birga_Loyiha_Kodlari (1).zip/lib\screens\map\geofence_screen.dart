import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../models/geofence_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';

class GeofenceScreen extends StatelessWidget {
  const GeofenceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final auth = context.watch<AuthService>();
    final familyId = auth.currentUser?.familyId ?? 'family_101';
    final zones = firestore.getGeofences(familyId);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Geozonalar (Xavfsiz Hududlar)'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Info banner
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.accentGreenLight.withOpacity(0.5),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.accentGreen.withOpacity(0.3)),
            ),
            child: const Row(
              children: [
                Icon(Icons.shield_outlined, color: AppColors.accentGreen),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Farzandingiz belgilangan hududga kirganda yoki undan chiqqanda ota-onaga avtomatik bildirishnoma yuboriladi.',
                    style: TextStyle(fontSize: 12, color: AppColors.primaryNavy),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          const Text(
            'Faol Xavfsiz Hududlar',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),

          ...zones.map((zone) {
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: zone.iconType == 'home' ? AppColors.softBlueLight : AppColors.accentGreenLight,
                          child: Icon(
                            zone.iconType == 'home' ? Icons.home_rounded : Icons.school_rounded,
                            color: zone.iconType == 'home' ? AppColors.primaryBlue : AppColors.accentGreen,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                zone.name,
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                              ),
                              Text(
                                zone.address,
                                style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColors.backgroundLight,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text('Radius: ${zone.radiusMeters.toInt()}m', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    const Divider(height: 1),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.notifications_active_outlined, size: 16, color: AppColors.accentGreen),
                            const SizedBox(width: 6),
                            Text(
                              'Kirish: ${zone.notifyOnEntry ? "Yoqilgan" : "O'chiq"} • Chiqish: ${zone.notifyOnExit ? "Yoqilgan" : "O'chiq"}',
                              style: const TextStyle(fontSize: 12, color: AppColors.textSecondaryLight),
                            ),
                          ],
                        ),
                        const Chip(
                          label: Text('Jasur Rahimov', style: TextStyle(fontSize: 11, color: AppColors.primaryNavy)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.accentGreen,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_location_alt_rounded),
        label: const Text('Yangi Hudud Qo\'shish'),
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Xaritada yangi xavfsiz geozona belgilash oynasi')),
          );
        },
      ),
    );
  }
}
