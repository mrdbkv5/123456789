class RewardItemModel {
  final String id;
  final String title;
  final String category; // 'fun', 'gift', 'time', 'treat'
  final int coinCost;
  final String icon;
  final bool isApproved;
  final bool isRedeemed;
  final String? requestedBy;
  final DateTime? requestedAt;

  RewardItemModel({
    required this.id,
    required this.title,
    required this.category,
    required this.coinCost,
    required this.icon,
    this.isApproved = false,
    this.isRedeemed = false,
    this.requestedBy,
    this.requestedAt,
  });

  RewardItemModel copyWith({
    String? id,
    String? title,
    String? category,
    int? coinCost,
    String? icon,
    bool? isApproved,
    bool? isRedeemed,
    String? requestedBy,
    DateTime? requestedAt,
  }) {
    return RewardItemModel(
      id: id ?? this.id,
      title: title ?? this.title,
      category: category ?? this.category,
      coinCost: coinCost ?? this.coinCost,
      icon: icon ?? this.icon,
      isApproved: isApproved ?? this.isApproved,
      isRedeemed: isRedeemed ?? this.isRedeemed,
      requestedBy: requestedBy ?? this.requestedBy,
      requestedAt: requestedAt ?? this.requestedAt,
    );
  }
}

class ChildCoinProfile {
  final String childId;
  final String childName;
  final int totalCoins;
  final int weeklyEarned;
  final int level;

  ChildCoinProfile({
    required this.childId,
    required this.childName,
    required this.totalCoins,
    required this.weeklyEarned,
    this.level = 1,
  });

  ChildCoinProfile copyWith({
    String? childId,
    String? childName,
    int? totalCoins,
    int? weeklyEarned,
    int? level,
  }) {
    return ChildCoinProfile(
      childId: childId ?? this.childId,
      childName: childName ?? this.childName,
      totalCoins: totalCoins ?? this.totalCoins,
      weeklyEarned: weeklyEarned ?? this.weeklyEarned,
      level: level ?? this.level,
    );
  }
}
