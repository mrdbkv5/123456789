import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_colors.dart';
import '../../models/ai_message_model.dart';
import '../../services/firestore_service.dart';

class AiFamilyAssistantScreen extends StatefulWidget {
  const AiFamilyAssistantScreen({super.key});

  @override
  State<AiFamilyAssistantScreen> createState() => _AiFamilyAssistantScreenState();
}

class _AiFamilyAssistantScreenState extends State<AiFamilyAssistantScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  String _selectedCategory = 'all';

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final firestore = context.watch<FirestoreService>();
    final messages = firestore.getAIChat();

    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: AppColors.accentGreen,
              child: Icon(Icons.auto_awesome, color: Colors.white, size: 18),
            ),
            SizedBox(width: 10),
            Text('Birga AI — Aqlli Assistent'),
          ],
        ),
      ),
      body: Column(
        children: [
          // Category Selector Chips
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildCategoryChip('all', 'Barchasi', Icons.stars_rounded),
                  const SizedBox(width: 8),
                  _buildCategoryChip('tutor', '📚 Repetitor (Darslar)', Icons.school_rounded),
                  const SizedBox(width: 8),
                  _buildCategoryChip('parenting', '👨‍👩‍👧 Ota-onalik', Icons.family_restroom_rounded),
                  const SizedBox(width: 8),
                  _buildCategoryChip('health', '🥗 Sog\'lom Hayot', Icons.favorite_rounded),
                ],
              ),
            ),
          ),
          const Divider(height: 1),

          // Messages List
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final msg = messages[index];
                final isUser = msg.role == AIMessageRole.user;

                return Column(
                  crossAxisAlignment:
                      isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment:
                          isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (!isUser) ...[
                          const CircleAvatar(
                            radius: 16,
                            backgroundColor: AppColors.primaryNavy,
                            child: Icon(Icons.smart_toy_rounded, size: 18, color: Colors.white),
                          ),
                          const SizedBox(width: 8),
                        ],
                        Flexible(
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 12),
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: isUser
                                  ? AppColors.primaryNavy
                                  : Theme.of(context).cardColor,
                              borderRadius: BorderRadius.circular(18).copyWith(
                                bottomLeft: isUser ? const Radius.circular(18) : const Radius.circular(4),
                                bottomRight: isUser ? const Radius.circular(4) : const Radius.circular(18),
                              ),
                              border: isUser ? null : Border.all(color: AppColors.borderLight),
                            ),
                            child: SelectableText(
                              msg.text,
                              style: TextStyle(
                                color: isUser ? Colors.white : null,
                                fontSize: 14,
                                height: 1.4,
                              ),
                            ),
                          ),
                        ),
                        if (isUser) ...[
                          const SizedBox(width: 8),
                          const CircleAvatar(
                            radius: 16,
                            backgroundColor: AppColors.accentGreen,
                            child: Icon(Icons.person, size: 18, color: Colors.white),
                          ),
                        ],
                      ],
                    ),

                    // Suggested follow up questions
                    if (!isUser && msg.suggestedFollowUps != null && msg.suggestedFollowUps!.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(left: 40, bottom: 12),
                        child: Wrap(
                          spacing: 8,
                          runSpacing: 6,
                          children: msg.suggestedFollowUps!.map((q) {
                            return ActionChip(
                              label: Text(q, style: const TextStyle(fontSize: 12)),
                              backgroundColor: AppColors.softBlueLight.withOpacity(0.4),
                              onPressed: () {
                                _controller.text = q;
                                _sendMessage(firestore);
                              },
                            );
                          }).toList(),
                        ),
                      ),
                  ],
                );
              },
            ),
          ),

          // Message Input Field
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              border: const Border(top: BorderSide(color: AppColors.borderLight)),
            ),
            child: SafeArea(
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: InputDecoration(
                        hintText: 'Savolingizni yozing (masalan: 5-sinf matematika)...',
                        hintStyle: const TextStyle(fontSize: 13),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: const BorderSide(color: AppColors.borderLight),
                        ),
                        filled: true,
                        fillColor: Theme.of(context).scaffoldBackgroundColor,
                      ),
                      onSubmitted: (_) => _sendMessage(firestore),
                    ),
                  ),
                  const SizedBox(width: 8),
                  CircleAvatar(
                    radius: 24,
                    backgroundColor: AppColors.primaryNavy,
                    child: IconButton(
                      icon: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                      onPressed: () => _sendMessage(firestore),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _sendMessage(FirestoreService firestore) {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    _controller.clear();
    firestore.sendAIMessage(text, _selectedCategory);
    _scrollToBottom();
  }

  Widget _buildCategoryChip(String key, String label, IconData icon) {
    final isSelected = _selectedCategory == key;
    return ChoiceChip(
      avatar: Icon(icon, size: 16, color: isSelected ? Colors.white : AppColors.primaryNavy),
      label: Text(label),
      selected: isSelected,
      selectedColor: AppColors.primaryNavy,
      labelStyle: TextStyle(
        color: isSelected ? Colors.white : null,
        fontSize: 12,
        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
      ),
      onSelected: (val) {
        if (val) setState(() => _selectedCategory = key);
      },
    );
  }
}
